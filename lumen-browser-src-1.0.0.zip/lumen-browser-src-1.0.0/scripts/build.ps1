# ===========================================================================
#  Lumen Browser - scripts/build.ps1
#  一鍵建置：自動取得 CEF -> CMake 設定 -> MSBuild -> 複製執行期檔案
#
#  用法：
#    powershell -ExecutionPolicy Bypass -File scripts\build.ps1
#    powershell -ExecutionPolicy Bypass -File scripts\build.ps1 -Config Debug
#    powershell -ExecutionPolicy Bypass -File scripts\build.ps1 -CefRoot D:\sdk\cef
#    powershell -ExecutionPolicy Bypass -File scripts\build.ps1 -NoFetch      (不自動下載 CEF)
# ===========================================================================
param(
  [ValidateSet("Release", "Debug")]
  [string]$Config = "Release",
  [string]$CefRoot = "",
  [switch]$NativeFrame,
  [switch]$NoFetch
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Push-Location $root
try {
  Write-Host ""
  Write-Host "=== Lumen Browser build ===" -ForegroundColor Cyan
  Write-Host "root   : $root"
  Write-Host "config : $Config"
  Write-Host ""

  # ---- 1. 找 CEF（找不到就自動下載）--------------------------------------
  if (-not $CefRoot) {
    if ($env:CEF_ROOT) { $CefRoot = $env:CEF_ROOT }
    else { $CefRoot = Join-Path $root "third_party\cef" }
  }
  if (-not (Test-Path (Join-Path $CefRoot "include\cef_app.h"))) {
    if ($NoFetch) {
      Write-Host "找不到 CEF：$CefRoot" -ForegroundColor Red
      exit 1
    }
    Write-Host "找不到 CEF，開始自動下載 (約 335 MB)..." -ForegroundColor Yellow
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "scripts\fetch-cef.ps1") -CefRoot $CefRoot
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $CefRoot "include\cef_app.h"))) {
      throw "CEF 取得失敗"
    }
  }
  Write-Host "CEF    : $CefRoot"

  # ---- 2. 檢查 CMake（Visual Studio 有內建，但可能不在 PATH）-------------
  $vsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
  $cmake = "cmake"
  if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    if (Test-Path $vsWhere) {
      $vsPath = & $vsWhere -latest -products * -property installationPath
      $candidate = Join-Path $vsPath "Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
      if (Test-Path $candidate) { $cmake = $candidate }
    }
  }
  if ($cmake -eq "cmake" -and -not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    Write-Host "找不到 cmake。請安裝 CMake (https://cmake.org/download/) 或改用 VS 的「x64 Native Tools Command Prompt」。" -ForegroundColor Red
    exit 1
  }
  Write-Host "cmake  : $cmake"

  # ---- 3. CMake 設定 -----------------------------------------------------
  $buildDir = Join-Path $root "build"
  $cmakeArgs = @("-S", $root, "-B", $buildDir, "-A", "x64", "-DCEF_ROOT=$CefRoot")
  # 若有 VS 2022 才指定產生器，否則讓 CMake 自動挑（例如只有 VS 2019）
  if (Test-Path $vsWhere) {
    $vsVersion = & $vsWhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationVersion
    if ($vsVersion -and ("$vsVersion" -match '^17\.')) {
      $cmakeArgs = @("-G", "Visual Studio 17 2022") + $cmakeArgs
    }
  }
  if ($NativeFrame) { $cmakeArgs += "-DLUMEN_NATIVE_FRAME=ON" }

  Write-Host ""
  & $cmake @cmakeArgs
  if ($LASTEXITCODE -ne 0) { throw "CMake 設定失敗" }

  # ---- 4. 建置 -----------------------------------------------------------
  Write-Host ""
  Write-Host "開始編譯（首次會編譯 CEF wrapper，約 5~15 分鐘）..." -ForegroundColor Yellow
  & $cmake --build $buildDir --config $Config --parallel
  if ($LASTEXITCODE -ne 0) { throw "建置失敗" }

  # ---- 5. 結果 -----------------------------------------------------------
  $outDir = Join-Path $buildDir $Config
  $exe = Join-Path $outDir "lumen.exe"
  Write-Host ""
  if (Test-Path $exe) {
    Write-Host "建置成功 ✔" -ForegroundColor Green
    Write-Host "  執行檔    : $exe"
    Write-Host "  可攜根目錄: $outDir"
    Write-Host ""
    Write-Host "  直接執行它，第一次啟動會在該目錄旁建立 browser_data\：" -ForegroundColor Gray
    Write-Host "    & `"$exe`""
  } else {
    Write-Host "找不到輸出檔 lumen.exe，請檢查上方建置訊息。" -ForegroundColor Yellow
  }
}
finally {
  Pop-Location
}
