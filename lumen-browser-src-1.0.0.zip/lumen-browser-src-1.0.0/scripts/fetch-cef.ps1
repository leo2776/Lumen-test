# ===========================================================================
#  Lumen Browser - scripts/fetch-cef.ps1
#  自動下載並解壓 CEF binary distribution 到 third_party\cef
#
#  ★ 版本已鎖定：CEF 130 (Chromium 130.0.6723.117)
#    本專案的 C++ 程式碼是「逐項對照此版本的標頭檔」驗證過的。
#    升級 CEF 前請先讀 docs/CEF-VERSION-NOTES.md（有破壞性變更清單）。
#
#  用法：
#    powershell -ExecutionPolicy Bypass -File scripts\fetch-cef.ps1
#    powershell -ExecutionPolicy Bypass -File scripts\fetch-cef.ps1 -Force
#    powershell -ExecutionPolicy Bypass -File scripts\fetch-cef.ps1 -Version "130.1.16+g5a7e5ed+chromium-130.0.6723.117"
# ===========================================================================
param(
  [string]$Version = "130.1.16+g5a7e5ed+chromium-130.0.6723.117",
  [string]$CefRoot = "",
  [switch]$Force
)

$ErrorActionPreference = "Stop"

# TLS 1.2（舊版 Windows PowerShell 預設可能沒有）
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
} catch {}

$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
if (-not $CefRoot) { $CefRoot = Join-Path $root "third_party\cef" }
$CefRoot = [IO.Path]::GetFullPath($CefRoot)

function Write-Step($text) { Write-Host "==> $text" -ForegroundColor Cyan }
function Write-Warn($text) { Write-Host "    $text" -ForegroundColor Yellow }

Write-Step "CEF 版本：$Version"
Write-Step "目的資料夾：$CefRoot"

if ((Test-Path (Join-Path $CefRoot "include\cef_app.h")) -and -not $Force) {
  Write-Host "CEF 已存在，略過下載（要重新下載請加 -Force）" -ForegroundColor Green
  exit 0
}

# ---- 準備資料夾 -----------------------------------------------------------
$thirdParty = Split-Path -Parent $CefRoot
New-Item -ItemType Directory -Force -Path $thirdParty | Out-Null

$fileName = "cef_binary_${Version}_windows64.tar.bz2"
$url = "https://cef-builds.spotifycdn.com/" + ($fileName -replace '\+', '%2B')
$archive = Join-Path $thirdParty $fileName

Write-Step "下載中（約 335 MB，請耐心等候）"
Write-Warn $url

# 優先用 Windows 10 內建的 curl.exe（比 Invoke-WebRequest 快且穩定）
$curl = Join-Path $env:SystemRoot "System32\curl.exe"
if (Test-Path $curl) {
  & $curl -L --fail --retry 3 --retry-delay 5 -o $archive $url
  if ($LASTEXITCODE -ne 0) { throw "curl 下載失敗（錯誤碼 $LASTEXITCODE）" }
} else {
  Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing
}

$size = (Get-Item $archive).Length
Write-Host ("    完成，檔案大小 {0:N1} MB" -f ($size / 1MB))

# 預期 SHA1（-Version 可用預設值以外時略過檢查）
$expectedSha1 = "5bc51f2378ddcf0d05abbb7d07681e48ba78b83e"
if ($Version -eq "130.1.16+g5a7e5ed+chromium-130.0.6723.117") {
  Write-Step "驗證 SHA1"
  $sha1 = (Get-FileHash -Algorithm SHA1 -Path $archive).Hash.ToLower()
  if ($sha1 -ne $expectedSha1) {
    Write-Warn "SHA1 不符（預期 $expectedSha1，實際 $sha1）"
    Write-Warn "可能是下載不完整，請刪除檔案後重試。"
    throw "SHA1 驗證失敗"
  }
  Write-Host "    驗證通過" -ForegroundColor Green
}

# ---- 解壓（Windows 10 1803+ 內建 tar.exe 可處理 .tar.bz2）-----------------
Write-Step "解壓中（需要幾分鐘，解開後約 1.2 GB）"
$tempDir = Join-Path $env:TEMP ("lumen_cef_" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
New-Item -ItemType Directory -Force -Path $tempDir | Out-Null

$tar = Join-Path $env:SystemRoot "System32\tar.exe"
if (-not (Test-Path $tar)) {
  throw "找不到 $tar。請安裝 7-Zip 後手動解壓縮到 $CefRoot"
}
& $tar -xjf $archive -C $tempDir
if ($LASTEXITCODE -ne 0) { throw "解壓失敗（tar 錯誤碼 $LASTEXITCODE）" }

$extracted = Get-ChildItem -Path $tempDir -Directory | Where-Object { Test-Path (Join-Path $_.FullName "include\cef_app.h") } | Select-Object -First 1
if (-not $extracted) { throw "解壓後找不到 CEF 目錄結構" }

if (Test-Path $CefRoot) { Remove-Item -Recurse -Force $CefRoot }
New-Item -ItemType Directory -Force -Path $CefRoot | Out-Null
Write-Step "搬移到 $CefRoot"
Get-ChildItem -Path $extracted.FullName -Force | Move-Item -Destination $CefRoot -Force

# ---- 驗證與清理 -----------------------------------------------------------
Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue

$required = @(
  "include\cef_app.h",
  "cmake\cef_variables.cmake",
  "libcef_dll",
  "Release\libcef.dll",
  "Release\libcef.lib",
  "Resources\icudtl.dat"
)
$missing = @()
foreach ($item in $required) {
  if (-not (Test-Path (Join-Path $CefRoot $item))) { $missing += $item }
}

if ($missing.Count -eq 0) {
  Write-Host ""
  Write-Host "CEF 準備完成 ✔" -ForegroundColor Green
  Write-Host "  版本目錄：$CefRoot"
  Write-Host "  下一步：powershell -ExecutionPolicy Bypass -File scripts\build.ps1"
  Write-Host ""
  Write-Host "  提示：$archive 可刪除（已解壓完成）" -ForegroundColor DarkGray
} else {
  Write-Warn "缺少以下項目，CEF 可能不完整："
  $missing | ForEach-Object { Write-Warn "  - $_" }
  exit 1
}
