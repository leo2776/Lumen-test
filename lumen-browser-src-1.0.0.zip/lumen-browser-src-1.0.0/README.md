# Lumen Browser

> 以 **純 C++（Win32 + Direct2D + DirectWrite）自研外殼** + **CEF / Chromium 渲染核心** 打造的旗艦級 Windows 瀏覽器。
> 無 Electron、無 Python、無 Node、無任何 UI 框架、不寫登錄檔、不碰 AppData。

📌 **第一次要在全新 Windows 10 虛擬機上跑起來 → 直接看 [`QUICKSTART-WIN10-VM.md`](QUICKSTART-WIN10-VM.md)**
（含工具安裝、CEF 自動下載、編譯、驗收清單、疑難排解）。

📌 **不要任意升級 CEF** → 本專案鎖定 `CEF 130`，升級前請讀 [`docs/CEF-VERSION-NOTES.md`](docs/CEF-VERSION-NOTES.md)。

```
外殼 (Lumen)                             渲染核心 (CEF / Chromium)
┌──────────────────────────────────┐     ┌───────────────────────────────┐
│ 無邊框視窗 / 分頁列 / 網址列      │     │ Blink · V8 · Skia · ANGLE     │
│ 書籤列 / 深色選單 / 視窗按鈕      │◄───►│ HTML5 · CSS3 · JS · WebGL     │
│ Direct2D 自繪 + OSR 畫面合成      │     │ 離屏渲染 (BGRA 緩衝)          │
└──────────────────────────────────┘     └───────────────────────────────┘
                  │                                     │
                  └────────── ./browser_data/ ──────────┘   ← 100% 可攜
```

---

## 1. 專案資料夾結構

```
<root>/                                   ← 建置輸出 = 可攜根目錄
├── CMakeLists.txt                        建置腳本 (MSVC + CEF 官方 CMake 包裝層)
├── README.md                             本文件
├── QUICKSTART-WIN10-VM.md                ★ 全新 Win10 VM 從零到執行的完整步驟
├── docs/
│   ├── ARCHITECTURE.md                   架構深入說明 (資料流 / 執行緒模型 / 設計取捨)
│   └── CEF-VERSION-NOTES.md              CEF 版本鎖定 + API 破壞性變更清單
├── scripts/
│   ├── fetch-cef.ps1                     自動下載並驗證 CEF (鎖定版本 + SHA1)
│   └── build.ps1                         一鍵建置 (缺 CEF 會自動呼叫 fetch-cef)
├── res/
│   ├── browser.manifest                  Per-Monitor V2 DPI / comctl32 v6 / UTF-8
│   └── browser.rc                        manifest + 版本資訊 (無二進位資產)
├── third_party/
│   └── cef/                              ← 放 cef_binary_<ver>_windows64 (自行下載)
└── src/
    ├── main.cpp                          ★ 進入點：DPI、子行程分流、單一實例、
    │                                       CefInitialize、外部訊息幫浦、主訊息迴圈
    │
    ├── core/                             ── 核心層 (與 UI 無關，可獨立測試) ──
    │   ├── Platform.h                    共通前置 (Win32/UNICODE/自訂訊息)
    │   ├── PortablePaths.{h,cpp}         ★ 可攜路徑 SSOT + 單一實例鎖
    │   ├── AppConfig.{h,cpp}             settings.json 讀寫
    │   ├── BookmarkStore.{h,cpp}         bookmarks.tsv
    │   ├── HistoryStore.{h,cpp}          history.tsv
    │   ├── Tab.{h,cpp}                   單一分頁狀態 + OSR 像素緩衝
    │   ├── TabManager.{h,cpp}            分頁生命週期 / session 續存 / 縮放
    │   ├── BrowserUI.h                   核心 → UI 的單向介面 (斷開循環相依)
    │   ├── UrlUtil.{h,cpp}               Omnibox 輸入正規化 / 安全指示燈判斷
    │   └── UiPages.{h,cpp}               C++ 產生的內建頁 (新分頁/紀錄/書籤)
    │
    ├── app/                              ── CEF 整合層 ──
    │   ├── LumenApp.{h,cpp}              CefApp：命令列開關 (可攜性第 2 道防線)
    │   ├── TabClient.{h,cpp}             每個分頁的 CefClient (7 個 Handler)
    │   └── MessagePump.h                 External Message Pump 介面
    │
    ├── ui/                               ── 自研 UI 層 (100% Direct2D 自繪) ──
    │   ├── MainWindow.{h,cpp}            無邊框視窗、佈局、輸入轉送、快速鍵
    │   ├── TabStrip.{h,cpp}              分頁列 (圓角上緣 / hover / 載入轉圈 / +)
    │   ├── Omnibox.{h,cpp}               網址列 (D2D 膠囊 + 原生 EDIT 取得完整 IME)
    │   ├── BookmarksBar.{h,cpp}          書籤列膠囊
    │   ├── PopupMenu.{h,cpp}             深色彈出選單 (⋮ 主選單 + 右鍵選單)
    │   ├── Theme.{h,cpp}                 Chrome 深色 / 淺色配色
    │   └── Gfx.{h,cpp}                   D2D/DWrite 封裝、向量圖示、執行時產生 App 圖示
    │
    └── util/
        ├── WinUtil.{h,cpp}               字串/DPI/檔案 I/O/DWM 深色標題列
        └── MiniJson.{h,cpp}              零依賴扁平 JSON (設定檔用)
```

**執行後自動產生的可攜資料夾（與 exe 同層）：**

```
<root>/browser_data/
├── PORTABLE.txt            說明：整個資料夾就是瀏覽器的全部狀態
├── instance.lock           單一實例鎖
├── profile/                Chromium 設定檔 (Cookie / LocalStorage / IndexedDB / 密碼檔)
├── cache/                  HTTP 快取、GPU shader 快取
├── crash/                  Crashpad 傾印 (可刪)
├── logs/cef.log            核心日誌
├── config/settings.json    設定 (深色模式、首頁、搜尋引擎…)
├── config/bookmarks.tsv    書籤 (tab 分隔，可直接編輯)
├── config/history.tsv      瀏覽紀錄
├── config/session.tsv      上次開啟的分頁
├── ui/newtab.html          C++ 產生的新分頁
├── ui/history.html         動態產生的瀏覽紀錄頁
├── downloads/              下載檔案一律放這裡
└── temp/                   子行程 TMP/TEMP 導向於此
```

> 只要複製整個資料夾（含 exe + CEF DLL + browser_data）到任何 Windows 機器、任何路徑（含 USB 隨身碟），
> 含書籤、Cookie、登入狀態、歷史全部一起搬走。刪掉 `browser_data/` 即完全重置。

---

## 2. 環境依賴

| 項目 | 版本 | 說明 |
|---|---|---|
| Windows | 10 1809+ / 11 x64 | 使用 DWM 深色邊框、Per-Monitor V2 DPI、Direct2D 1.1 |
| Visual Studio | 2022 (MSVC v143) | 需「使用 C++ 的桌面開發」工作負載 |
| Windows SDK | 10.0.19041 以上 | Direct2D / DirectWrite / DWM |
| CMake | ≥ 3.21 | 支援 `add_subdirectory(cef/cmake)` |
| **CEF** | **`130.1.16+g5a7e5ed+chromium-130.0.6723.117`**（windows64 **Standard**） | 已鎖定。需含 `cmake/`、`include/`、`libcef_dll/`、`Release/`、`Resources/` |

CEF 下載：<https://cef-builds.spotifycdn.com/index.html> → `windows64` → **Standard**
（檔案 `cef_binary_130.1.16+g5a7e5ed+chromium-130.0.6723.117_windows64.tar.bz2`，335.3 MB，SHA1 `5bc51f2378ddcf0d05abbb7d07681e48ba78b83e`）。
或直接執行 `scripts\fetch-cef.ps1` 自動下載驗證。**請勿升級到 M132+**，原因見 `docs/CEF-VERSION-NOTES.md`。

```
third_party/cef/
├── cmake/           ← 官方 CMake 包裝層
├── include/         ← CEF 標頭
├── libcef_dll/      ← wrapper 原始碼
├── Release/         ← libcef.dll / chrome_elf.dll / *.pak / libcef.lib ...
├── Resources/       ← icudtl.dat / *.pak / locales/
└── Debug/
```

> 不需要 `cef_sandbox.lib`（本專案預設 `no_sandbox`，見 §6 說明如何開啟沙箱）。

---

## 3. 編譯指令

### 3.1 一鍵（PowerShell，推薦）

```powershell
cd <root>
# 若 third_party\cef 不存在，這一步會自動下載並驗證 CEF 130 (335 MB)
powershell -ExecutionPolicy Bypass -File scripts\build.ps1 -Config Release
```

只想先下載 CEF：`powershell -ExecutionPolicy Bypass -File scripts\fetch-cef.ps1`

### 3.2 手動 CMake（推薦）

```bat
:: 1) 取得 CEF（範例版本，請依 cef-builds 最新版替換）
mkdir third_party
curl -L -o cef.tar.bz2 https://cef-builds.spotifycdn.com/cef_binary_131.0.0%2BgXXXXXXXX%2Bchromium-131.0.0-windows64.tar.bz2
tar -xjf cef.tar.bz2 -C third_party
move third_party\cef_binary_131.0.0* third_party\cef

:: 2) 設定 & 建置
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --parallel

:: 3) 執行（輸出目錄就是可攜根目錄）
build\Release\lumen.exe
```

若 CEF 放在別處：

```bat
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DCEF_ROOT=D:\sdk\cef
```

建置完成後輸出目錄會自動包含：

```
build/Release/
├── lumen.exe
├── libcef.dll  chrome_elf.dll  libEGL.dll  libGLESv2.dll  d3dcompiler_47.dll
├── icudtl.dat  v8_context_snapshot.bin  resources.pak  chrome_100_percent.pak …
├── locales/
└── swiftshader/
```

第一次執行時，`lumen.exe` 會在**自己旁邊**建立 `browser_data/`。

### 3.3 除錯備援

若某些機器上自繪無邊框視窗的最大化版面異常，可用原生標題列編譯：

```bat
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DLUMEN_NATIVE_FRAME=ON
```

---

## 4. 功能清單

| 分類 | 功能 |
|---|---|
| 分頁 | 開新分頁（+ / Ctrl+T）、關閉（✕ / 中鍵 / Ctrl+W）、切換（點擊 / Ctrl+Tab / Ctrl+1..9）、載入轉圈、hover 效果、圓角上緣 Chrome 視覺 |
| 網址列 | Omnibox 正規化（網址 vs 搜尋）、https 鎖頭 / 非 https 地球圖示、書籤星號、完整中文 IME |
| 導覽 | 上一頁 / 下一頁 / 重新載入 / 停止（載入中同一按鈕）/ 首頁 |
| 書籤 | Ctrl+D 加入、書籤列膠囊、右鍵移除、`bookmarks.tsv` 可手改 |
| 選單 | ⋮ 深色自繪選單、網頁右鍵選單（自繪，非系統選單） |
| 內建頁 | 新分頁、瀏覽紀錄、書籤管理員（皆由 C++ 產生 HTML，無網路需求） |
| 外觀 | Chrome 風深色 / 淺色模式即時切換、DWM 圓角與深色邊框、Per-Monitor V2 DPI |
| 視窗 | 自繪最小化 / 最大化 / 還原 / 關閉按鈕、邊框拖曳縮放、Aero Snap |
| 其他 | 縮放（Ctrl+± / Ctrl+0 / Ctrl+滾輪）、列印、下載導向 `browser_data/downloads`、renderer 崩潰自動重載、自訂錯誤頁、session 還原 |

**快速鍵**：`Ctrl+T/W/L/R/D/H/J`、`Ctrl+Shift+B`（書籤列）、`Ctrl+1..9`、`Ctrl+Tab/Shift+Tab`、`Alt+←/→/Home`、`F5`、`Ctrl+Shift+R`（硬重載）、`Ctrl+±/0`、`F11`。

---

## 5. 可攜性（絕對隔離）怎麼做到的

四道防線，任何一道單獨失效都不會把資料寫到系統裡：

1. **`CefSettings`**
   `root_cache_path` = `browser_data/`、`log_file` = `browser_data/logs/cef.log`、
   `locales_dir_path` / `resources_dir_path` = 執行檔所在目錄。
2. **命令列開關**（`LumenApp::OnBeforeCommandLineProcessing`，會被所有子行程沿用）
   `--user-data-dir=<browser_data/profile>`、`--disk-cache-dir=<browser_data/cache>`、
   `--crash-dumps-dir=<browser_data/crash>`、`--log-file=…`
   並關閉首次執行精靈、元件更新、背景網路、同步、擴充功能等會產生外部副作用的行為。
3. **行程環境變數**（`PortablePaths::ApplyProcessEnvironment`）
   `TMP` / `TEMP` / `TMPDIR` 全部改指 `browser_data/temp`，子行程繼承。
4. **下載 / 設定 / 歷史 / session 全部走 `PortablePaths`**
   整個程式碼中**沒有任何一處**直接使用 `%APPDATA%`、`%LOCALAPPDATA%` 或登錄檔 API
   （唯一的登錄檔互動是 Windows 內建對話框的行為，並非本程式寫入）。

**驗證方式**

```powershell
# 1) 啟動前記錄
dir "$env:LOCALAPPDATA\CEF" -ErrorAction SilentlyContinue      # 應該不存在
# 2) 開幾個網頁、下載一個檔案、登入一個網站
# 3) 關閉後檢查
Get-ChildItem "$env:LOCALAPPDATA" -Filter "*CEF*" -Recurse -ErrorAction SilentlyContinue
Get-ChildItem "$env:APPDATA" -Filter "*Lumen*" -Recurse -ErrorAction SilentlyContinue
dir .\browser_data                        # 所有狀態都在這裡
```

進階：用 **Process Monitor** 過濾 `lumen.exe` 的 `WriteFile` 事件，路徑應全部落在 `browser_data\` 之下。

---

## 6. 已知限制與進階調整（誠實揭露）

| 項目 | 現況 | 說明 / 調整方式 |
|---|---|---|
| 沙箱 | 預設關閉 (`no_sandbox`) | 單一 exe 可攜模式最簡潔。要開啟：`CefScopedSandboxInfo` + 連結 `cef_sandbox.lib` + 傳 `sandbox_info` 給 `CefExecuteProcess`/`CefInitialize`，並移除 `settings.no_sandbox`。 |
| 網頁內 IME | OSR 模式下由 CEF 處理，少數輸入法組字視窗位置可能偏移 | 網址列使用原生 EDIT，中文輸入完全正常。若需要完整 IME，可考慮在 `MainWindow` 實作 `WM_IME_*` 轉送或改用 CEF Views 視窗。 |
| 渲染模式 | 軟體離屏渲染 (OSR, `shared_texture_enabled=false`) | 相容性最好。追求效能可改用共享紋理 (`shared_texture_enabled=true` + `OnAcceleratedPaint` + D3D11 合成)，本專案保留軟體路徑以確保可在任何 GPU/VM 上運行。 |
| 分頁拖曳排序 / 多視窗 | 未實作 | 分頁列已模組化 (`TabStrip`)，加入拖曳只需在 `MainWindow` 加 drag state。 |
| 擴充功能 / 書籤同步 | 不支援 | 已用 `--disable-extensions` 明確關閉。 |
| 效能 | 每個 frame 會 memcpy 一份 BGRA 到 `Tab` 的緩衝 | 若需極致效能：直接在 `OnPaint` 上傳至 D3D11 紋理、或使用共享紋理。 |
| 最大化版面 | `WM_NCCALCSIZE` + `WM_GETMINMAXINFO` 已互相搭配 | 少數 Windows 版本若出現 1~2px 間隙，微調 `MainWindow::HandleMessage` 中這兩個分支，或改用 `-DLUMEN_NATIVE_FRAME=ON`。 |

---

## 7. 疑難排解

| 症狀 | 原因 / 解法 |
|---|---|
| 啟動即關閉、`browser_data/logs/cef.log` 有訊息 | 多為 CEF 執行期檔缺漏：確認 `libcef.dll`、`chrome_elf.dll`、`icudtl.dat`、`v8_context_snapshot.bin`、`locales/`、`*.pak` 都在 exe 旁。 |
| 白畫面但標題/網址都正常 | 檢查 `GetViewRect` 是否拿到 0 尺寸（視窗最小化時屬正常）；`--disable-gpu` 可排除 GPU 驅動問題。 |
| 已有實例在執行 | 單一實例鎖以「可攜資料夾」為單位，會把既有視窗帶到前景；要同時跑多份，複製整個資料夾。 |
| `browser_data` 無法建立 | exe 所在資料夾不可寫（例如 `C:\Program Files`）。可攜式瀏覽器請放在可寫入路徑，或設定環境變數 `LUMEN_DATA_DIR=<絕對路徑>`。 |
| 中文選單變亂碼 | 必須以 `/utf-8` 編譯（CMakeLists 已設定）。 |
| 編譯時出現 `OnBeforePopup` / `OnCursorChange` / `Reload` 簽名不符 | 你用的 CEF 版本不是鎖定的 130。請執行 `scripts\fetch-cef.ps1 -Force` 換回 130，或依 `docs/CEF-VERSION-NOTES.md` §2 自行修改程式碼。 |

---

## 8. 授權與致謝

* 外殼程式碼（本專案 `src/`）為自研實作。
* 渲染核心為 [CEF (Chromium Embedded Framework)](https://bitbucket.org/chromiumembedded/cef)，遵循其 BSD 授權與 Chromium 的第三方授權清單；發佈 binary 時請一併附上 CEF/Chromium 的授權文件。
