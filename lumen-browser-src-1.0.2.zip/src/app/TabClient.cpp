#include "app/TabClient.h"

#include "core/BrowserUI.h"
#include "core/PortablePaths.h"
#include "core/Tab.h"
#include "core/TabManager.h"
#include "core/UrlUtil.h"
#include "util/WinUtil.h"

#include "include/cef_browser.h"
#include "include/cef_frame.h"
#include "include/cef_menu_model.h"
#include "include/cef_parser.h"

namespace lumen {
namespace {

std::wstring SanitizeFileName(const std::wstring& name) {
  std::wstring out;
  for (wchar_t c : name) {
    const bool bad = c == L'\\' || c == L'/' || c == L':' || c == L'*' || c == L'?' ||
                     c == L'"' || c == L'<' || c == L'>' || c == L'|' || c < 0x20;
    out.push_back(bad ? L'_' : c);
  }
  if (out.empty()) out = L"download.bin";
  return out;
}

std::wstring BuildErrorPage(const std::wstring& failed_url, const std::wstring& error_text,
                            int error_code) {
  std::wstring html;
  html += L"<!doctype html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\">";
  html += L"<title>無法連上這個網站</title><style>";
  html += L":root{color-scheme:dark light}body{margin:0;min-height:100vh;display:flex;"
          L"align-items:center;justify-content:center;font-family:'Segoe UI','Microsoft JhengHei',"
          L"sans-serif;background:#202124;color:#e8eaed}";
  html += L".card{max-width:560px;padding:40px}h1{font-size:22px;font-weight:600;margin:0 0 12px}";
  html += L"p{color:#9aa0a6;font-size:14px;line-height:1.7;margin:6px 0}";
  html += L"code{background:#2d2e31;padding:2px 6px;border-radius:4px;color:#8ab4f8;"
          L"word-break:break-all;font-size:13px}";
  html += L"</style></head><body><div class=\"card\">";
  html += L"<h1>無法連上這個網站</h1><p>網址：<code>" + failed_url + L"</code></p>";
  html += L"<p>錯誤：" + error_text + L" (" + std::to_wstring(error_code) + L")</p>";
  html += L"<p>請檢查網址是否正確、網路連線是否正常，或稍後再試一次。</p>";
  html += L"</div></body></html>";
  return html;
}

}  // namespace

TabClient::TabClient(TabManager* manager, Tab* tab) : manager_(manager), tab_(tab) {}

void TabClient::NotifyChanged() {
  if (manager_ && tab_) manager_->ui()->OnTabChanged(tab_);
}

// ---------------------------------------------------------------------------
//  RenderHandler
// ---------------------------------------------------------------------------
void TabClient::GetViewRect(CefRefPtr<CefBrowser> browser, CefRect& rect) {
  // CEF 的 view rect 使用「裝置無關像素 (DIP)」
  const int w = tab_ ? tab_->view_dip_width() : 1;
  const int h = tab_ ? tab_->view_dip_height() : 1;
  rect = CefRect(0, 0, w > 0 ? w : 1, h > 0 ? h : 1);
}

bool TabClient::GetScreenInfo(CefRefPtr<CefBrowser> browser, CefScreenInfo& screen_info) {
  if (tab_) screen_info.device_scale_factor = tab_->dpi_scale();
  return true;
}

void TabClient::OnPaint(CefRefPtr<CefBrowser> browser, PaintElementType type,
                        const RectList& dirtyRects, const void* buffer, int width, int height) {
  if (!tab_ || !manager_) return;
  if (type == PET_VIEW) {
    tab_->SetFrame(buffer, width, height);
    manager_->ui()->OnTabFrameReady(tab_);
  } else if (type == PET_POPUP) {
    tab_->SetPopupFrame(buffer, width, height);
    manager_->ui()->OnTabFrameReady(tab_);
  }
}

void TabClient::OnPopupShow(CefRefPtr<CefBrowser> browser, bool show) {
  if (!tab_) return;
  tab_->SetPopupVisible(show);
  if (manager_) manager_->ui()->OnTabFrameReady(tab_);
}

void TabClient::OnPopupSize(CefRefPtr<CefBrowser> browser, const CefRect& rect) {
  if (!tab_) return;
  tab_->SetPopupRect(rect.x, rect.y, rect.width, rect.height);
}

bool TabClient::OnCursorChange(CefRefPtr<CefBrowser> browser, CefCursorHandle cursor,
                               cef_cursor_type_t type, const CefCursorInfo& custom_cursor_info) {
  if (manager_ && cursor && type != CT_NONE) {
    manager_->ui()->OnCursorChanged((HCURSOR)cursor);
    return true;   // 由 MainWindow 在 WM_MOUSEMOVE 中套用自訂游標
  }
  return false;
}

// ---------------------------------------------------------------------------
//  DisplayHandler
// ---------------------------------------------------------------------------
void TabClient::OnAddressChange(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                                const CefString& url) {
  if (!tab_ || !frame) return;
  if (!frame->IsMain()) return;
  tab_->SetUrl(url.ToWString());
  NotifyChanged();
}

void TabClient::OnTitleChange(CefRefPtr<CefBrowser> browser, const CefString& title) {
  if (!tab_) return;
  tab_->SetTitle(title.ToWString());
  NotifyChanged();
}

void TabClient::OnStatusMessage(CefRefPtr<CefBrowser> browser, const CefString& value) {
  if (manager_ && tab_) manager_->ui()->OnStatusMessage(tab_, value.ToWString());
}

// ---------------------------------------------------------------------------
//  LoadHandler
// ---------------------------------------------------------------------------
void TabClient::OnLoadingStateChange(CefRefPtr<CefBrowser> browser, bool isLoading, bool canGoBack,
                                     bool canGoForward) {
  if (!tab_) return;
  tab_->SetLoading(isLoading);
  tab_->SetNavState(canGoBack, canGoForward);
  if (!isLoading) tab_->SetProgress(1.0);
  NotifyChanged();
}

void TabClient::OnLoadStart(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                            TransitionType transition_type) {
  if (!tab_ || !frame || !frame->IsMain()) return;
  tab_->SetLoading(true);
  tab_->SetProgress(0.0);
  tab_->SetUrl(frame->GetURL().ToWString());
  NotifyChanged();
}

void TabClient::OnLoadEnd(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                          int httpStatusCode) {
  if (!tab_ || !frame || !frame->IsMain()) return;
  tab_->SetLoading(false);
  tab_->SetProgress(1.0);
  tab_->SetNavState(browser->CanGoBack(), browser->CanGoForward());
  if (manager_) manager_->RecordHistory(tab_);
  NotifyChanged();
}

void TabClient::OnLoadError(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                            ErrorCode errorCode, const CefString& errorText,
                            const CefString& failedUrl) {
  if (!frame || !frame->IsMain()) return;
  if (errorCode == ERR_ABORTED) return;   // 使用者主動取消，不是錯誤

  const std::wstring page =
      BuildErrorPage(failedUrl.ToWString(), errorText.ToWString(), (int)errorCode);
  frame->LoadURL(CefString(L"data:text/html;charset=utf-8," + EscapeQueryParam(page)));
  if (tab_) {
    tab_->SetLoading(false);
    tab_->SetNavState(browser->CanGoBack(), browser->CanGoForward());
    NotifyChanged();
  }
}

// ---------------------------------------------------------------------------
//  LifeSpanHandler
// ---------------------------------------------------------------------------
bool TabClient::OnBeforePopup(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                              const CefString& target_url, const CefString& target_frame_name,
                              WindowOpenDisposition target_disposition, bool user_gesture,
                              const CefPopupFeatures& popup_features, CefWindowInfo& window_info,
                              CefRefPtr<CefClient>& client, CefBrowserSettings& settings,
                              CefRefPtr<CefDictionaryValue>& extra_info,
                              bool* no_javascript_access) {
  const std::wstring url = target_url.ToWString();
  if (!manager_ || !tab_) return true;   // 一律攔截：Lumen 用自己的分頁列呈現

  // 空白目標視窗 (window.open 後由 script 寫入內容) 直接導向目前網址
  if (url.empty()) return true;

  // 非使用者手勢觸發的彈出視窗 (如自動廣告) 靜默封鎖
  if (!user_gesture && !IsInternalUrl(url)) return true;

  const bool background = (target_disposition == CEF_WOD_NEW_BACKGROUND_TAB);
  manager_->ui()->OnPopupRequest(tab_, url, !background);
  return true;
}

void TabClient::OnAfterCreated(CefRefPtr<CefBrowser> browser) {
  if (manager_ && tab_) manager_->OnBrowserCreated(tab_, browser);
}

bool TabClient::DoClose(CefRefPtr<CefBrowser> browser) {
  // 回傳 false：由 CEF 繼續關閉流程，OnBeforeClose 會被呼叫
  closing_ = true;
  return false;
}

void TabClient::OnBeforeClose(CefRefPtr<CefBrowser> browser) {
  Tab* tab = tab_;
  tab_ = nullptr;
  if (manager_ && tab) manager_->OnBrowserClosed(tab);
  // 注意：此處之後不得再碰觸 manager_，因為最後一個分頁關閉時 UI 會解構。
}

// ---------------------------------------------------------------------------
//  RequestHandler
// ---------------------------------------------------------------------------
void TabClient::OnRenderProcessTerminated(CefRefPtr<CefBrowser> browser, TerminationStatus status,
                                         int error_code, const CefString& error_string) {
  if (browser && tab_) {
    // 與 Chrome 一致的「這個分頁已經重新載入」行為
    browser->ReloadIgnoreCache();
    NotifyChanged();
  }
}

// ---------------------------------------------------------------------------
//  ContextMenuHandler
// ---------------------------------------------------------------------------
void TabClient::OnBeforeContextMenu(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                                   CefRefPtr<CefContextMenuParams> params,
                                   CefRefPtr<CefMenuModel> model) {
  model->Clear();
  const bool can_back = browser && browser->CanGoBack();
  const bool can_forward = browser && browser->CanGoForward();

  model->AddItem(kCmdBack, CefString(L"上一頁"));
  model->SetEnabledAt(0, can_back);
  model->AddItem(kCmdForward, CefString(L"下一頁"));
  model->SetEnabledAt(1, can_forward);
  model->AddItem(kCmdReload, CefString(L"重新載入"));

  const bool editable = params && params->IsEditable();
  const bool has_selection = params && !params->GetSelectionText().empty();
  model->AddSeparator();
  model->AddItem(kCmdCut, CefString(L"剪下"));
  model->SetEnabledAt(4, editable && has_selection);
  model->AddItem(kCmdCopy, CefString(L"複製"));
  model->SetEnabledAt(5, has_selection || editable);
  model->AddItem(kCmdPaste, CefString(L"貼上"));
  model->SetEnabledAt(6, editable);
  model->AddItem(kCmdSelectAll, CefString(L"全選"));
  model->SetEnabledAt(7, true);

  model->AddSeparator();
  model->AddItem(kCmdViewSource, CefString(L"檢視網頁原始碼"));
  model->AddItem(kCmdPrint, CefString(L"列印…"));
}

bool TabClient::RunContextMenu(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                               CefRefPtr<CefContextMenuParams> params,
                               CefRefPtr<CefMenuModel> model,
                               CefRefPtr<CefRunContextMenuCallback> callback) {
  if (!manager_ || !tab_ || !callback) return false;
  manager_->ui()->OnContextMenuRequested(tab_, model, callback);
  return true;
}

bool TabClient::OnContextMenuCommand(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                                     CefRefPtr<CefContextMenuParams> params, int command_id,
                                     EventFlags event_flags) {
  if (!frame) return false;
  switch (command_id) {
    case kCmdBack:      if (browser) browser->GoBack(); return true;
    case kCmdForward:   if (browser) browser->GoForward(); return true;
    case kCmdReload:    if (browser) browser->Reload(); return true;
    case kCmdCopy:      frame->Copy(); return true;
    case kCmdCut:       frame->Cut(); return true;
    case kCmdPaste:     frame->Paste(); return true;
    case kCmdSelectAll: frame->SelectAll(); return true;
    case kCmdViewSource: {
      if (manager_) {
        manager_->ui()->OnPopupRequest(tab_, L"view-source:" + frame->GetURL().ToWString(), true);
      }
      return true;
    }
    case kCmdPrint: if (browser) browser->GetHost()->Print(); return true;
    default: break;
  }
  return false;
}

// ---------------------------------------------------------------------------
//  DownloadHandler — 下載一律落在 ./browser_data/downloads
// ---------------------------------------------------------------------------
bool TabClient::OnBeforeDownload(CefRefPtr<CefBrowser> browser,
                                CefRefPtr<CefDownloadItem> download_item,
                                const CefString& suggested_name,
                                CefRefPtr<CefBeforeDownloadCallback> callback) {
  if (!callback) return false;
  std::wstring name = suggested_name.ToWString();
  if (name.empty() && download_item) {
    name = download_item->GetSuggestedFileName().ToWString();
  }
  name = SanitizeFileName(name);

  std::wstring target = JoinPath(PortablePaths::DownloadsDir(), name);
  // 同名檔案自動加序號
  int counter = 1;
  const size_t dot = name.find_last_of(L'.');
  const std::wstring stem = dot == std::wstring::npos ? name : name.substr(0, dot);
  const std::wstring ext = dot == std::wstring::npos ? std::wstring() : name.substr(dot);
  while (FileExists(target)) {
    target = JoinPath(PortablePaths::DownloadsDir(),
                      stem + L" (" + std::to_wstring(counter++) + L")" + ext);
  }
  callback->Continue(CefString(target), false);   // false = 不顯示另存新檔對話框
  return true;
}

void TabClient::OnDownloadUpdated(CefRefPtr<CefBrowser> browser,
                                 CefRefPtr<CefDownloadItem> download_item,
                                 CefRefPtr<CefDownloadItemCallback> callback) {
  if (!manager_ || !tab_ || !download_item) return;
  if (download_item->IsComplete()) {
    manager_->ui()->OnStatusMessage(tab_, L"下載完成：" + download_item->GetFullPath().ToWString());
  } else if (download_item->IsInProgress()) {
    manager_->ui()->OnStatusMessage(
        tab_, L"下載中 " + std::to_wstring(download_item->GetPercentComplete()) + L"%");
  } else if (download_item->IsCanceled()) {
    manager_->ui()->OnStatusMessage(tab_, L"下載已取消");
  }
}

}  // namespace lumen
