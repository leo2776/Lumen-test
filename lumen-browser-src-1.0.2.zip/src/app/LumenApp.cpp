#include "app/LumenApp.h"

#include "app/MessagePump.h"
#include "core/PortablePaths.h"
#include "util/WinUtil.h"

#include "include/cef_command_line.h"

namespace lumen {

LumenApp::LumenApp() = default;

// ---------------------------------------------------------------------------
//  ★ 可攜性的第二道防線 ★
//  即使 CefSettings 已經指定路徑，Chromium 內部仍有許多路徑來自命令列
//  開關 (而且會被 renderer / gpu / utility 子行程沿用)。這裡把所有
//  「會寫檔」的開關全部釘死在 ./browser_data 之下。
// ---------------------------------------------------------------------------
void LumenApp::OnBeforeCommandLineProcessing(const CefString& process_type,
                                            CefRefPtr<CefCommandLine> command_line) {
  if (!command_line) return;

  const std::wstring profile = PortablePaths::ProfileDir();
  const std::wstring cache = PortablePaths::CacheDir();
  const std::wstring crash = PortablePaths::CrashDir();
  const std::wstring logs = PortablePaths::LogDir();

  if (!profile.empty()) {
    command_line->AppendSwitchWithValue("user-data-dir", ToUtf8(profile));
  }
  if (!cache.empty()) {
    command_line->AppendSwitchWithValue("disk-cache-dir", ToUtf8(cache));
    command_line->AppendSwitchWithValue("gpu-shader-cache-dir", ToUtf8(JoinPath(cache, L"gpu")));
  }
  if (!crash.empty()) {
    command_line->AppendSwitchWithValue("crash-dumps-dir", ToUtf8(crash));
    command_line->AppendSwitchWithValue("database", ToUtf8(JoinPath(crash, L"db")));
  }
  command_line->AppendSwitchWithValue("log-file", ToUtf8(PortablePaths::LogFile(L"cef.log")));
  (void)logs;

  // 不產生任何系統層級副作用 / 不打擾使用者的開關
  command_line->AppendSwitch("no-first-run");
  command_line->AppendSwitch("no-default-browser-check");
  command_line->AppendSwitch("disable-component-update");
  command_line->AppendSwitch("disable-background-networking");
  command_line->AppendSwitch("disable-sync");
  command_line->AppendSwitch("disable-domain-reliability");
  command_line->AppendSwitch("disable-breakpad");           // crash 由 CEF 內部紀錄即可
  command_line->AppendSwitch("disable-client-side-phishing-detection");
  command_line->AppendSwitch("disable-extensions");
  command_line->AppendSwitch("disable-plugins-discovery");
  command_line->AppendSwitch("disable-prompt-on-repost");
  command_line->AppendSwitch("no-pings");
  command_line->AppendSwitch("metrics-recording-only");
  command_line->AppendSwitchWithValue("force-color-profile", "srgb");
  command_line->AppendSwitch("disable-features", "Translate,MediaRouter,OptimizationHints");
}

void LumenApp::OnContextInitialized() {
  // Browser 程序已就緒。真正的視窗由 main.cpp 在 CefInitialize 回傳後建立，
  // 這樣 UI 物件生命週期完全由我們掌控。
}

void LumenApp::OnScheduleMessagePumpWork(int64_t delay_ms) {
  ScheduleExternalPumpWork(delay_ms);
}

}  // namespace lumen
