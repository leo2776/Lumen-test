// ===========================================================================
//  Lumen Browser — app/MessagePump.h
//  CEF 外部訊息幫浦 (External Message Pump)。
//
//  Lumen 採用「單執行緒訊息迴圈」模式：
//    settings.external_message_pump = true
//    settings.multi_threaded_message_loop = false
//  也就是 CEF 的 UI 執行緒 == 我們的 Win32 UI 執行緒，因此所有
//  RenderHandler / LifeSpanHandler 回呼都在同一執行緒，免去鎖與跨執行緒
//  繪製的複雜度。CEF 需要工作時會呼叫 OnScheduleMessagePumpWork()，
//  我們把請求轉成對隱藏訊息視窗的 PostMessage / SetTimer，由主迴圈處理。
// ===========================================================================
#pragma once

#include "core/Platform.h"

namespace lumen {

void InstallExternalPump(HWND pump_window);
void ScheduleExternalPumpWork(int64_t delay_ms);
void ShutdownExternalPump();

}  // namespace lumen
