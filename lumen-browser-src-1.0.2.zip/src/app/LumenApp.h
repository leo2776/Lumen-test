// ===========================================================================
//  Lumen Browser — app/LumenApp.h
//  CefApp 實作：命令列開關 (可攜性關鍵) 與 BrowserProcessHandler。
// ===========================================================================
#pragma once

#include "core/Platform.h"

#include "include/cef_app.h"
#include "include/cef_browser_process_handler.h"

namespace lumen {

class LumenApp : public CefApp, public CefBrowserProcessHandler {
 public:
  LumenApp();

  // CefApp
  CefRefPtr<CefBrowserProcessHandler> GetBrowserProcessHandler() override { return this; }
  void OnBeforeCommandLineProcessing(const CefString& process_type,
                                     CefRefPtr<CefCommandLine> command_line) override;

  // CefBrowserProcessHandler
  void OnContextInitialized() override;
  void OnScheduleMessagePumpWork(int64_t delay_ms) override;

 private:
  IMPLEMENT_REFCOUNTING(LumenApp);
};

}  // namespace lumen
