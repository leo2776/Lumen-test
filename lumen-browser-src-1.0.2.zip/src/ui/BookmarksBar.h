// ===========================================================================
//  Lumen Browser — ui/BookmarksBar.h
//  書籤列：Direct2D 自繪的膠囊按鈕，點擊即導覽。
// ===========================================================================
#pragma once

#include "core/BookmarkStore.h"
#include "core/Platform.h"
#include "ui/Theme.h"

#include <d2d1.h>

namespace lumen {

class BookmarksBar {
 public:
  void SetItems(const std::vector<Bookmark>& items);
  void SetHover(int index) { hover_ = index; }
  void Layout(const D2D1_RECT_F& area);
  int HitTest(D2D1_POINT_2F point) const;   // -1 表示未命中

  void Paint(ID2D1RenderTarget* rt, const Theme& theme) const;

  const std::vector<Bookmark>& items() const { return items_; }
  const D2D1_RECT_F& area() const { return area_; }

 private:
  std::vector<Bookmark> items_;
  std::vector<D2D1_RECT_F> chips_;
  D2D1_RECT_F area_{};
  int hover_ = -1;
};

}  // namespace lumen
