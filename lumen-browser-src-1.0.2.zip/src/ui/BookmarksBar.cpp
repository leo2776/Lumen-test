#include "ui/BookmarksBar.h"

#include "ui/Gfx.h"

#include <d2d1helper.h>

namespace lumen {
namespace {
constexpr float kChipHeight = 24.0f;
constexpr float kChipPaddingX = 10.0f;
constexpr float kChipGap = 2.0f;
constexpr float kLeading = 8.0f;
}  // namespace

void BookmarksBar::SetItems(const std::vector<Bookmark>& items) {
  items_ = items;
  chips_.assign(items_.size(), D2D1_RECT_F{});
  if (hover_ >= (int)items_.size()) hover_ = -1;
}

void BookmarksBar::Layout(const D2D1_RECT_F& area) {
  area_ = area;
  chips_.assign(items_.size(), D2D1_RECT_F{});

  const float top = (area.top + area.bottom) * 0.5f - kChipHeight * 0.5f;
  const float bottom = top + kChipHeight;
  float x = area.left + kLeading;

  for (size_t i = 0; i < items_.size(); ++i) {
    const std::wstring label = items_[i].title.empty() ? items_[i].url : items_[i].title;
    float width = MeasureText(label, FontRole::UI) + kChipPaddingX * 2.0f;
    if (width < 48.0f) width = 48.0f;
    if (width > 220.0f) width = 220.0f;
    if (x + width > area.right - 8.0f) {
      // 超出寬度就不再排版 (其餘書籤保留資料，只是不顯示)
      chips_[i] = D2D1::RectF(0, 0, 0, 0);
      x += width + kChipGap;
      continue;
    }
    chips_[i] = D2D1::RectF(x, top, x + width, bottom);
    x += width + kChipGap;
  }
}

int BookmarksBar::HitTest(D2D1_POINT_2F point) const {
  for (size_t i = 0; i < chips_.size(); ++i) {
    const D2D1_RECT_F& r = chips_[i];
    if (r.right <= r.left) continue;
    if (point.x >= r.left && point.x <= r.right && point.y >= r.top && point.y <= r.bottom) {
      return (int)i;
    }
  }
  return -1;
}

void BookmarksBar::Paint(ID2D1RenderTarget* rt, const Theme& theme) const {
  if (!rt) return;
  for (size_t i = 0; i < chips_.size() && i < items_.size(); ++i) {
    const D2D1_RECT_F& r = chips_[i];
    if (r.right <= r.left) continue;

    if ((int)i == hover_) {
      FillRoundedRect(rt, r, 6.0f, theme.button_hover);
    }
    const std::wstring label = items_[i].title.empty() ? items_[i].url : items_[i].title;
    DrawTextClipped(rt, label, FontRole::UI,
                    D2D1::RectF(r.left + kChipPaddingX, r.top, r.right - kChipPaddingX, r.bottom),
                    theme.text, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
                    true);
  }
}

}  // namespace lumen
