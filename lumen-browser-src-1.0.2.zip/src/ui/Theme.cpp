#include "ui/Theme.h"

#include <d2d1helper.h>

namespace lumen {
namespace {
inline D2D1_COLOR_F Hex(unsigned int rgb, float a = 1.0f) {
  return D2D1::ColorF((UINT32)rgb, a);
}
}  // namespace

Theme Theme::Dark() {
  Theme t;
  t.dark = true;
  t.frame_background  = Hex(0x202124);
  t.tab_active        = Hex(0x35363A);
  t.tab_inactive      = Hex(0x202124);
  t.tab_hover         = Hex(0x2C2D31);
  t.toolbar           = Hex(0x35363A);
  t.toolbar_separator = Hex(0x202124);
  t.omnibox           = Hex(0x202124);
  t.omnibox_hover     = Hex(0x292A2D);
  t.omnibox_focus     = Hex(0x202124);
  t.omnibox_border    = Hex(0x5F6368);
  t.button_hover      = Hex(0x4A4B4F);
  t.text              = Hex(0xE8EAED);
  t.text_secondary    = Hex(0x9AA0A6);
  t.text_disabled     = Hex(0x5F6368);
  t.icon              = Hex(0xE8EAED);
  t.accent            = Hex(0x8AB4F8);
  t.danger            = Hex(0xC5221F);
  t.menu_background   = Hex(0x292A2D);
  t.menu_hover        = Hex(0x3C4043);
  t.menu_border       = Hex(0x3C4043);
  t.web_backdrop      = Hex(0x202124);
  t.caption_hover     = Hex(0x3C4043);
  t.caption_close_hover = Hex(0xC42B1C);
  return t;
}

Theme Theme::Light() {
  Theme t;
  t.dark = false;
  t.frame_background  = Hex(0xE8EAED);
  t.tab_active        = Hex(0xFFFFFF);
  t.tab_inactive      = Hex(0xE8EAED);
  t.tab_hover         = Hex(0xF1F3F4);
  t.toolbar           = Hex(0xFFFFFF);
  t.toolbar_separator = Hex(0xDADCE0);
  t.omnibox           = Hex(0xF1F3F4);
  t.omnibox_hover     = Hex(0xE8EAED);
  t.omnibox_focus     = Hex(0xFFFFFF);
  t.omnibox_border    = Hex(0xBDC1C6);
  t.button_hover      = Hex(0xE8EAED);
  t.text              = Hex(0x202124);
  t.text_secondary    = Hex(0x5F6368);
  t.text_disabled     = Hex(0xBDC1C6);
  t.icon              = Hex(0x5F6368);
  t.accent            = Hex(0x1A73E8);
  t.danger            = Hex(0xD93025);
  t.menu_background   = Hex(0xFFFFFF);
  t.menu_hover        = Hex(0xF1F3F4);
  t.menu_border       = Hex(0xDADCE0);
  t.web_backdrop      = Hex(0xFFFFFF);
  t.caption_hover     = Hex(0xE8EAED);
  t.caption_close_hover = Hex(0xC42B1C);
  return t;
}

}  // namespace lumen
