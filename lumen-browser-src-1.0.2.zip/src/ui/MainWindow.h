// ===========================================================================
//  Lumen Browser — ui/MainWindow.h
//  自研主視窗：無邊框 (custom frame) + Direct2D 繪製的分頁列 / 網址列 /
//  書籤列 / 視窗按鈕 / 狀態列，並把 CEF 的離屏畫面合成進來。
// ===========================================================================
#pragma once

#include "core/AppConfig.h"
#include "core/BookmarkStore.h"
#include "core/BrowserUI.h"
#include "core/HistoryStore.h"
#include "core/Platform.h"
#include "core/TabManager.h"
#include "ui/BookmarksBar.h"
#include "ui/Omnibox.h"
#include "ui/PopupMenu.h"
#include "ui/TabStrip.h"
#include "ui/Theme.h"

#include "include/cef_browser.h"

#include <d2d1.h>

namespace lumen {

class MainWindow : public BrowserUI {
 public:
  MainWindow(HINSTANCE instance, AppConfig* config, HistoryStore* history,
             BookmarkStore* bookmarks);
  ~MainWindow() override;

  bool Create(int show_command);
  HWND hwnd() const { return hwnd_; }

  // 由命令列 (例如把檔案拖到 exe 上) 要求開啟的網址
  void OpenExternalUrl(const std::wstring& url) { NewTab(url, true); }

  // ---- BrowserUI --------------------------------------------------------
  HWND window_handle() override { return hwnd_; }
  void OnTabFrameReady(Tab* tab) override;
  void OnTabChanged(Tab* tab) override;
  void OnTabCreated(Tab* tab) override;
  void OnTabClosed(Tab* tab) override;
  void OnAllTabsClosed() override;
  void OnCursorChanged(HCURSOR cursor) override;
  void OnPopupRequest(Tab* source, const std::wstring& url, bool foreground) override;
  void OnStatusMessage(Tab* tab, const std::wstring& message) override;
  void OnContextMenuRequested(Tab* tab, CefRefPtr<CefMenuModel> model,
                              CefRefPtr<CefRunContextMenuCallback> callback) override;

 private:
  enum class Hover {
    None,
    Caption,
    Minimize,
    Maximize,
    Close,
    Tab,
    CloseTab,
    NewTab,
    Back,
    Forward,
    Reload,
    Home,
    Star,
    MenuButton,
    Bookmark,
    WebContent,
  };

  struct Layout {
    D2D1_RECT_F tab_strip{};
    D2D1_RECT_F tab_area{};          // 分頁列中「不含視窗按鈕」的可用區
    D2D1_RECT_F toolbar{};
    D2D1_RECT_F bookmarks{};
    D2D1_RECT_F content{};
    D2D1_RECT_F back{};
    D2D1_RECT_F forward{};
    D2D1_RECT_F reload{};
    D2D1_RECT_F home{};
    D2D1_RECT_F pill{};
    D2D1_RECT_F lock{};
    D2D1_RECT_F star{};
    D2D1_RECT_F menu_button{};
    D2D1_RECT_F btn_minimize{};
    D2D1_RECT_F btn_maximize{};
    D2D1_RECT_F btn_close{};
  };

  static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam);
  LRESULT HandleMessage(UINT message, WPARAM wparam, LPARAM lparam);

  // ---- 建構 / 佈局 ------------------------------------------------------
  void RecalcLayout();
  void ApplyTheme();
  void RebuildTabStrip();
  void SyncOmniboxWithActiveTab();
  bool ContentAreaContains(D2D1_POINT_2F dip) const;

  // ---- 繪製 -------------------------------------------------------------
  void EnsureRenderTarget();
  void ReleaseRenderTarget();
  void Paint();
  void PaintChrome(ID2D1RenderTarget* rt);
  void PaintContent(ID2D1RenderTarget* rt);
  void PaintToolbarButton(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, Icon icon, bool hovered,
                          bool enabled) const;
  void PaintCaptionButtons(ID2D1RenderTarget* rt) const;

  // ---- 互動 -------------------------------------------------------------
  Hover HitTestChrome(D2D1_POINT_2F dip, int* out_index) const;
  void OnMouseMove(POINT client_px, WPARAM flags);
  void OnMouseLeave();
  void OnLeftButtonDown(POINT client_px);
  void OnLeftButtonUp(POINT client_px);
  void OnRightButtonUp(POINT client_px);
  void OnMouseWheel(WPARAM wparam, POINT client_px);
  bool HandleShortcut(UINT key, bool ctrl, bool shift, bool alt);
  void ForwardKey(UINT message, WPARAM wparam, LPARAM lparam);
  void ForwardMouseMove(POINT client_px, CefBrowserHost::MouseButtonType button);
  void ForwardMouseButton(POINT client_px, CefBrowserHost::MouseButtonType button, bool up,
                          int click_count);
  bool FocusWebContent();
  int CurrentCefModifiers() const;
  D2D1_POINT_2F ClientPxToViewDip(POINT client_px) const;

  // ---- 動作 -------------------------------------------------------------
  void NewTab(const std::wstring& url = std::wstring(), bool foreground = true);
  void CloseTab(int index);
  void ActivateTab(int index);
  void NavigateFromOmnibox();
  void GoHome();
  void ToggleBookmark();
  void ToggleTheme();
  void ToggleBookmarksBar();
  void ShowMainMenu();
  void ShowBookmarkMenu(int index);
  void OpenInternalPage(const std::wstring& file_path);
  void ShowHistory();
  void ShowBookmarks();
  void OpenFolder(const std::wstring& path);
  void ShowAbout();
  void ToggleMaximize();
  void SaveWindowState();
  void BeginClose();
  void OnMenuCommand(int command_id);

  HINSTANCE instance_ = nullptr;
  HWND hwnd_ = nullptr;
  AppConfig* config_ = nullptr;
  HistoryStore* history_ = nullptr;
  BookmarkStore* bookmarks_ = nullptr;
  std::unique_ptr<TabManager> tabs_;

  Omnibox omnibox_;
  TabStrip tab_strip_;
  BookmarksBar bookmarks_bar_;
  std::unique_ptr<PopupMenu> menu_;

  Theme theme_;
  Layout layout_;
  int dpi_ = 96;
  float scale_ = 1.0f;

  ID2D1HwndRenderTarget* target_ = nullptr;
  ID2D1Bitmap* web_bitmap_ = nullptr;
  ID2D1Bitmap* popup_bitmap_ = nullptr;
  int web_bitmap_width_ = 0;
  int web_bitmap_height_ = 0;
  int popup_bitmap_width_ = 0;
  int popup_bitmap_height_ = 0;

  Hover hover_ = Hover::None;
  int hover_index_ = -1;
  D2D1_POINT_2F mouse_dip_{-1.0f, -1.0f};
  POINT last_mouse_px_{0, 0};
  bool mouse_in_content_ = false;
  bool tracking_leave_ = false;
  bool closing_ = false;
  bool shutting_down_ = false;

  HCURSOR custom_cursor_ = nullptr;
  HICON icon_big_ = nullptr;
  HICON icon_small_ = nullptr;

  std::wstring status_text_;
  std::wstring omnibox_display_url_;
  float spinner_phase_ = 0.0f;
  bool spinner_active_ = false;
};

}  // namespace lumen
