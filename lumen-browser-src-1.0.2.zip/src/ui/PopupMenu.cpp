#include "ui/PopupMenu.h"

#include "ui/Gfx.h"
#include "util/WinUtil.h"

#include <d2d1helper.h>
#include <windowsx.h>

namespace lumen {
namespace {

constexpr wchar_t kMenuClass[] = L"LumenPopupMenuWindow";
constexpr float kItemHeight = 32.0f;
constexpr float kSeparatorHeight = 9.0f;
constexpr float kPaddingY = 6.0f;
constexpr float kPaddingX = 14.0f;
constexpr float kMinWidth = 210.0f;

bool EnsureClassRegistered(HINSTANCE instance) {
  static bool registered = false;
  if (registered) return true;
  WNDCLASSEXW wc{};
  wc.cbSize = sizeof(wc);
  wc.style = CS_DROPSHADOW;
  wc.lpfnWndProc = PopupMenu::WndProc;
  wc.hInstance = instance;
  wc.hCursor = ::LoadCursorW(nullptr, IDC_ARROW);
  wc.lpszClassName = kMenuClass;
  if (!::RegisterClassExW(&wc) && ::GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return false;
  registered = true;
  return true;
}

}  // namespace

PopupMenu::PopupMenu(HWND owner) : owner_(owner) {}

PopupMenu::~PopupMenu() {
  if (target_) {
    target_->Release();
    target_ = nullptr;
  }
  if (hwnd_ && ::IsWindow(hwnd_)) ::DestroyWindow(hwnd_);
  hwnd_ = nullptr;
}

int PopupMenu::Track(POINT screen_point, const std::vector<MenuItem>& items, const Theme& theme) {
  items_ = items;
  theme_ = theme;
  dpi_ = DpiForWindow(owner_);
  hover_ = -1;
  selected_ = -1;
  result_ = 0;

  HINSTANCE instance = ::GetModuleHandleW(nullptr);
  if (!EnsureClassRegistered(instance)) return 0;

  // ---- 量測尺寸 (DIP -> px) -------------------------------------------
  float label_width = 0.0f;
  float shortcut_width = 0.0f;
  float height_dip = kPaddingY * 2.0f;
  for (const auto& item : items_) {
    if (item.separator) {
      height_dip += kSeparatorHeight;
      continue;
    }
    height_dip += kItemHeight;
    label_width = std::max(label_width, MeasureText(item.label, FontRole::Menu));
    if (!item.shortcut.empty()) {
      shortcut_width = std::max(shortcut_width, MeasureText(item.shortcut, FontRole::Small));
    }
  }
  float width_dip = std::max(kMinWidth, label_width + shortcut_width + kPaddingX * 2.0f + 46.0f);
  width_px_ = (UINT)ScaleDip((int)std::ceil(width_dip), dpi_);
  height_px_ = (UINT)ScaleDip((int)std::ceil(height_dip), dpi_);

  // ---- 位置：避開螢幕邊界 ---------------------------------------------
  POINT position = screen_point;
  HMONITOR monitor = ::MonitorFromPoint(screen_point, MONITOR_DEFAULTTONEAREST);
  MONITORINFO info{};
  info.cbSize = sizeof(info);
  if (::GetMonitorInfoW(monitor, &info)) {
    const RECT& work = info.rcWork;
    if (position.x + (LONG)width_px_ > work.right) position.x = work.right - (LONG)width_px_;
    if (position.y + (LONG)height_px_ > work.bottom) {
      position.y = work.bottom - (LONG)height_px_;
    }
    if (position.x < work.left) position.x = work.left;
    if (position.y < work.top) position.y = work.top;
  }

  hwnd_ = ::CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, kMenuClass, L"", WS_POPUP,
                            position.x, position.y, (int)width_px_, (int)height_px_, owner_,
                            nullptr, instance, this);
  if (!hwnd_) return 0;

  RebuildLayout();
  ::ShowWindow(hwnd_, SW_SHOWNORMAL);
  ::SetForegroundWindow(hwnd_);
  ::SetFocus(hwnd_);
  ::InvalidateRect(hwnd_, nullptr, FALSE);

  // ---- 巢狀訊息迴圈 (與 TrackPopupMenu 等價的行為) ---------------------
  activated_ = (::GetForegroundWindow() == hwnd_);
  running_ = true;
  MSG message;
  while (running_ && ::GetMessageW(&message, nullptr, 0, 0)) {
    if (message.message == WM_QUIT) {
      ::PostQuitMessage((int)message.wParam);
      running_ = false;
      break;
    }
    ::TranslateMessage(&message);
    ::DispatchMessageW(&message);
  }
  if (running_) running_ = false;

  if (hwnd_ && ::IsWindow(hwnd_)) {
    ::DestroyWindow(hwnd_);
  }
  hwnd_ = nullptr;
  if (target_) {
    target_->Release();
    target_ = nullptr;
  }
  return result_;
}

void PopupMenu::RebuildLayout() {
  item_rects_.assign(items_.size(), D2D1_RECT_F{});
  float y = kPaddingY;
  const float width_dip = (float)width_px_ * 96.0f / (float)dpi_;
  for (size_t i = 0; i < items_.size(); ++i) {
    if (items_[i].separator) {
      item_rects_[i] = D2D1::RectF(0.0f, y + kSeparatorHeight * 0.5f, width_dip,
                                   y + kSeparatorHeight * 0.5f);
      y += kSeparatorHeight;
    } else {
      item_rects_[i] = D2D1::RectF(4.0f, y, width_dip - 4.0f, y + kItemHeight);
      y += kItemHeight;
    }
  }
}

int PopupMenu::HitTestItem(POINT client_point) const {
  const float x = (float)client_point.x * 96.0f / (float)dpi_;
  const float y = (float)client_point.y * 96.0f / (float)dpi_;
  for (size_t i = 0; i < item_rects_.size(); ++i) {
    const D2D1_RECT_F& r = item_rects_[i];
    if (items_[i].separator) continue;
    if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return (int)i;
  }
  return -1;
}

void PopupMenu::Dismiss(int result) {
  result_ = result;
  running_ = false;
}

void PopupMenu::Paint() {
  if (!hwnd_) return;
  RECT client{};
  ::GetClientRect(hwnd_, &client);

  if (!target_) {
    ID2D1Factory* factory = Gfx::Get().d2d();
    if (!factory) return;
    const D2D1_RENDER_TARGET_PROPERTIES props = D2D1::RenderTargetProperties();
    const D2D1_HWND_RENDER_TARGET_PROPERTIES hwnd_props = D2D1::HwndRenderTargetProperties(
        hwnd_, D2D1::SizeU((UINT32)client.right, (UINT32)client.bottom));
    if (FAILED(factory->CreateHwndRenderTarget(props, hwnd_props, &target_)) || !target_) return;
  }

  target_->SetDpi((float)dpi_, (float)dpi_);
  target_->BeginDraw();
  target_->Clear(theme_.menu_background);

  const float width_dip = (float)client.right * 96.0f / (float)dpi_;
  const float height_dip = (float)client.bottom * 96.0f / (float)dpi_;

  for (size_t i = 0; i < items_.size() && i < item_rects_.size(); ++i) {
    const MenuItem& item = items_[i];
    const D2D1_RECT_F& r = item_rects_[i];

    if (item.separator) {
      DrawLine(target_, D2D1::Point2F(kPaddingX, r.top), D2D1::Point2F(width_dip - kPaddingX, r.top),
               theme_.menu_border, 1.0f);
      continue;
    }

    const bool is_hover = ((int)i == hover_) || ((int)i == selected_);
    if (is_hover && item.enabled) {
      FillRoundedRect(target_, r, 5.0f, theme_.menu_hover);
    }

    const D2D1_COLOR_F color = item.enabled ? theme_.text : theme_.text_disabled;
    float text_left = r.left + kPaddingX;
    if (item.checked) {
      DrawIcon(target_, Icon::Close, D2D1::RectF(text_left, r.top + 10.0f, text_left + 12.0f,
                                                 r.top + 22.0f),
               theme_.accent, 1.6f);
    }
    text_left += 4.0f;
    DrawTextClipped(target_, item.label, FontRole::Menu,
                    D2D1::RectF(text_left, r.top, r.right - 60.0f, r.bottom), color,
                    DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, true);

    if (!item.shortcut.empty()) {
      DrawTextClipped(target_, item.shortcut, FontRole::Small,
                      D2D1::RectF(r.right - 60.0f - kPaddingX, r.top, r.right - kPaddingX, r.bottom),
                      theme_.text_secondary, DWRITE_TEXT_ALIGNMENT_TRAILING,
                      DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
    }
  }

  StrokeRoundedRect(target_, D2D1::RectF(0.5f, 0.5f, width_dip - 0.5f, height_dip - 0.5f), 6.0f,
                    theme_.menu_border, 1.0f);

  const HRESULT hr = target_->EndDraw();
  if (hr == D2DERR_RECREATE_TARGET && target_) {
    target_->Release();
    target_ = nullptr;
  }
}

LRESULT CALLBACK PopupMenu::WndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam) {
  PopupMenu* self = reinterpret_cast<PopupMenu*>(::GetWindowLongPtrW(hwnd, GWLP_USERDATA));
  if (message == WM_NCCREATE) {
    auto* create = reinterpret_cast<CREATESTRUCTW*>(lparam);
    self = reinterpret_cast<PopupMenu*>(create->lpCreateParams);
    ::SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
    if (self) self->hwnd_ = hwnd;
  }
  if (self) return self->HandleMessage(message, wparam, lparam);
  return ::DefWindowProcW(hwnd, message, wparam, lparam);
}

LRESULT PopupMenu::HandleMessage(UINT message, WPARAM wparam, LPARAM lparam) {
  switch (message) {
    case WM_ERASEBKGND:
      return 1;

    case WM_PAINT: {
      PAINTSTRUCT ps;
      ::BeginPaint(hwnd_, &ps);
      Paint();
      ::EndPaint(hwnd_, &ps);
      return 0;
    }

    case WM_MOUSEMOVE: {
      const POINT point{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      const int index = HitTestItem(point);
      if (index != hover_) {
        hover_ = index;
        selected_ = -1;
        ::InvalidateRect(hwnd_, nullptr, FALSE);
      }
      return 0;
    }

    case WM_LBUTTONUP: {
      const POINT point{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      const int index = HitTestItem(point);
      if (index >= 0 && index < (int)items_.size() && items_[index].enabled) {
        Dismiss(items_[index].id);
      } else {
        Dismiss(0);
      }
      return 0;
    }

    case WM_RBUTTONUP:
    case WM_MBUTTONUP:
      Dismiss(0);
      return 0;

    case WM_KEYDOWN: {
      const int count = (int)items_.size();
      if (wparam == VK_ESCAPE) {
        Dismiss(0);
        return 0;
      }
      if (wparam == VK_RETURN) {
        if (selected_ >= 0 && selected_ < count && items_[selected_].enabled) {
          Dismiss(items_[selected_].id);
        }
        return 0;
      }
      if (wparam == VK_DOWN || wparam == VK_UP) {
        const int step = (wparam == VK_DOWN) ? 1 : -1;
        int index = selected_;
        for (int guard = 0; guard < count + 1; ++guard) {
          index += step;
          if (index < 0) index = count - 1;
          if (index >= count) index = 0;
          if (!items_[index].separator && items_[index].enabled) {
            selected_ = index;
            hover_ = -1;
            ::InvalidateRect(hwnd_, nullptr, FALSE);
            break;
          }
        }
        return 0;
      }
      return 0;
    }

    case WM_ACTIVATE:
      if (LOWORD(wparam) == WA_INACTIVE) {
        // 只有在選單確實取得前景後才因失焦關閉，
        // 避免 SetForegroundWindow 被系統拒絕時選單一閃即關。
        if (activated_) Dismiss(0);
      } else {
        activated_ = true;
      }
      return 0;

    case WM_KILLFOCUS:
      if (activated_ && !::IsChild(hwnd_, (HWND)wparam)) {
        Dismiss(0);
      }
      return 0;

    case WM_MOUSEACTIVATE:
      return MA_ACTIVATE;

    case WM_DESTROY:
      if (target_) {
        target_->Release();
        target_ = nullptr;
      }
      return 0;

    default:
      break;
  }
  return ::DefWindowProcW(hwnd_, message, wparam, lparam);
}

}  // namespace lumen
