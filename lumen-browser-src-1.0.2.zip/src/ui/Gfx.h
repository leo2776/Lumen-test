// ===========================================================================
//  Lumen Browser — ui/Gfx.h
//  Direct2D / DirectWrite 繪圖層。整個自研 UI (分頁列、網址列、書籤列、
//  選單、視窗按鈕、App 圖示) 都靠這一層繪製，完全不使用任何 UI 框架。
// ===========================================================================
#pragma once

#include "core/Platform.h"

#include <d2d1.h>
#include <dwrite.h>

namespace lumen {

enum class FontRole {
  UI = 0,        // 一般 UI 文字
  UIBold,        // 粗體 (分頁標題、選單強調)
  Omnibox,       // 網址列 (稍大)
  Tab,           // 分頁標題
  Menu,          // 選單項目
  Small,         // 提示 / 狀態
  Heading,       // 內建頁面標題
  Count
};

enum class Icon {
  Back,
  Forward,
  Reload,
  Home,
  Star,
  StarFilled,
  Plus,
  Close,
  MenuDots,
  Lock,
  Search,
  Download,
  Globe,
  Minimize,
  Maximize,
  Restore,
};

class Gfx {
 public:
  static Gfx& Get();

  bool Initialize();
  void Shutdown();

  ID2D1Factory* d2d() const { return d2d_; }
  IDWriteFactory* dwrite() const { return dwrite_; }
  IDWriteTextFormat* Font(FontRole role) const { return fonts_[(int)role]; }

 private:
  Gfx() = default;
  ~Gfx() = default;
  Gfx(const Gfx&) = delete;
  Gfx& operator=(const Gfx&) = delete;

  ID2D1Factory* d2d_ = nullptr;
  IDWriteFactory* dwrite_ = nullptr;
  IDWriteTextFormat* fonts_[(int)FontRole::Count] = {nullptr};
};

// ---- 繪圖小工具 ----------------------------------------------------------
void FillRect(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, const D2D1_COLOR_F& color);
void FillRoundedRect(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, float radius,
                     const D2D1_COLOR_F& color);
void StrokeRoundedRect(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, float radius,
                       const D2D1_COLOR_F& color, float stroke_width = 1.0f);
void FillCircle(ID2D1RenderTarget* rt, D2D1_POINT_2F center, float radius,
                const D2D1_COLOR_F& color);

void DrawLine(ID2D1RenderTarget* rt, D2D1_POINT_2F a, D2D1_POINT_2F b,
              const D2D1_COLOR_F& color, float width = 1.0f);

void DrawIcon(ID2D1RenderTarget* rt, Icon icon, const D2D1_RECT_F& box, const D2D1_COLOR_F& color,
              float stroke_width = 1.6f);

void DrawTextClipped(ID2D1RenderTarget* rt, const std::wstring& text, FontRole role,
                     const D2D1_RECT_F& box, const D2D1_COLOR_F& color,
                     DWRITE_TEXT_ALIGNMENT align = DWRITE_TEXT_ALIGNMENT_LEADING,
                     DWRITE_PARAGRAPH_ALIGNMENT paragraph = DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
                     bool ellipsis = true);

void DrawTextRaw(ID2D1RenderTarget* rt, const std::wstring& text, IDWriteTextFormat* format,
                 const D2D1_RECT_F& box, const D2D1_COLOR_F& color,
                 DWRITE_TEXT_ALIGNMENT align = DWRITE_TEXT_ALIGNMENT_LEADING);

// 量測單行文字寬度 (DIP)，用於書籤列/選單的自適應排版
float MeasureText(const std::wstring& text, FontRole role, float max_width = 4096.0f);

// 執行時用 Direct2D 產生多尺寸 App 圖示 (純 C++，不需要 .ico 資源檔)
HICON CreateAppIcon(int size_px, bool dark = true);

}  // namespace lumen
