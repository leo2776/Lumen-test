#include "ui/Omnibox.h"

#include "util/WinUtil.h"

#include <commctrl.h>

#pragma comment(lib, "comctl32.lib")

namespace lumen {
namespace {
constexpr UINT_PTR kSubclassId = 0x4F4D4E42;   // 'OMNB'
}

void Omnibox::Create(HWND parent, HINSTANCE instance) {
  parent_ = parent;
  dpi_ = DpiForWindow(parent);

  edit_ = ::CreateWindowExW(
      0, L"EDIT", L"",
      WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL | ES_NOHIDESEL,
      0, 0, 10, 10, parent, nullptr, instance, nullptr);
  if (!edit_) return;

  ::SendMessageW(edit_, EM_SETMARGINS, EC_LEFTMARGIN | EC_RIGHTMARGIN, MAKELONG(0, 4));
  // 原生 cue banner (灰字提示)
  ::SendMessageW(edit_, EM_SETCUEBANNER, TRUE, (LPARAM)L"搜尋 Google 或輸入網址");

  RecreateFont(dpi_);
  SetWindowSubclass(edit_, &Omnibox::SubclassProc, kSubclassId, (DWORD_PTR)this);
}

void Omnibox::Destroy() {
  if (font_) {
    ::DeleteObject(font_);
    font_ = nullptr;
  }
  if (brush_) {
    ::DeleteObject(brush_);
    brush_ = nullptr;
  }
  if (edit_) {
    RemoveWindowSubclass(edit_, &Omnibox::SubclassProc, kSubclassId);
    ::DestroyWindow(edit_);
    edit_ = nullptr;
  }
}

void Omnibox::RecreateFont(int dpi) {
  if (!edit_) return;
  if (font_) ::DeleteObject(font_);
  LOGFONTW lf{};
  lf.lfHeight = -::MulDiv(13, dpi, 96);
  lf.lfWeight = FW_NORMAL;
  lf.lfCharSet = DEFAULT_CHARSET;
  lf.lfQuality = CLEARTYPE_QUALITY;
  ::wcscpy_s(lf.lfFaceName, L"Segoe UI");
  font_ = ::CreateFontIndirectW(&lf);
  if (font_) ::SendMessageW(edit_, WM_SETFONT, (WPARAM)font_, TRUE);
}

void Omnibox::SetBoundsPx(const RECT& rect_px) {
  if (!edit_) return;
  ::SetWindowPos(edit_, nullptr, rect_px.left, rect_px.top, rect_px.right - rect_px.left,
                 rect_px.bottom - rect_px.top, SWP_NOZORDER | SWP_NOACTIVATE);
}

void Omnibox::ApplyTheme(const Theme& theme, int dpi) {
  if (dpi != dpi_) {
    dpi_ = dpi;
    RecreateFont(dpi_);
  }
  text_color_ = RGB((int)(theme.text.r * 255.0f), (int)(theme.text.g * 255.0f),
                    (int)(theme.text.b * 255.0f));
  background_color_ = RGB((int)(theme.omnibox.r * 255.0f), (int)(theme.omnibox.g * 255.0f),
                          (int)(theme.omnibox.b * 255.0f));
  if (brush_) ::DeleteObject(brush_);
  brush_ = ::CreateSolidBrush(background_color_);
  if (edit_) ::InvalidateRect(edit_, nullptr, TRUE);
}

void Omnibox::SetText(const std::wstring& text, bool select_all) {
  if (!edit_) return;
  ::SetWindowTextW(edit_, text.c_str());
  if (select_all) {
    ::SendMessageW(edit_, EM_SETSEL, 0, -1);
  } else {
    ::SendMessageW(edit_, EM_SETSEL, (WPARAM)text.size(), (LPARAM)text.size());
  }
}

std::wstring Omnibox::GetText() const {
  if (!edit_) return std::wstring();
  const int length = ::GetWindowTextLengthW(edit_);
  if (length <= 0) return std::wstring();
  std::wstring buffer((size_t)length + 1, L'\0');
  const int copied = ::GetWindowTextW(edit_, &buffer[0], length + 1);
  buffer.resize(copied > 0 ? (size_t)copied : 0);
  return buffer;
}

void Omnibox::FocusAndSelectAll() {
  if (!edit_) return;
  ::SetFocus(edit_);
  ::SendMessageW(edit_, EM_SETSEL, 0, -1);
}

LRESULT CALLBACK Omnibox::SubclassProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam,
                                       UINT_PTR subclass_id, DWORD_PTR ref_data) {
  auto* self = reinterpret_cast<Omnibox*>(ref_data);
  if (!self) return ::DefSubclassProc(hwnd, message, wparam, lparam);

  switch (message) {
    case WM_KEYDOWN: {
      if (self->on_pre_key && self->on_pre_key(message, wparam, lparam)) return 0;
      if (wparam == VK_RETURN) {
        if (self->on_submit) self->on_submit(self->GetText());
        return 0;
      }
      if (wparam == VK_ESCAPE) {
        if (self->on_cancel) self->on_cancel();
        return 0;
      }
      break;
    }
    case WM_CHAR: {
      // 吃掉 Enter/ESC 造成的系統提示音
      if (wparam == VK_RETURN || wparam == VK_ESCAPE || wparam == 7) return 0;
      break;
    }
    case WM_SETFOCUS: {
      self->focused_ = true;
      // 聚焦時通知父視窗重繪膠囊外觀
      ::InvalidateRect(::GetParent(hwnd), nullptr, FALSE);
      if (self->on_focus_changed) self->on_focus_changed(true);
      break;
    }
    case WM_KILLFOCUS: {
      self->focused_ = false;
      ::InvalidateRect(::GetParent(hwnd), nullptr, FALSE);
      if (self->on_focus_changed) self->on_focus_changed(false);
      break;
    }
    case WM_KEYUP:
    case WM_LBUTTONUP:
      break;
    default:
      break;
  }
  return ::DefSubclassProc(hwnd, message, wparam, lparam);
}

}  // namespace lumen
