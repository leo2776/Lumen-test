#include "ui/Gfx.h"

#include <d2d1helper.h>
#include <cmath>

#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")

namespace lumen {
namespace {

void SafeRelease(IUnknown*& p) {
  if (p) {
    p->Release();
    p = nullptr;
  }
}

ID2D1StrokeStyle* RoundStrokeStyle() {
  static ID2D1StrokeStyle* style = nullptr;
  if (!style) {
    ID2D1Factory* factory = Gfx::Get().d2d();
    if (!factory) return nullptr;
    D2D1_STROKE_STYLE_PROPERTIES props = D2D1::StrokeStyleProperties(
        D2D1_CAP_STYLE_ROUND, D2D1_CAP_STYLE_ROUND, D2D1_CAP_STYLE_ROUND, D2D1_LINE_JOIN_ROUND,
        10.0f, D2D1_DASH_STYLE_SOLID, 0.0f);
    factory->CreateStrokeStyle(props, nullptr, 0, &style);
  }
  return style;
}

inline D2D1_COLOR_F Rgba(unsigned int rgb, float a = 1.0f) {
  return D2D1::ColorF((UINT32)rgb, a);
}

// 把 0..1 的正規化座標轉成實際像素/DIP 座標
struct IconBox {
  float left, top, width, height;

  explicit IconBox(const D2D1_RECT_F& r)
      : left(r.left), top(r.top), width(r.right - r.left), height(r.bottom - r.top) {}

  D2D1_POINT_2F P(float nx, float ny) const {
    return D2D1::Point2F(left + width * nx, top + height * ny);
  }
  float Radius(float nr) const { return (width < height ? width : height) * nr; }
};

// 以「多段折線 + 圓弧」累積一條路徑，最後一次描邊或填滿
class PathBuilder {
 public:
  PathBuilder() = default;
  ~PathBuilder() { Reset(); }

  bool Begin() {
    ID2D1Factory* factory = Gfx::Get().d2d();
    if (!factory) return false;
    if (FAILED(factory->CreatePathGeometry(&geometry_)) || !geometry_) return false;
    if (FAILED(geometry_->Open(&sink_)) || !sink_) return false;
    return true;
  }

  void Polyline(const std::vector<D2D1_POINT_2F>& points) {
    if (!sink_ || points.size() < 2) return;
    sink_->BeginFigure(points.front(), D2D1_FIGURE_BEGIN_HOLLOW);
    for (size_t i = 1; i < points.size(); ++i) sink_->AddLine(points[i]);
    sink_->EndFigure(D2D1_FIGURE_END_OPEN);
  }

  void Line(D2D1_POINT_2F a, D2D1_POINT_2F b) { Polyline({a, b}); }

  void ClosedPolygon(const std::vector<D2D1_POINT_2F>& points) {
    if (!sink_ || points.size() < 3) return;
    sink_->BeginFigure(points.front(), D2D1_FIGURE_BEGIN_FILLED);
    for (size_t i = 1; i < points.size(); ++i) sink_->AddLine(points[i]);
    sink_->EndFigure(D2D1_FIGURE_END_CLOSED);
  }

  // 由 start 到 end 的圓弧 (角度以「數學角度、y 軸向下」計算)
  void Arc(D2D1_POINT_2F start, D2D1_POINT_2F end, float radius, bool clockwise,
           bool large = false) {
    if (!sink_) return;
    sink_->BeginFigure(start, D2D1_FIGURE_BEGIN_HOLLOW);
    const D2D1_ARC_SEGMENT seg = D2D1::ArcSegment(
        end, D2D1::SizeF(radius, radius), 0.0f,
        clockwise ? D2D1_SWEEP_DIRECTION_CLOCKWISE : D2D1_SWEEP_DIRECTION_COUNTER_CLOCKWISE,
        large ? D2D1_ARC_SIZE_LARGE : D2D1_ARC_SIZE_SMALL);
    sink_->AddArc(seg);
    sink_->EndFigure(D2D1_FIGURE_END_OPEN);
  }

  void Stroke(ID2D1RenderTarget* rt, const D2D1_COLOR_F& color, float width) {
    if (!Finish()) return;
    ID2D1SolidColorBrush* brush = nullptr;
    if (FAILED(rt->CreateSolidColorBrush(color, &brush)) || !brush) return;
    rt->DrawGeometry(geometry_, brush, width, RoundStrokeStyle());
    brush->Release();
    Reset();
  }

  void Fill(ID2D1RenderTarget* rt, const D2D1_COLOR_F& color) {
    if (!Finish()) return;
    ID2D1SolidColorBrush* brush = nullptr;
    if (FAILED(rt->CreateSolidColorBrush(color, &brush)) || !brush) return;
    rt->FillGeometry(geometry_, brush);
    brush->Release();
    Reset();
  }

  // 建立一條折線後直接描邊的便捷函式
  static void StrokePolyline(ID2D1RenderTarget* rt, ID2D1Factory* factory,
                             const std::vector<D2D1_POINT_2F>& points, const D2D1_COLOR_F& color,
                             float width) {
    if (!factory || points.size() < 2) return;
    ID2D1PathGeometry* geometry = nullptr;
    ID2D1GeometrySink* sink = nullptr;
    if (FAILED(factory->CreatePathGeometry(&geometry)) || !geometry) return;
    if (FAILED(geometry->Open(&sink)) || !sink) {
      geometry->Release();
      return;
    }
    sink->BeginFigure(points.front(), D2D1_FIGURE_BEGIN_HOLLOW);
    for (size_t i = 1; i < points.size(); ++i) sink->AddLine(points[i]);
    sink->EndFigure(D2D1_FIGURE_END_OPEN);
    sink->Close();
    sink->Release();

    ID2D1SolidColorBrush* brush = nullptr;
    if (SUCCEEDED(rt->CreateSolidColorBrush(color, &brush)) && brush) {
      rt->DrawGeometry(geometry, brush, width, RoundStrokeStyle());
      brush->Release();
    }
    geometry->Release();
  }

 private:
  bool Finish() {
    if (!sink_) return false;
    sink_->Close();
    sink_->Release();
    sink_ = nullptr;
    return geometry_ != nullptr;
  }

  void Reset() {
    if (sink_) {
      sink_->Release();
      sink_ = nullptr;
    }
    if (geometry_) {
      geometry_->Release();
      geometry_ = nullptr;
    }
  }

  ID2D1PathGeometry* geometry_ = nullptr;
  ID2D1GeometrySink* sink_ = nullptr;
};

void PointOnCircle(D2D1_POINT_2F center, float radius, float degrees, D2D1_POINT_2F* out) {
  const float rad = degrees * 3.14159265358979f / 180.0f;
  out->x = center.x + radius * std::cos(rad);
  out->y = center.y + radius * std::sin(rad);
}

}  // namespace

// ---------------------------------------------------------------------------
//  Gfx
// ---------------------------------------------------------------------------
Gfx& Gfx::Get() {
  static Gfx instance;
  return instance;
}

bool Gfx::Initialize() {
  if (d2d_ && dwrite_) return true;

  D2D1_FACTORY_OPTIONS options{};
  if (FAILED(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, __uuidof(ID2D1Factory), &options,
                               reinterpret_cast<void**>(&d2d_)))) {
    return false;
  }
  if (FAILED(DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory),
                                 reinterpret_cast<IUnknown**>(&dwrite_)))) {
    return false;
  }

  struct FontSpec {
    const wchar_t* family;
    float size;
    DWRITE_FONT_WEIGHT weight;
  };
  const FontSpec specs[(int)FontRole::Count] = {
      {L"Segoe UI", 12.5f, DWRITE_FONT_WEIGHT_NORMAL},      // UI
      {L"Segoe UI", 12.5f, DWRITE_FONT_WEIGHT_SEMI_BOLD},   // UIBold
      {L"Segoe UI", 13.0f, DWRITE_FONT_WEIGHT_NORMAL},      // Omnibox
      {L"Segoe UI", 12.0f, DWRITE_FONT_WEIGHT_NORMAL},      // Tab
      {L"Segoe UI", 12.5f, DWRITE_FONT_WEIGHT_NORMAL},      // Menu
      {L"Segoe UI", 11.0f, DWRITE_FONT_WEIGHT_NORMAL},      // Small
      {L"Segoe UI", 16.0f, DWRITE_FONT_WEIGHT_SEMI_BOLD},   // Heading
  };

  for (int i = 0; i < (int)FontRole::Count; ++i) {
    IDWriteTextFormat* format = nullptr;
    if (SUCCEEDED(dwrite_->CreateTextFormat(specs[i].family, nullptr, specs[i].weight,
                                            DWRITE_FONT_STYLE_NORMAL, DWRITE_FONT_STRETCH_NORMAL,
                                            specs[i].size, L"zh-TW", &format)) &&
        format) {
      format->SetWordWrapping(DWRITE_WORD_WRAPPING_NO_WRAP);
      format->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
      fonts_[i] = format;
    }
  }
  return true;
}

void Gfx::Shutdown() {
  for (auto& font : fonts_) {
    if (font) {
      font->Release();
      font = nullptr;
    }
  }
  if (dwrite_) {
    dwrite_->Release();
    dwrite_ = nullptr;
  }
  if (d2d_) {
    d2d_->Release();
    d2d_ = nullptr;
  }
}

// ---------------------------------------------------------------------------
//  基本圖形
// ---------------------------------------------------------------------------
void FillRect(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, const D2D1_COLOR_F& color) {
  ID2D1SolidColorBrush* brush = nullptr;
  if (!rt || FAILED(rt->CreateSolidColorBrush(color, &brush)) || !brush) return;
  rt->FillRectangle(rect, brush);
  brush->Release();
}

void FillRoundedRect(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, float radius,
                     const D2D1_COLOR_F& color) {
  ID2D1SolidColorBrush* brush = nullptr;
  if (!rt || FAILED(rt->CreateSolidColorBrush(color, &brush)) || !brush) return;
  const D2D1_ROUNDED_RECT rounded = D2D1::RoundedRect(rect, radius, radius);
  rt->FillRoundedRectangle(rounded, brush);
  brush->Release();
}

void StrokeRoundedRect(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, float radius,
                       const D2D1_COLOR_F& color, float stroke_width) {
  ID2D1SolidColorBrush* brush = nullptr;
  if (!rt || FAILED(rt->CreateSolidColorBrush(color, &brush)) || !brush) return;
  const D2D1_ROUNDED_RECT rounded = D2D1::RoundedRect(rect, radius, radius);
  rt->DrawRoundedRectangle(rounded, brush, stroke_width);
  brush->Release();
}

void FillCircle(ID2D1RenderTarget* rt, D2D1_POINT_2F center, float radius,
                const D2D1_COLOR_F& color) {
  ID2D1SolidColorBrush* brush = nullptr;
  if (!rt || FAILED(rt->CreateSolidColorBrush(color, &brush)) || !brush) return;
  rt->FillEllipse(D2D1::Ellipse(center, radius, radius), brush);
  brush->Release();
}

void DrawLine(ID2D1RenderTarget* rt, D2D1_POINT_2F a, D2D1_POINT_2F b, const D2D1_COLOR_F& color,
              float width) {
  ID2D1SolidColorBrush* brush = nullptr;
  if (!rt || FAILED(rt->CreateSolidColorBrush(color, &brush)) || !brush) return;
  rt->DrawLine(a, b, brush, width);
  brush->Release();
}

// ---------------------------------------------------------------------------
//  向量圖示
// ---------------------------------------------------------------------------
void DrawIcon(ID2D1RenderTarget* rt, Icon icon, const D2D1_RECT_F& box, const D2D1_COLOR_F& color,
              float stroke_width) {
  if (!rt) return;
  ID2D1Factory* factory = Gfx::Get().d2d();
  if (!factory) return;
  const IconBox b(box);

  switch (icon) {
    case Icon::Back:
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.62f, 0.24f), b.P(0.34f, 0.5f), b.P(0.62f, 0.76f)},
                                  color, stroke_width);
      break;
    case Icon::Forward:
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.38f, 0.24f), b.P(0.66f, 0.5f), b.P(0.38f, 0.76f)},
                                  color, stroke_width);
      break;
    case Icon::Reload: {
      const D2D1_POINT_2F center = b.P(0.5f, 0.5f);
      const float radius = b.Radius(0.28f);
      D2D1_POINT_2F start{}, end{};
      PointOnCircle(center, radius, -55.0f, &start);
      PointOnCircle(center, radius, 235.0f, &end);
      PathBuilder builder;
      if (builder.Begin()) {
        builder.Arc(start, end, radius, false, true);
        // 箭頭
        builder.Line(D2D1::Point2F(start.x - radius * 0.42f, start.y - radius * 0.12f), start);
        builder.Line(start, D2D1::Point2F(start.x + radius * 0.16f, start.y + radius * 0.42f));
        builder.Stroke(rt, color, stroke_width);
      }
      break;
    }
    case Icon::Home:
      PathBuilder::StrokePolyline(rt, factory,
                                  {b.P(0.5f, 0.2f), b.P(0.82f, 0.46f), b.P(0.82f, 0.8f), b.P(0.18f, 0.8f),
                                   b.P(0.18f, 0.46f), b.P(0.5f, 0.2f)},
                                  color, stroke_width);
      break;
    case Icon::Star:
    case Icon::StarFilled: {
      std::vector<D2D1_POINT_2F> points;
      points.reserve(10);
      const D2D1_POINT_2F center = b.P(0.5f, 0.5f);
      const float outer = b.Radius(0.42f);
      const float inner = b.Radius(0.18f);
      for (int i = 0; i < 10; ++i) {
        const float angle = -90.0f + (float)i * 36.0f;
        D2D1_POINT_2F p{};
        PointOnCircle(center, (i % 2 == 0) ? outer : inner, angle, &p);
        points.push_back(p);
      }
      PathBuilder builder;
      if (builder.Begin()) {
        builder.ClosedPolygon(points);
        if (icon == Icon::StarFilled) {
          builder.Fill(rt, color);
        } else {
          builder.Stroke(rt, color, stroke_width);
        }
      }
      break;
    }
    case Icon::Plus:
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.5f, 0.26f), b.P(0.5f, 0.74f)}, color,
                                  stroke_width);
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.26f, 0.5f), b.P(0.74f, 0.5f)}, color,
                                  stroke_width);
      break;
    case Icon::Close:
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.3f, 0.3f), b.P(0.7f, 0.7f)}, color,
                                  stroke_width);
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.7f, 0.3f), b.P(0.3f, 0.7f)}, color,
                                  stroke_width);
      break;
    case Icon::MenuDots:
      FillCircle(rt, b.P(0.5f, 0.24f), b.Radius(0.07f), color);
      FillCircle(rt, b.P(0.5f, 0.5f), b.Radius(0.07f), color);
      FillCircle(rt, b.P(0.5f, 0.76f), b.Radius(0.07f), color);
      break;
    case Icon::Lock: {
      PathBuilder builder;
      if (builder.Begin()) {
        const float left = box.left + b.width * 0.3f;
        const float right = box.left + b.width * 0.7f;
        const float top = box.top + b.height * 0.48f;
        const float bottom = box.top + b.height * 0.8f;
        builder.ClosedPolygon({{left, top}, {right, top}, {right, bottom}, {left, bottom}});
        // 鎖勾
        D2D1_POINT_2F arc_start{}, arc_end{};
        PointOnCircle(D2D1::Point2F((left + right) * 0.5f, top), (right - left) * 0.32f, 180.0f,
                      &arc_start);
        PointOnCircle(D2D1::Point2F((left + right) * 0.5f, top), (right - left) * 0.32f, 0.0f,
                      &arc_end);
        builder.Arc(arc_start, arc_end, (right - left) * 0.32f, true, false);
        builder.Stroke(rt, color, stroke_width * 0.85f);
      }
      break;
    }
    case Icon::Search: {
      ID2D1SolidColorBrush* brush = nullptr;
      if (SUCCEEDED(rt->CreateSolidColorBrush(color, &brush)) && brush) {
        rt->DrawEllipse(D2D1::Ellipse(b.P(0.44f, 0.44f), b.Radius(0.24f), b.Radius(0.24f)), brush,
                        stroke_width);
        brush->Release();
      }
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.62f, 0.62f), b.P(0.8f, 0.8f)}, color,
                                  stroke_width);
      break;
    }
    case Icon::Download:
      PathBuilder::StrokePolyline(rt, factory,
                                  {b.P(0.5f, 0.22f), b.P(0.5f, 0.62f), b.P(0.34f, 0.46f)}, color,
                                  stroke_width);
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.5f, 0.62f), b.P(0.66f, 0.46f)}, color,
                                  stroke_width);
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.26f, 0.78f), b.P(0.74f, 0.78f)}, color,
                                  stroke_width);
      break;
    case Icon::Globe: {
      ID2D1SolidColorBrush* brush = nullptr;
      if (SUCCEEDED(rt->CreateSolidColorBrush(color, &brush)) && brush) {
        const D2D1_POINT_2F center = b.P(0.5f, 0.5f);
        rt->DrawEllipse(D2D1::Ellipse(center, b.Radius(0.32f), b.Radius(0.32f)), brush,
                        stroke_width);
        rt->DrawEllipse(D2D1::Ellipse(center, b.Radius(0.14f), b.Radius(0.32f)), brush,
                        stroke_width * 0.8f);
        rt->DrawLine(D2D1::Point2F(center.x - b.Radius(0.32f), center.y),
                     D2D1::Point2F(center.x + b.Radius(0.32f), center.y), brush, stroke_width * 0.8f);
        brush->Release();
      }
      break;
    }
    case Icon::Minimize:
      PathBuilder::StrokePolyline(rt, factory, {b.P(0.28f, 0.5f), b.P(0.72f, 0.5f)}, color, 1.0f);
      break;
    case Icon::Maximize:
      StrokeRoundedRect(rt, D2D1::RectF(box.left + b.width * 0.32f, box.top + b.height * 0.32f,
                                        box.left + b.width * 0.68f, box.top + b.height * 0.68f),
                        0.0f, color, 1.0f);
      break;
    case Icon::Restore:
      StrokeRoundedRect(rt, D2D1::RectF(box.left + b.width * 0.28f, box.top + b.height * 0.36f,
                                        box.left + b.width * 0.62f, box.top + b.height * 0.70f),
                        0.0f, color, 1.0f);
      PathBuilder::StrokePolyline(rt, factory,
                                  {b.P(0.38f, 0.30f), b.P(0.72f, 0.30f), b.P(0.72f, 0.62f)}, color,
                                  1.0f);
      break;
  }
}

// ---------------------------------------------------------------------------
//  文字
// ---------------------------------------------------------------------------
void DrawTextClipped(ID2D1RenderTarget* rt, const std::wstring& text, FontRole role,
                     const D2D1_RECT_F& box, const D2D1_COLOR_F& color,
                     DWRITE_TEXT_ALIGNMENT align, DWRITE_PARAGRAPH_ALIGNMENT paragraph,
                     bool ellipsis) {
  if (!rt || text.empty()) return;
  IDWriteTextFormat* format = Gfx::Get().Font(role);
  IDWriteFactory* dwrite = Gfx::Get().dwrite();
  if (!format || !dwrite) return;

  const float width = (box.right - box.left) > 1.0f ? (box.right - box.left) : 1.0f;
  const float height = (box.bottom - box.top) > 1.0f ? (box.bottom - box.top) : 1.0f;

  IDWriteTextLayout* layout = nullptr;
  if (FAILED(dwrite->CreateTextLayout(text.c_str(), (UINT32)text.size(), format, width, height,
                                      &layout)) ||
      !layout) {
    return;
  }
  layout->SetTextAlignment(align);
  layout->SetParagraphAlignment(paragraph);

  if (ellipsis) {
    IDWriteInlineObject* sign = nullptr;
    if (SUCCEEDED(dwrite->CreateEllipsisTrimmingSign(format, &sign)) && sign) {
      DWRITE_TRIMMING trimming{};
      trimming.granularity = DWRITE_TRIMMING_GRANULARITY_CHARACTER;
      trimming.delimiter = 0;
      trimming.delimiterCount = 0;
      layout->SetTrimming(&trimming, sign);
      sign->Release();
    }
  }

  ID2D1SolidColorBrush* brush = nullptr;
  if (SUCCEEDED(rt->CreateSolidColorBrush(color, &brush)) && brush) {
    rt->DrawTextLayout(D2D1::Point2F(box.left, box.top), layout, brush,
                       D2D1_DRAW_TEXT_OPTIONS_CLIP);
    brush->Release();
  }
  layout->Release();
}

void DrawTextRaw(ID2D1RenderTarget* rt, const std::wstring& text, IDWriteTextFormat* format,
                 const D2D1_RECT_F& box, const D2D1_COLOR_F& color, DWRITE_TEXT_ALIGNMENT align) {
  if (!rt || text.empty() || !format) return;
  IDWriteFactory* dwrite = Gfx::Get().dwrite();
  if (!dwrite) return;

  IDWriteTextLayout* layout = nullptr;
  const float width = (box.right - box.left) > 1.0f ? (box.right - box.left) : 1.0f;
  const float height = (box.bottom - box.top) > 1.0f ? (box.bottom - box.top) : 1.0f;
  if (FAILED(dwrite->CreateTextLayout(text.c_str(), (UINT32)text.size(), format, width, height,
                                      &layout)) ||
      !layout) {
    return;
  }
  layout->SetTextAlignment(align);
  layout->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

  ID2D1SolidColorBrush* brush = nullptr;
  if (SUCCEEDED(rt->CreateSolidColorBrush(color, &brush)) && brush) {
    rt->DrawTextLayout(D2D1::Point2F(box.left, box.top), layout, brush, D2D1_DRAW_TEXT_OPTIONS_CLIP);
    brush->Release();
  }
  layout->Release();
}

float MeasureText(const std::wstring& text, FontRole role, float max_width) {
  if (text.empty()) return 0.0f;
  IDWriteFactory* dwrite = Gfx::Get().dwrite();
  IDWriteTextFormat* format = Gfx::Get().Font(role);
  if (!dwrite || !format) return 0.0f;

  IDWriteTextLayout* layout = nullptr;
  if (FAILED(dwrite->CreateTextLayout(text.c_str(), (UINT32)text.size(), format, max_width, 1000.0f,
                                      &layout)) ||
      !layout) {
    return 0.0f;
  }
  DWRITE_TEXT_METRICS metrics{};
  float width = 0.0f;
  if (SUCCEEDED(layout->GetMetrics(&metrics))) width = metrics.widthIncludingTrailingWhitespace;
  layout->Release();
  return width;
}

// ---------------------------------------------------------------------------
//  App 圖示 (純 C++ 執行時生成，不依賴 .ico 檔)
// ---------------------------------------------------------------------------
HICON CreateAppIcon(int size_px, bool dark) {
  if (size_px <= 0) return nullptr;
  Gfx& gfx = Gfx::Get();
  if (!gfx.d2d()) return nullptr;

  BITMAPINFO bmi{};
  bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bmi.bmiHeader.biWidth = size_px;
  bmi.bmiHeader.biHeight = -size_px;   // top-down
  bmi.bmiHeader.biPlanes = 1;
  bmi.bmiHeader.biBitCount = 32;
  bmi.bmiHeader.biCompression = BI_RGB;

  HDC screen = ::GetDC(nullptr);
  void* bits = nullptr;
  HBITMAP color_bitmap = ::CreateDIBSection(screen, &bmi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (!color_bitmap) {
    ::ReleaseDC(nullptr, screen);
    return nullptr;
  }
  HDC memory_dc = ::CreateCompatibleDC(screen);
  HGDIOBJ old_bitmap = ::SelectObject(memory_dc, color_bitmap);

  ID2D1DCRenderTarget* target = nullptr;
  const D2D1_RENDER_TARGET_PROPERTIES props = D2D1::RenderTargetProperties(
      D2D1_RENDER_TARGET_TYPE_DEFAULT,
      D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED), 96.0f, 96.0f);
  if (SUCCEEDED(gfx.d2d()->CreateDCRenderTarget(&props, &target)) && target) {
    RECT rc{0, 0, size_px, size_px};
    if (SUCCEEDED(target->BindDC(memory_dc, &rc))) {
      target->BeginDraw();
      target->Clear(D2D1::ColorF(0.0f, 0.0f));
      const float s = (float)size_px;

      // 圓形底 + 環
      const D2D1_POINT_2F center = D2D1::Point2F(s * 0.5f, s * 0.5f);
      ID2D1GradientStopCollection* stops = nullptr;
      const D2D1_GRADIENT_STOP gradient[2] = {
          {0.0f, D2D1::ColorF(0x4C8DF6)},
          {1.0f, D2D1::ColorF(0x1A73E8)},
      };
      if (SUCCEEDED(target->CreateGradientStopCollection(gradient, 2, &stops)) && stops) {
        ID2D1LinearGradientBrush* brush = nullptr;
        const D2D1_LINEAR_GRADIENT_BRUSH_PROPERTIES lbp =
            D2D1::LinearGradientBrushProperties(D2D1::Point2F(0.0f, 0.0f), D2D1::Point2F(0.0f, s));
        if (SUCCEEDED(target->CreateLinearGradientBrush(lbp, stops, &brush)) && brush) {
          target->FillEllipse(D2D1::Ellipse(center, s * 0.46f, s * 0.46f), brush);
          brush->Release();
        }
        stops->Release();
      }

      ID2D1SolidColorBrush* white = nullptr;
      if (SUCCEEDED(target->CreateSolidColorBrush(D2D1::ColorF(0xFFFFFF), &white)) && white) {
        // 白色軌道環
        target->DrawEllipse(D2D1::Ellipse(center, s * 0.30f, s * 0.30f), white, s * 0.075f);
        // 中央亮點
        target->FillEllipse(D2D1::Ellipse(center, s * 0.085f, s * 0.085f), white);
        white->Release();
      }
      target->EndDraw();
    }
    target->Release();
  }

  ::SelectObject(memory_dc, old_bitmap);
  ::DeleteDC(memory_dc);
  ::ReleaseDC(nullptr, screen);

  HBITMAP mask = ::CreateBitmap(size_px, size_px, 1, 1, nullptr);
  ICONINFO info{};
  info.fIcon = TRUE;
  info.hbmMask = mask;
  info.hbmColor = color_bitmap;
  HICON icon = ::CreateIconIndirect(&info);
  if (mask) ::DeleteObject(mask);
  ::DeleteObject(color_bitmap);
  (void)dark;
  return icon;
}

}  // namespace lumen
