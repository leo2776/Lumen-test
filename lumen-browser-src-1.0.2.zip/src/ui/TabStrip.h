// ===========================================================================
//  Lumen Browser — ui/TabStrip.h
//  自研分頁列：圓角上緣分頁、hover 效果、關閉鈕、載入轉圈、新增分頁 (+)。
//  所有幾何以 DIP 計算，交由 Direct2D 依 DPI 縮放。
// ===========================================================================
#pragma once

#include "core/Platform.h"
#include "ui/Theme.h"

#include <d2d1.h>

namespace lumen {

struct TabVisual {
  std::wstring title;
  bool loading = false;
};

class TabStrip {
 public:
  enum class Part { None, Tab, CloseTab, NewTab };

  struct Hit {
    Part part = Part::None;
    int index = -1;
  };

  void SetTabs(const std::vector<TabVisual>& tabs, int active_index);
  void SetHover(int tab_index, int close_tab_index);
  void SetSpinnerPhase(float phase) { spinner_phase_ = phase; }

  void Layout(const D2D1_RECT_F& area);

  Hit HitTest(D2D1_POINT_2F point) const;
  void Paint(ID2D1RenderTarget* rt, const Theme& theme) const;

  D2D1_RECT_F new_tab_rect() const { return newtab_; }
  int tab_count() const { return (int)tabs_.size(); }

 private:
  struct Visual {
    D2D1_RECT_F tab{};
    D2D1_RECT_F close{};
    bool has_close = false;
  };

  std::vector<TabVisual> tabs_;
  std::vector<Visual> visuals_;
  D2D1_RECT_F area_{};
  D2D1_RECT_F newtab_{};
  int active_ = -1;
  int hover_ = -1;
  int hover_close_ = -1;
  float spinner_phase_ = 0.0f;
};

}  // namespace lumen
