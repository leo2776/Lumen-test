#include "ui/TabStrip.h"

#include "ui/Gfx.h"

#include <d2d1helper.h>
#include <cmath>

namespace lumen {
namespace {

constexpr float kTabRadius = 9.0f;
constexpr float kTabMinWidth = 34.0f;
constexpr float kTabMaxWidth = 240.0f;

// 只有上緣圓角的分頁形狀 (Chrome 分頁的關鍵視覺特徵)
void FillTopRoundedRect(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, float radius,
                        const D2D1_COLOR_F& color) {
  ID2D1Factory* factory = Gfx::Get().d2d();
  if (!factory || !rt) return;
  if (rect.right - rect.left < radius * 2.0f) radius = (rect.right - rect.left) * 0.5f;

  ID2D1PathGeometry* geometry = nullptr;
  ID2D1GeometrySink* sink = nullptr;
  if (FAILED(factory->CreatePathGeometry(&geometry)) || !geometry) return;
  if (FAILED(geometry->Open(&sink)) || !sink) {
    geometry->Release();
    return;
  }
  sink->BeginFigure(D2D1::Point2F(rect.left, rect.bottom), D2D1_FIGURE_BEGIN_FILLED);
  sink->AddLine(D2D1::Point2F(rect.left, rect.top + radius));
  sink->AddArc(D2D1::ArcSegment(D2D1::Point2F(rect.left + radius, rect.top),
                                D2D1::SizeF(radius, radius), 0.0f,
                                D2D1_SWEEP_DIRECTION_CLOCKWISE, D2D1_ARC_SIZE_SMALL));
  sink->AddLine(D2D1::Point2F(rect.right - radius, rect.top));
  sink->AddArc(D2D1::ArcSegment(D2D1::Point2F(rect.right, rect.top + radius),
                                D2D1::SizeF(radius, radius), 0.0f,
                                D2D1_SWEEP_DIRECTION_CLOCKWISE, D2D1_ARC_SIZE_SMALL));
  sink->AddLine(D2D1::Point2F(rect.right, rect.bottom));
  sink->EndFigure(D2D1_FIGURE_END_CLOSED);
  sink->Close();
  sink->Release();

  ID2D1SolidColorBrush* brush = nullptr;
  if (SUCCEEDED(rt->CreateSolidColorBrush(color, &brush)) && brush) {
    rt->FillGeometry(geometry, brush);
    brush->Release();
  }
  geometry->Release();
}

void StrokeArc(ID2D1RenderTarget* rt, D2D1_POINT_2F center, float radius, float start_deg,
               float sweep_deg, const D2D1_COLOR_F& color, float width) {
  ID2D1Factory* factory = Gfx::Get().d2d();
  if (!factory || !rt) return;
  const float a0 = start_deg * 3.14159265f / 180.0f;
  const float a1 = (start_deg + sweep_deg) * 3.14159265f / 180.0f;
  ID2D1PathGeometry* geometry = nullptr;
  ID2D1GeometrySink* sink = nullptr;
  if (FAILED(factory->CreatePathGeometry(&geometry)) || !geometry) return;
  if (FAILED(geometry->Open(&sink)) || !sink) {
    geometry->Release();
    return;
  }
  sink->BeginFigure(D2D1::Point2F(center.x + radius * std::cos(a0), center.y + radius * std::sin(a0)),
                    D2D1_FIGURE_BEGIN_HOLLOW);
  sink->AddArc(D2D1::ArcSegment(
      D2D1::Point2F(center.x + radius * std::cos(a1), center.y + radius * std::sin(a1)),
      D2D1::SizeF(radius, radius), 0.0f,
      sweep_deg >= 0 ? D2D1_SWEEP_DIRECTION_CLOCKWISE : D2D1_SWEEP_DIRECTION_COUNTER_CLOCKWISE,
      std::fabs(sweep_deg) > 180.0f ? D2D1_ARC_SIZE_LARGE : D2D1_ARC_SIZE_SMALL));
  sink->EndFigure(D2D1_FIGURE_END_OPEN);
  sink->Close();
  sink->Release();

  ID2D1SolidColorBrush* brush = nullptr;
  if (SUCCEEDED(rt->CreateSolidColorBrush(color, &brush)) && brush) {
    rt->DrawGeometry(geometry, brush, width);
    brush->Release();
  }
  geometry->Release();
}

D2D1_COLOR_F FaviconColor(const std::wstring& title, bool dark) {
  static const unsigned int kDark[] = {0x8AB4F8, 0x81C995, 0xFDD663, 0xF28B82, 0xC58AF9, 0x78D9EC};
  static const unsigned int kLight[] = {0x1A73E8, 0x188038, 0xF9AB00, 0xD93025, 0xA142F4, 0x12B5CB};
  unsigned int hash = 2166136261u;
  for (wchar_t c : title) {
    hash ^= (unsigned int)c;
    hash *= 16777619u;
  }
  const unsigned int* palette = dark ? kDark : kLight;
  return D2D1::ColorF(palette[hash % 6]);
}

}  // namespace

void TabStrip::SetTabs(const std::vector<TabVisual>& tabs, int active_index) {
  tabs_ = tabs;
  active_ = active_index;
}

void TabStrip::SetHover(int tab_index, int close_tab_index) {
  hover_ = tab_index;
  hover_close_ = close_tab_index;
}

void TabStrip::Layout(const D2D1_RECT_F& area) {
  area_ = area;
  visuals_.assign(tabs_.size(), Visual{});

  const float left_pad = 8.0f;
  const float right_pad = 6.0f;
  const float newtab_width = 30.0f;
  const float top = area.top + 6.0f;
  const float bottom = area.bottom + 1.0f;
  const int count = (int)tabs_.size();

  float tab_width = 0.0f;
  if (count > 0) {
    const float available = (area.right - area.left) - left_pad - right_pad - newtab_width;
    tab_width = available / (float)count;
    if (tab_width > kTabMaxWidth) tab_width = kTabMaxWidth;
    if (tab_width < kTabMinWidth) tab_width = kTabMinWidth;
  }

  float x = area.left + left_pad;
  for (int i = 0; i < count; ++i) {
    Visual v;
    v.tab = D2D1::RectF(x, top, x + tab_width, bottom);
    const float center_y = (top + bottom) * 0.5f;
    const float close_size = 15.0f;
    v.close = D2D1::RectF(v.tab.right - close_size - 7.0f, center_y - close_size * 0.5f,
                          v.tab.right - 7.0f, center_y + close_size * 0.5f);
    v.has_close = tab_width >= 52.0f;
    visuals_[i] = v;
    x += tab_width;
  }

  const float center_y = (top + bottom) * 0.5f;
  newtab_ = D2D1::RectF(x + 4.0f, center_y - 14.0f, x + 4.0f + 26.0f, center_y + 14.0f);
}

TabStrip::Hit TabStrip::HitTest(D2D1_POINT_2F point) const {
  for (int i = 0; i < (int)visuals_.size(); ++i) {
    const Visual& v = visuals_[i];
    if (!v.has_close) continue;
    if (point.x >= v.close.left && point.x <= v.close.right && point.y >= v.close.top &&
        point.y <= v.close.bottom) {
      return Hit{Part::CloseTab, i};
    }
  }
  for (int i = 0; i < (int)visuals_.size(); ++i) {
    const D2D1_RECT_F& r = visuals_[i].tab;
    if (point.x >= r.left && point.x <= r.right && point.y >= r.top && point.y <= r.bottom) {
      return Hit{Part::Tab, i};
    }
  }
  if (point.x >= newtab_.left && point.x <= newtab_.right && point.y >= newtab_.top &&
      point.y <= newtab_.bottom) {
    return Hit{Part::NewTab, -1};
  }
  return Hit{};
}

void TabStrip::Paint(ID2D1RenderTarget* rt, const Theme& theme) const {
  if (!rt) return;

  for (int i = 0; i < (int)tabs_.size() && i < (int)visuals_.size(); ++i) {
    const Visual& v = visuals_[i];
    const bool is_active = (i == active_);
    const bool is_hover = (i == hover_);

    if (is_active) {
      FillTopRoundedRect(rt, v.tab, kTabRadius, theme.tab_active);
    } else if (is_hover) {
      FillTopRoundedRect(rt, v.tab, kTabRadius, theme.tab_hover);
    } else if (i + 1 < (int)visuals_.size() && i != active_) {
      // 非作用中分頁之間的分隔線
      const float x = v.tab.right - 1.0f;
      DrawLine(rt, D2D1::Point2F(x, v.tab.top + 11.0f), D2D1::Point2F(x, v.tab.bottom - 9.0f),
               D2D1::ColorF(theme.text_disabled.r, theme.text_disabled.g, theme.text_disabled.b, 0.35f),
               1.0f);
    }

    const float center_y = (v.tab.top + v.tab.bottom) * 0.5f;
    const float favicon_center_x = v.tab.left + 17.0f;

    if (tabs_[i].loading) {
      StrokeArc(rt, D2D1::Point2F(favicon_center_x, center_y), 6.0f,
                spinner_phase_ * 360.0f, 100.0f, theme.accent, 1.6f);
    } else {
      FillCircle(rt, D2D1::Point2F(favicon_center_x, center_y), 6.5f,
                 FaviconColor(tabs_[i].title, theme.dark));
    }

    const float text_left = favicon_center_x + 12.0f;
    const float text_right = v.has_close ? (v.close.left - 4.0f) : (v.tab.right - 8.0f);
    if (text_right > text_left) {
      DrawTextClipped(rt, tabs_[i].title, FontRole::Tab,
                      D2D1::RectF(text_left, v.tab.top, text_right, v.tab.bottom),
                      is_active ? theme.text : theme.text_secondary,
                      DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, true);
    }

    // 關閉鈕：作用中或 hover 時顯示
    if (v.has_close && (is_active || is_hover || hover_close_ == i)) {
      if (hover_close_ == i) {
        FillRoundedRect(rt, D2D1::RectF(v.close.left - 2.0f, v.close.top - 2.0f,
                                        v.close.right + 2.0f, v.close.bottom + 2.0f),
                        4.0f, theme.button_hover);
      }
      DrawIcon(rt, Icon::Close,
               D2D1::RectF(v.close.left + 2.0f, v.close.top + 2.0f, v.close.right - 2.0f,
                           v.close.bottom - 2.0f),
               hover_close_ == i ? theme.text : theme.text_secondary, 1.4f);
    }
  }

  // 新增分頁 (+)
  if (hover_ == -2) {
    FillRoundedRect(rt, newtab_, 6.0f, theme.button_hover);
  }
  DrawIcon(rt, Icon::Plus, newtab_, theme.icon, 1.5f);
}

}  // namespace lumen
