// ===========================================================================
//  Lumen Browser — ui/PopupMenu.h
//  Chrome 風格的深色彈出選單 (主選單 ⋮ 與網頁右鍵選單共用)。
//
//  為什麼不用 TrackPopupMenu？
//    原生 Win32 選單在 Windows 10 上無法套用深色主題，而且外觀與 Chrome
//    相差甚遠。這裡用一個 WS_POPUP 視窗 + Direct2D 自繪，並在 Track()
//    內跑巢狀訊息迴圈，行為與系統選單一致 (點擊外部 / ESC 即關閉)。
// ===========================================================================
#pragma once

#include "core/Platform.h"
#include "ui/Theme.h"

#include <d2d1.h>

namespace lumen {

struct MenuItem {
  int id = 0;
  std::wstring label;
  std::wstring shortcut;
  bool separator = false;
  bool checked = false;
  bool enabled = true;

  static MenuItem Separator() {
    MenuItem item;
    item.separator = true;
    return item;
  }
};

class PopupMenu {
 public:
  explicit PopupMenu(HWND owner);
  ~PopupMenu();

  // 回傳被選取的 id；使用者取消則回傳 0
  int Track(POINT screen_point, const std::vector<MenuItem>& items, const Theme& theme);

  static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam);

 private:
  LRESULT HandleMessage(UINT message, WPARAM wparam, LPARAM lparam);

  void RebuildLayout();
  void Paint();
  void Dismiss(int result);
  int  HitTestItem(POINT client_point) const;

  HWND owner_ = nullptr;
  HWND hwnd_ = nullptr;
  ID2D1HwndRenderTarget* target_ = nullptr;
  std::vector<MenuItem> items_;
  std::vector<D2D1_RECT_F> item_rects_;
  Theme theme_;
  int dpi_ = 96;
  int hover_ = -1;
  int selected_ = -1;
  int result_ = 0;
  bool running_ = false;
  bool activated_ = false;
  UINT width_px_ = 0;
  UINT height_px_ = 0;
};

}  // namespace lumen
