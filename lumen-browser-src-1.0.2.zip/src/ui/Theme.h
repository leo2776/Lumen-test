// ===========================================================================
//  Lumen Browser — ui/Theme.h
//  Chrome 風格的深色 / 淺色配色。所有 UI 元件只透過 Theme 取色，
//  切換深色模式時不需要重建任何視窗。
// ===========================================================================
#pragma once

#include "core/Platform.h"

#include <d2d1.h>

namespace lumen {

struct Theme {
  bool dark = true;

  D2D1_COLOR_F frame_background;   // 視窗外框 / 分頁列底色
  D2D1_COLOR_F tab_active;         // 作用中分頁
  D2D1_COLOR_F tab_inactive;       // 非作用中分頁
  D2D1_COLOR_F tab_hover;          // 分頁滑鼠移入
  D2D1_COLOR_F toolbar;            // 工具列 (含網址列所在橫列)
  D2D1_COLOR_F toolbar_separator;  // 工具列下緣分隔線
  D2D1_COLOR_F omnibox;            // 網址列未聚焦
  D2D1_COLOR_F omnibox_hover;
  D2D1_COLOR_F omnibox_focus;      // 網址列聚焦
  D2D1_COLOR_F omnibox_border;
  D2D1_COLOR_F button_hover;       // 工具列按鈕 hover 底色
  D2D1_COLOR_F text;               // 主要文字
  D2D1_COLOR_F text_secondary;     // 次要文字 (網址、狀態列)
  D2D1_COLOR_F text_disabled;
  D2D1_COLOR_F icon;               // 圖示預設色
  D2D1_COLOR_F accent;             // 強調色 (載入指示、聚焦外框)
  D2D1_COLOR_F danger;             // 關閉按鈕 hover
  D2D1_COLOR_F menu_background;
  D2D1_COLOR_F menu_hover;
  D2D1_COLOR_F menu_border;
  D2D1_COLOR_F web_backdrop;       // 網頁內容尚未繪製時的底色
  D2D1_COLOR_F caption_hover;      // 視窗按鈕 hover
  D2D1_COLOR_F caption_close_hover;

  static Theme Dark();
  static Theme Light();
  static Theme ForMode(bool dark) { return dark ? Dark() : Light(); }
};

}  // namespace lumen
