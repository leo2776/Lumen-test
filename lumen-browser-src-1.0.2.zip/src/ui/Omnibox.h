// ===========================================================================
//  Lumen Browser — ui/Omnibox.h
//  網址列 (Omnibox)。
//
//  技術選擇說明：
//   外觀 (圓角膠囊、鎖頭圖示、載入狀態) 由 Direct2D 自繪；
//   文字輸入則使用一個無邊框的原生 EDIT 子視窗疊在其上。
//   原因：只有原生 EDIT 能免費取得完整的 IME (中文/日文輸入)、
//   輸入法組字視窗、觸控選字、以及系統協助工具支援。
//   這是「自研 UI + Chromium 級輸入體驗」之間最務實的工程取捨。
// ===========================================================================
#pragma once

#include "core/Platform.h"
#include "ui/Theme.h"

namespace lumen {

class Omnibox {
 public:
  void Create(HWND parent, HINSTANCE instance);
  void Destroy();

  void SetBoundsPx(const RECT& rect_px);
  void ApplyTheme(const Theme& theme, int dpi);

  void SetText(const std::wstring& text, bool select_all);
  std::wstring GetText() const;

  void FocusAndSelectAll();
  bool has_focus() const { return focused_; }
  void SetSecure(bool secure) { secure_ = secure; }
  bool secure() const { return secure_; }

  HWND hwnd() const { return edit_; }
  HBRUSH background_brush() const { return brush_; }
  COLORREF text_color() const { return text_color_; }

  // 事件回呼
  std::function<void(const std::wstring&)> on_submit;
  std::function<void()> on_cancel;
  std::function<void(const std::wstring&)> on_text_changed;
  std::function<void(bool)> on_focus_changed;
  // 全域快速鍵 (Ctrl+T / Ctrl+W ...)：即使焦點在 EDIT 內也要能攔截
  std::function<bool(UINT message, WPARAM wparam, LPARAM lparam)> on_pre_key;

 private:
  static LRESULT CALLBACK SubclassProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam,
                                       UINT_PTR subclass_id, DWORD_PTR ref_data);
  void RecreateFont(int dpi);

  HWND parent_ = nullptr;
  HWND edit_ = nullptr;
  HFONT font_ = nullptr;
  HBRUSH brush_ = nullptr;
  COLORREF text_color_ = RGB(232, 234, 237);
  COLORREF background_color_ = RGB(32, 33, 36);
  bool focused_ = false;
  bool secure_ = false;
  int dpi_ = 96;
};

}  // namespace lumen
