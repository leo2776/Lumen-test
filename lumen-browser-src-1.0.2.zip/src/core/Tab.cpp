#include "core/Tab.h"

#include "include/cef_browser.h"

namespace lumen {

Tab::Tab(int id) : id_(id) {}

void Tab::SetBrowser(CefRefPtr<CefBrowser> browser) {
  browser_ = browser;
  if (browser_) {
    was_resized_pending_ = true;
    NotifyWasResized();
  }
}

bool Tab::HasBrowser() const { return browser_.get() != nullptr; }

void Tab::SetTitle(const std::wstring& title) {
  if (title.empty()) return;
  title_ = title;
}

void Tab::SetUrl(const std::wstring& url) { url_ = url; }

void Tab::SetLoading(bool loading) { loading_ = loading; }
void Tab::SetProgress(double progress) { progress_ = progress; }

void Tab::SetNavState(bool back, bool forward) {
  can_go_back_ = back;
  can_go_forward_ = forward;
}

void Tab::SetFrame(const void* bgra, int width, int height) {
  if (!bgra || width <= 0 || height <= 0) return;
  const size_t bytes = (size_t)width * (size_t)height * 4u;
  if (frame_.size() != bytes) frame_.resize(bytes);
  std::memcpy(frame_.data(), bgra, bytes);
  frame_width_ = width;
  frame_height_ = height;
}

void Tab::ResizeView(int pixel_width, int pixel_height, float dpi_scale) {
  if (pixel_width <= 0 || pixel_height <= 0) return;
  const bool size_changed = (pixel_width != view_width_ || pixel_height != view_height_);
  const bool dpi_changed = (std::fabs(dpi_scale - dpi_scale_) > 0.001f);
  view_width_ = pixel_width;
  view_height_ = pixel_height;
  dpi_scale_ = dpi_scale > 0.1f ? dpi_scale : 1.0f;
  if (size_changed || dpi_changed) {
    // 尺寸變了：舊畫面已無效，先清掉避免拉伸變形
    if (size_changed) {
      frame_width_ = 0;
      frame_height_ = 0;
      frame_.clear();
    }
    NotifyWasResized();
  }
}

int Tab::view_dip_width() const {
  return (int)std::lround((double)view_width_ / (double)dpi_scale_);
}

int Tab::view_dip_height() const {
  return (int)std::lround((double)view_height_ / (double)dpi_scale_);
}

void Tab::SetHidden(bool hidden) {
  if (hidden_ == hidden) return;
  hidden_ = hidden;
  if (browser_) {
    browser_->GetHost()->WasHidden(hidden);
    if (!hidden) {
      browser_->GetHost()->Invalidate(PET_VIEW);
    }
  }
}

void Tab::SetPopupVisible(bool visible) {
  popup_visible_ = visible;
  if (!visible) {
    popup_frame_.clear();
    popup_width_ = 0;
    popup_height_ = 0;
  }
}

void Tab::SetPopupRect(int x, int y, int width, int height) {
  popup_x_ = x;
  popup_y_ = y;
  popup_width_ = width > 0 ? width : 0;
  popup_height_ = height > 0 ? height : 0;
}

void Tab::SetPopupFrame(const void* bgra, int width, int height) {
  if (!bgra || width <= 0 || height <= 0) return;
  const size_t bytes = (size_t)width * (size_t)height * 4u;
  if (popup_frame_.size() != bytes) popup_frame_.resize(bytes);
  std::memcpy(popup_frame_.data(), bgra, bytes);
  popup_width_ = width;
  popup_height_ = height;
}

void Tab::NotifyWasResized() {
  if (browser_) {
    was_resized_pending_ = false;
    browser_->GetHost()->WasResized();
  } else {
    was_resized_pending_ = true;
  }
}

}  // namespace lumen
