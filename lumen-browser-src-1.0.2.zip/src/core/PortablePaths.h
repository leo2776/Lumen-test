// ===========================================================================
//  Lumen Browser — core/PortablePaths.h
//  ★ 可攜性核心 ★
//  所有路徑都強制落在「執行檔所在資料夾」之下，絕不觸碰 %APPDATA% /
//  %LOCALAPPDATA% / 登錄檔。這個模組是全瀏覽器唯一的資料位置來源 (SSOT)。
//
//  佈局：
//      <exe_dir>/lumen.exe
//      <exe_dir>/browser_data/            <- 可攜根 (可用 LUMEN_DATA_DIR 覆寫)
//          profile/    Chromium 使用者設定檔 (Cookie/LocalStorage/IndexedDB)
//          cache/      HTTP 快取、GPU shader 快取
//          crash/      Crashpad 傾印
//          logs/       cef.log
//          config/     settings.json / bookmarks.tsv / history.tsv
//          ui/         C++ 產生的內建頁面 (newtab.html ...)
//          downloads/  預設下載位置
//          temp/       行程專用 TMP/TEMP
// ===========================================================================
#pragma once

#include "core/Platform.h"

namespace lumen {

class PortablePaths {
 public:
  // 必須在使用任何其他方法前呼叫（main 最早執行）。
  static bool Initialize();
  static bool IsInitialized();

  static const std::wstring& ExePath();
  static const std::wstring& RootDir();      // 執行檔所在資料夾
  static const std::wstring& DataDir();      // <root>/browser_data
  static const std::wstring& ProfileDir();
  static const std::wstring& CacheDir();
  static const std::wstring& CrashDir();
  static const std::wstring& LogDir();
  static const std::wstring& ConfigDir();
  static const std::wstring& UiDir();
  static const std::wstring& DownloadsDir();
  static const std::wstring& TempDir();

  static std::wstring ConfigFile(const std::wstring& name);
  static std::wstring LogFile(const std::wstring& name);

  // 把 TMP/TEMP/CEF 相關環境變數導向可攜目錄，讓子行程 (renderer/GPU)
  // 也無法寫到系統暫存區。
  static void ApplyProcessEnvironment();

  // 單一實例鎖：在資料夾內建立 lock 檔並持有具名 Mutex。
  static bool LockSingleInstance();
  static void UnlockSingleInstance();
};

}  // namespace lumen
