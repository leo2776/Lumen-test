// ===========================================================================
//  Lumen Browser — core/UrlUtil.h
//  Omnibox 輸入判斷與 URL 正規化。
// ===========================================================================
#pragma once

#include "core/Platform.h"

namespace lumen {

// 百分比編碼（UTF-8 為基礎），用於查詢字串
std::wstring EscapeQueryParam(const std::wstring& text);

// 把 Omnibox 的輸入轉成可導覽的 URL；不像 URL 時走搜尋樣板。
std::wstring ResolveUserInput(const std::wstring& input, const std::wstring& search_template);

// 顯示用：去掉 scheme 與結尾斜線，讓 Omnibox 更像 Chrome
std::wstring DisplayUrl(const std::wstring& url);

// 取出 host 供安全指示燈判斷
std::wstring UrlHost(const std::wstring& url);
bool IsHttpsUrl(const std::wstring& url);
bool IsFileUrl(const std::wstring& url);
bool IsInternalUrl(const std::wstring& url);   // about:blank / file:// 內建頁

}  // namespace lumen
