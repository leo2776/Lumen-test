// ===========================================================================
//  Lumen Browser — core/UiPages.h
//  以 C++ 產生內建頁面 (新分頁 / 瀏覽紀錄 / 書籤管理)。
//  這些 HTML 由本程式在啟動與需要時寫入 ./browser_data/ui/ 後以 file:// 載入，
//  因此不需要任何網路資源，也不依賴外部檔案。
// ===========================================================================
#pragma once

#include "core/BookmarkStore.h"
#include "core/HistoryStore.h"
#include "core/Platform.h"

namespace lumen {
namespace ui_pages {

// 首次啟動時寫出 newtab.html (不會覆蓋使用者自行修改的版本)
void EnsureDefaultPages(const std::wstring& ui_dir);

// 產生並寫出紀錄頁，回傳檔案完整路徑
std::wstring WriteHistoryPage(const std::wstring& ui_dir, const std::vector<HistoryEntry>& entries);

// 產生並寫出書籤頁，回傳檔案完整路徑
std::wstring WriteBookmarksPage(const std::wstring& ui_dir, const std::vector<Bookmark>& bookmarks);

}  // namespace ui_pages
}  // namespace lumen
