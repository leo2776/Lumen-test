#include "core/AppConfig.h"

#include "util/MiniJson.h"
#include "util/WinUtil.h"

namespace lumen {

void AppConfig::Load(const std::wstring& path) {
  JsonObject json;
  const std::string raw = ReadTextFile(path);
  if (!raw.empty()) {
    if (!json.Parse(raw)) {
      // 設定檔損毀：保留預設值，並把壞檔備份起來方便診斷
      WriteTextFile(path + L".bak", raw);
    }
  }

  theme_mode   = ToWide(json.GetString("theme_mode", ToUtf8(theme_mode)));
  homepage     = ToWide(json.GetString("homepage", ToUtf8(homepage)));
  search_url   = ToWide(json.GetString("search_url", ToUtf8(search_url)));
  startup_mode = ToWide(json.GetString("startup_mode", ToUtf8(startup_mode)));
  if (theme_mode != L"dark" && theme_mode != L"light") theme_mode = L"dark";
  if (startup_mode != L"newtab" && startup_mode != L"homepage") startup_mode = L"newtab";
  if (search_url.find(L"%s") == std::wstring::npos) search_url = L"https://www.google.com/search?q=%s";

  show_bookmarks_bar = json.GetBool("show_bookmarks_bar", show_bookmarks_bar);
  window_width  = (int)json.GetInt("window_width", window_width);
  window_height = (int)json.GetInt("window_height", window_height);
  last_tab_count = (int)json.GetInt("last_tab_count", last_tab_count);

  if (window_width  < 640) window_width  = 1440;
  if (window_height < 480) window_height = 920;

  // 首次啟動：把預設值寫回，讓使用者知道檔案在哪、可以直接編輯
  if (raw.empty()) Save(path);
}

void AppConfig::Save(const std::wstring& path) const {
  JsonObject json;
  json.SetString("theme_mode", ToUtf8(theme_mode));
  json.SetString("homepage", ToUtf8(homepage));
  json.SetString("search_url", ToUtf8(search_url));
  json.SetString("startup_mode", ToUtf8(startup_mode));
  json.SetBool("show_bookmarks_bar", show_bookmarks_bar);
  json.SetInt("window_width", window_width);
  json.SetInt("window_height", window_height);
  json.SetInt("last_tab_count", last_tab_count);
  WriteTextFile(path, json.Serialize());
}

}  // namespace lumen
