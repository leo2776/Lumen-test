// ===========================================================================
//  Lumen Browser — core/TabManager.h
//  分頁生命週期管理：建立 / 切換 / 關閉 CEF browser，維護前景分頁、
//  視圖尺寸廣播、歷史紀錄與 session 續存。
// ===========================================================================
#pragma once

#include "core/Platform.h"

#include "core/AppConfig.h"
#include "core/BookmarkStore.h"
#include "core/HistoryStore.h"
#include "core/Tab.h"

namespace lumen {

class BrowserUI;

class TabManager {
 public:
  TabManager(BrowserUI* ui, AppConfig* config, HistoryStore* history, BookmarkStore* bookmarks);
  ~TabManager();

  bool Initialize();   // 依設定開啟起始分頁 / 還原 session

  // index < 0 表示附加到最後
  Tab* CreateTab(const std::wstring& url, bool foreground, int index = -1);
  void CloseTab(int index);
  void ActivateTab(int index);

  Tab* ActiveTab() const;
  Tab* TabAt(int index) const;
  int Count() const { return (int)tabs_.size(); }
  int ActiveIndex() const { return active_; }

  void SetContentSize(int pixel_width, int pixel_height, float dpi_scale);

  // 對前景分頁操作
  void LoadUrl(const std::wstring& url);
  void GoBack();
  void GoForward();
  void Reload(bool bypass_cache);
  void StopLoading();
  void ZoomStep(double delta);
  void ResetZoom();
  void PrintActive();
  void SavePageActive();

  // 關閉所有分頁；all_closed_called 由 MainWindow 決定何時真正結束行程
  void CloseAll(bool force);

  // ---- CEF 回呼 ---------------------------------------------------------
  Tab* FindTabByBrowser(CefRefPtr<CefBrowser> browser) const;
  void OnBrowserCreated(Tab* tab, CefRefPtr<CefBrowser> browser);
  void OnBrowserClosing(Tab* tab);
  void OnBrowserClosed(Tab* tab);
  void RecordHistory(Tab* tab);

  BrowserUI* ui() const { return ui_; }
  AppConfig* config() const { return config_; }
  HistoryStore* history() const { return history_; }
  BookmarkStore* bookmarks() const { return bookmarks_; }

  void SaveSession();

 private:
  void FocusOnly(Tab* tab);            // 設定前景分頁並處理 WasHidden
  void ApplyContentSizeTo(Tab* tab);
  std::wstring SessionFile() const;

  BrowserUI* ui_ = nullptr;
  AppConfig* config_ = nullptr;
  HistoryStore* history_ = nullptr;
  BookmarkStore* bookmarks_ = nullptr;

  std::vector<std::unique_ptr<Tab>> tabs_;
  int active_ = -1;
  int next_id_ = 1;
  int content_width_ = 0;
  int content_height_ = 0;
  float dpi_scale_ = 1.0f;
  bool closing_all_ = false;
};

}  // namespace lumen
