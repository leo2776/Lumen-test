#include "core/BookmarkStore.h"

#include "util/WinUtil.h"

namespace lumen {
namespace {

std::wstring SanitizeField(const std::wstring& in) {
  std::wstring out = in;
  for (auto& c : out) {
    if (c == L'\t' || c == L'\r' || c == L'\n') c = L' ';
  }
  return out;
}

}  // namespace

void BookmarkStore::Load(const std::wstring& path) {
  path_ = path;
  items_.clear();
  const std::string raw = ReadTextFile(path);
  if (raw.empty()) return;

  const std::wstring text = ToWide(raw);
  size_t pos = 0;
  while (pos < text.size()) {
    size_t eol = text.find(L'\n', pos);
    if (eol == std::wstring::npos) eol = text.size();
    const std::wstring line = text.substr(pos, eol - pos);
    pos = eol + 1;
    if (line.empty() || line[0] == L'#') continue;

    const size_t tab = line.find(L'\t');
    Bookmark bm;
    if (tab == std::wstring::npos) {
      bm.url = line;                       // 只有 URL：標題稍後由頁面提供
    } else {
      bm.title = line.substr(0, tab);
      bm.url = line.substr(tab + 1);
    }
    if (bm.url.empty()) continue;
    if (bm.title.empty()) bm.title = bm.url;
    items_.push_back(std::move(bm));
  }
  dirty_ = false;
}

void BookmarkStore::Flush() {
  if (!dirty_ || path_.empty()) return;
  std::string out;
  out.reserve(items_.size() * 96);
  out += "# Lumen bookmarks: title\\turl\r\n";
  for (const auto& bm : items_) {
    out += ToUtf8(bm.title);
    out += '\t';
    out += ToUtf8(bm.url);
    out += "\r\n";
  }
  if (WriteTextFile(path_, out)) dirty_ = false;
}

bool BookmarkStore::Contains(const std::wstring& url) const {
  for (const auto& bm : items_) {
    if (bm.url == url) return true;
  }
  return false;
}

bool BookmarkStore::Toggle(const std::wstring& title, const std::wstring& url) {
  if (url.empty()) return false;
  if (Contains(url)) {
    RemoveByUrl(url);
    return false;
  }
  Bookmark bm;
  bm.title = SanitizeField(title.empty() ? url : title);
  bm.url = url;
  items_.push_back(std::move(bm));
  dirty_ = true;
  Flush();
  return true;
}

void BookmarkStore::RemoveByUrl(const std::wstring& url) {
  for (auto it = items_.begin(); it != items_.end(); ++it) {
    if (it->url == url) {
      items_.erase(it);
      dirty_ = true;
      Flush();
      return;
    }
  }
}

void BookmarkStore::RemoveAt(size_t index) {
  if (index >= items_.size()) return;
  items_.erase(items_.begin() + (ptrdiff_t)index);
  dirty_ = true;
  Flush();
}

}  // namespace lumen
