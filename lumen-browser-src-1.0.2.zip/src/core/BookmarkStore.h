// ===========================================================================
//  Lumen Browser — core/BookmarkStore.h
//  書籤，儲存於 ./browser_data/config/bookmarks.tsv
// ===========================================================================
#pragma once

#include "core/Platform.h"

namespace lumen {

struct Bookmark {
  std::wstring title;
  std::wstring url;
};

class BookmarkStore {
 public:
  void Load(const std::wstring& path);
  void Flush();

  const std::vector<Bookmark>& items() const { return items_; }

  // 若已存在則移除 (回傳 false)，否則新增 (回傳 true)
  bool Toggle(const std::wstring& title, const std::wstring& url);
  bool Contains(const std::wstring& url) const;
  void RemoveByUrl(const std::wstring& url);
  void RemoveAt(size_t index);

 private:
  std::vector<Bookmark> items_;
  std::wstring path_;
  bool dirty_ = false;
};

}  // namespace lumen
