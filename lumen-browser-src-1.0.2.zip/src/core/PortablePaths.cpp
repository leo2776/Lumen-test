#include "core/PortablePaths.h"

#include "util/WinUtil.h"

namespace lumen {
namespace {

std::wstring g_exe_path;
std::wstring g_root_dir;
std::wstring g_data_dir;
std::wstring g_profile_dir;
std::wstring g_cache_dir;
std::wstring g_crash_dir;
std::wstring g_log_dir;
std::wstring g_config_dir;
std::wstring g_ui_dir;
std::wstring g_downloads_dir;
std::wstring g_temp_dir;
bool g_initialized = false;

HANDLE g_instance_mutex = nullptr;
HANDLE g_instance_lock_file = INVALID_HANDLE_VALUE;

// 若使用者設定 LUMEN_DATA_DIR，允許把可攜資料夾搬到他處（仍為絕對路徑自足）。
std::wstring ResolveDataDir(const std::wstring& root) {
  const DWORD needed = ::GetEnvironmentVariableW(L"LUMEN_DATA_DIR", nullptr, 0);
  if (needed > 1) {
    std::wstring override_path(needed, L'\0');
    const DWORD written = ::GetEnvironmentVariableW(L"LUMEN_DATA_DIR", &override_path[0], needed);
    if (written > 0) {
      override_path.resize(written);
      return AbsolutePath(override_path);
    }
  }
  return JoinPath(root, kDataFolder);
}

bool MakeAll(const std::vector<std::wstring>& dirs) {
  for (const auto& d : dirs) {
    if (!EnsureDirectory(d)) return false;
  }
  return true;
}

}  // namespace

bool PortablePaths::Initialize() {
  if (g_initialized) return true;

  g_exe_path = ExePath();
  if (g_exe_path.empty()) return false;

  g_root_dir = ExeDirectory();
  g_data_dir = ResolveDataDir(g_root_dir);
  if (g_data_dir.empty()) return false;

  g_profile_dir   = JoinPath(g_data_dir, L"profile");
  g_cache_dir     = JoinPath(g_data_dir, L"cache");
  g_crash_dir     = JoinPath(g_data_dir, L"crash");
  g_log_dir       = JoinPath(g_data_dir, L"logs");
  g_config_dir    = JoinPath(g_data_dir, L"config");
  g_ui_dir        = JoinPath(g_data_dir, L"ui");
  g_downloads_dir = JoinPath(g_data_dir, L"downloads");
  g_temp_dir      = JoinPath(g_data_dir, L"temp");

  if (!MakeAll({g_data_dir, g_profile_dir, g_cache_dir, g_crash_dir, g_log_dir, g_config_dir,
                g_ui_dir, g_downloads_dir, g_temp_dir})) {
    return false;
  }

  // 可攜性標記檔：方便使用者/維運確認資料被綁在何處。
  const std::wstring marker = JoinPath(g_data_dir, L"PORTABLE.txt");
  if (!FileExists(marker)) {
    std::string text;
    text += "Lumen portable data root.\r\n";
    text += "Everything in this folder belongs to the browser in ";
    text += ToUtf8(g_root_dir);
    text += "\r\nDelete this folder to reset the browser completely.\r\n";
    WriteTextFile(marker, text);
  }

  g_initialized = true;
  return true;
}

bool PortablePaths::IsInitialized() { return g_initialized; }

const std::wstring& PortablePaths::ExePath() { return g_exe_path; }
const std::wstring& PortablePaths::RootDir() { return g_root_dir; }
const std::wstring& PortablePaths::DataDir() { return g_data_dir; }
const std::wstring& PortablePaths::ProfileDir() { return g_profile_dir; }
const std::wstring& PortablePaths::CacheDir() { return g_cache_dir; }
const std::wstring& PortablePaths::CrashDir() { return g_crash_dir; }
const std::wstring& PortablePaths::LogDir() { return g_log_dir; }
const std::wstring& PortablePaths::ConfigDir() { return g_config_dir; }
const std::wstring& PortablePaths::UiDir() { return g_ui_dir; }
const std::wstring& PortablePaths::DownloadsDir() { return g_downloads_dir; }
const std::wstring& PortablePaths::TempDir() { return g_temp_dir; }

std::wstring PortablePaths::ConfigFile(const std::wstring& name) { return JoinPath(g_config_dir, name); }
std::wstring PortablePaths::LogFile(const std::wstring& name) { return JoinPath(g_log_dir, name); }

void PortablePaths::ApplyProcessEnvironment() {
  if (!g_initialized) return;
  // 子行程 (renderer / gpu / network service) 繼承這些變數，
  // 因此它們的暫存檔同樣被關在可攜資料夾內。
  ::SetEnvironmentVariableW(L"TMP", g_temp_dir.c_str());
  ::SetEnvironmentVariableW(L"TEMP", g_temp_dir.c_str());
  ::SetEnvironmentVariableW(L"TMPDIR", g_temp_dir.c_str());
  // 阻止 Chromium 使用系統層級的 crash 上報目錄。
  ::SetEnvironmentVariableW(L"CHROME_CRASHPAD_PIPE_NAME", nullptr);
  ::SetEnvironmentVariableW(L"BREAKPAD_DUMP_LOCATION", g_crash_dir.c_str());
}

bool PortablePaths::LockSingleInstance() {
  if (!g_initialized) return false;

  // 1) 具名 Mutex：名稱包含資料夾雜湊，避免同機多份可攜副本互鎖。
  std::wstring key = g_data_dir;
  unsigned long long hash = 1469598103934665603ull;
  for (wchar_t c : key) {
    hash ^= (unsigned long long)c;
    hash *= 1099511628211ull;
  }
  wchar_t mutex_name[96];
  ::swprintf_s(mutex_name, L"Local\\LumenBrowser.Instance.%016llX", hash);
  g_instance_mutex = ::CreateMutexW(nullptr, FALSE, mutex_name);
  if (!g_instance_mutex) return false;
  if (::GetLastError() == ERROR_ALREADY_EXISTS) {
    ::CloseHandle(g_instance_mutex);
    g_instance_mutex = nullptr;
    return false;
  }
  ::ReleaseMutex(g_instance_mutex);   // 持有參照即可，執行緒不需長期持有

  // 2) 資料夾鎖檔：額外保護 (例如使用者在兩台機器同步同一個資料夾)。
  const std::wstring lock_path = JoinPath(g_data_dir, L"instance.lock");
  g_instance_lock_file = ::CreateFileW(lock_path.c_str(), GENERIC_READ | GENERIC_WRITE,
                                       FILE_SHARE_READ, nullptr, OPEN_ALWAYS,
                                       FILE_ATTRIBUTE_HIDDEN, nullptr);
  if (g_instance_lock_file == INVALID_HANDLE_VALUE) return false;
  ::SetFilePointer(g_instance_lock_file, 0, nullptr, FILE_BEGIN);
  ::SetEndOfFile(g_instance_lock_file);
  const std::string pid = std::to_string((long long)::GetCurrentProcessId());
  DWORD written = 0;
  ::WriteFile(g_instance_lock_file, pid.data(), (DWORD)pid.size(), &written, nullptr);
  return true;
}

void PortablePaths::UnlockSingleInstance() {
  if (g_instance_lock_file != INVALID_HANDLE_VALUE) {
    ::CloseHandle(g_instance_lock_file);
    g_instance_lock_file = INVALID_HANDLE_VALUE;
  }
  if (g_instance_mutex) {
    ::CloseHandle(g_instance_mutex);
    g_instance_mutex = nullptr;
  }
}

}  // namespace lumen
