#include "core/UiPages.h"

#include "util/WinUtil.h"

namespace lumen {
namespace ui_pages {
namespace {

const char kNewTabHtml[] = R"HTML(<!doctype html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>新分頁</title>
<style>
  :root { color-scheme: dark light; --bg:#202124; --fg:#e8eaed; --dim:#9aa0a6; --card:#292a2d;
          --border:#3c4043; --accent:#8ab4f8; }
  @media (prefers-color-scheme: light) {
    :root { --bg:#ffffff; --fg:#202124; --dim:#5f6368; --card:#f1f3f4; --border:#dadce0;
            --accent:#1a73e8; }
  }
  * { box-sizing: border-box; }
  html, body { height: 100%; margin: 0; }
  body { background: var(--bg); color: var(--fg); display: flex; flex-direction: column;
         align-items: center; justify-content: center; gap: 28px; padding: 24px;
         font-family: "Segoe UI", "Microsoft JhengHei", system-ui, sans-serif; }
  .brand { display: flex; align-items: center; gap: 14px; }
  .logo { width: 56px; height: 56px; border-radius: 50%;
          background: linear-gradient(180deg,#4c8df6,#1a73e8);
          box-shadow: 0 0 0 7px rgba(138,180,248,.18) inset; }
  .brand h1 { font-size: 30px; font-weight: 600; margin: 0; letter-spacing: .5px; }
  form { width: min(620px, 90vw); }
  input[type=search] { width: 100%; padding: 14px 20px; font-size: 15px; color: var(--fg);
      background: var(--card); border: 1px solid var(--border); border-radius: 24px;
      outline: none; transition: border-color .15s, box-shadow .15s; }
  input[type=search]:focus { border-color: var(--accent);
      box-shadow: 0 0 0 3px rgba(138,180,248,.22); }
  .tiles { display: grid; grid-template-columns: repeat(auto-fit, 92px); gap: 14px;
           justify-content: center; width: min(620px, 90vw); }
  .tile { display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 12px 6px;
          border-radius: 12px; text-decoration: none; color: var(--fg); transition: background .15s; }
  .tile:hover { background: var(--card); }
  .dot { width: 40px; height: 40px; border-radius: 50%; display: grid; place-items: center;
         font-size: 17px; font-weight: 600; color: #fff; }
  .tile span { font-size: 12px; color: var(--dim); max-width: 84px; overflow: hidden;
               text-overflow: ellipsis; white-space: nowrap; }
  footer { position: fixed; bottom: 14px; font-size: 11px; color: var(--dim); }
</style>
</head>
<body>
  <div class="brand"><div class="logo"></div><h1>Lumen</h1></div>
  <form action="https://www.google.com/search" method="get" autocomplete="off">
    <input type="search" name="q" placeholder="搜尋 Google 或輸入網址" autofocus>
  </form>
  <div class="tiles">
    <a class="tile" href="https://www.google.com"><div class="dot" style="background:#1a73e8">G</div><span>Google</span></a>
    <a class="tile" href="https://www.youtube.com"><div class="dot" style="background:#ea4335">Y</div><span>YouTube</span></a>
    <a class="tile" href="https://github.com"><div class="dot" style="background:#333">G</div><span>GitHub</span></a>
    <a class="tile" href="https://developer.mozilla.org"><div class="dot" style="background:#188038">M</div><span>MDN</span></a>
    <a class="tile" href="https://news.ycombinator.com"><div class="dot" style="background:#f9ab00">H</div><span>Hacker News</span></a>
    <a class="tile" href="https://www.wikipedia.org"><div class="dot" style="background:#5f6368">W</div><span>Wikipedia</span></a>
  </div>
  <footer>Lumen Browser — C++ 自研外殼 + CEF/Chromium 渲染核心</footer>
</body>
</html>
)HTML";

std::string EscapeHtml(const std::wstring& text) {
  const std::string utf8 = ToUtf8(text);
  std::string out;
  out.reserve(utf8.size() + 16);
  for (char c : utf8) {
    switch (c) {
      case '&': out += "&amp;"; break;
      case '<': out += "&lt;"; break;
      case '>': out += "&gt;"; break;
      case '"': out += "&quot;"; break;
      case '\'': out += "&#39;"; break;
      default: out.push_back(c);
    }
  }
  return out;
}

const char* kPageStyle = R"CSS(
:root { color-scheme: dark light; --bg:#202124; --fg:#e8eaed; --dim:#9aa0a6; --card:#292a2d;
        --border:#3c4043; --accent:#8ab4f8; }
@media (prefers-color-scheme: light) {
  :root { --bg:#ffffff; --fg:#202124; --dim:#5f6368; --card:#f8f9fa; --border:#dadce0;
          --accent:#1a73e8; }
}
body { margin:0; background:var(--bg); color:var(--fg); padding:32px min(8vw,72px);
       font-family:"Segoe UI","Microsoft JhengHei",system-ui,sans-serif; }
h1 { font-size:22px; font-weight:600; margin:0 0 6px; }
p.sub { color:var(--dim); font-size:13px; margin:0 0 28px; }
.row { display:flex; gap:14px; padding:11px 14px; border-radius:10px; align-items:baseline;
       text-decoration:none; color:var(--fg); border:1px solid transparent; }
.row:hover { background:var(--card); border-color:var(--border); }
.row .t { font-size:13px; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.row .u { font-size:11px; color:var(--dim); max-width:46%; overflow:hidden;
          text-overflow:ellipsis; white-space:nowrap; }
.row .d { font-size:11px; color:var(--dim); width:130px; text-align:right; }
.empty { color:var(--dim); font-size:13px; }
)CSS";

}  // namespace

void EnsureDefaultPages(const std::wstring& ui_dir) {
  EnsureDirectory(ui_dir);
  const std::wstring path = JoinPath(ui_dir, L"newtab.html");
  if (!FileExists(path)) WriteTextFile(path, kNewTabHtml);
}

std::wstring WriteHistoryPage(const std::wstring& ui_dir, const std::vector<HistoryEntry>& entries) {
  EnsureDirectory(ui_dir);
  std::string html;
  html += "<!doctype html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\">";
  html += "<title>瀏覽紀錄</title><style>";
  html += kPageStyle;
  html += "</style></head><body><h1>瀏覽紀錄</h1>";
  html += "<p class=\"sub\">資料來源：browser_data/config/history.tsv</p>";

  if (entries.empty()) {
    html += "<div class=\"empty\">目前沒有瀏覽紀錄。</div>";
  } else {
    int shown = 0;
    for (auto it = entries.rbegin(); it != entries.rend() && shown < 2000; ++it, ++shown) {
      html += "<a class=\"row\" href=\"" + EscapeHtml(it->url) + "\">";
      html += "<span class=\"t\">" + EscapeHtml(it->title.empty() ? it->url : it->title) + "</span>";
      html += "<span class=\"u\">" + EscapeHtml(it->url) + "</span>";
      html += "<span class=\"d\">" + ToUtf8(FormatTimeForHistory(it->timestamp)) + "</span>";
      html += "</a>";
    }
  }
  html += "</body></html>";

  const std::wstring path = JoinPath(ui_dir, L"history.html");
  WriteTextFile(path, html);
  return path;
}

std::wstring WriteBookmarksPage(const std::wstring& ui_dir,
                                const std::vector<Bookmark>& bookmarks) {
  EnsureDirectory(ui_dir);
  std::string html;
  html += "<!doctype html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\">";
  html += "<title>書籤</title><style>";
  html += kPageStyle;
  html += "</style></head><body><h1>書籤</h1>";
  html += "<p class=\"sub\">資料來源：browser_data/config/bookmarks.tsv</p>";

  if (bookmarks.empty()) {
    html += "<div class=\"empty\">還沒有書籤。在網址列右側按星號即可加入。</div>";
  } else {
    for (const auto& bm : bookmarks) {
      html += "<a class=\"row\" href=\"" + EscapeHtml(bm.url) + "\">";
      html += "<span class=\"t\">" + EscapeHtml(bm.title) + "</span>";
      html += "<span class=\"u\">" + EscapeHtml(bm.url) + "</span>";
      html += "</a>";
    }
  }
  html += "</body></html>";

  const std::wstring path = JoinPath(ui_dir, L"bookmarks.html");
  WriteTextFile(path, html);
  return path;
}

}  // namespace ui_pages
}  // namespace lumen
