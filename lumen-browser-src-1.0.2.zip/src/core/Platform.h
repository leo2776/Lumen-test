// ===========================================================================
//  Lumen Browser — core/Platform.h
//  Windows 平台共通前置宣告 (prelude). 所有檔案第一行都 include 這個標頭，
//  確保 Win32 巨集 (min/max)、UNICODE、C++ 標準容器在整份程式碼中行為一致。
// ===========================================================================
#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <windows.h>

#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdlib>
#include <cwchar>
#include <cstdio>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <algorithm>
#include <utility>
#include <new>

namespace lumen {

// 全域常數：版本與品牌資訊
constexpr wchar_t kAppName[]      = L"Lumen";
constexpr wchar_t kAppVersion[]   = L"1.0.0";
constexpr wchar_t kAppVendor[]    = L"Lumen Project";
constexpr wchar_t kWindowClass[]  = L"LumenBrowserMainWindow";
constexpr wchar_t kDataFolder[]   = L"browser_data";   // 可攜資料根目錄名稱

// 自訂視窗訊息
constexpr UINT kMsgPumpWork       = WM_APP + 0x100;    // CEF 外部訊息幫浦
constexpr UINT kMsgFrameArrived   = WM_APP + 0x101;    // 背景執行緒通知有新的 frame
constexpr UINT kMsgTabStateDirty  = WM_APP + 0x102;    // 分頁狀態 (title/url/loading) 變更
constexpr UINT kMsgAllTabsClosed  = WM_APP + 0x103;    // 所有分頁已關閉 -> 非同步銷毀視窗

}  // namespace lumen
