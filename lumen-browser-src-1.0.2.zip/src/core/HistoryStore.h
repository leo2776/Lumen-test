// ===========================================================================
//  Lumen Browser — core/HistoryStore.h
//  瀏覽紀錄，儲存於 ./browser_data/config/history.tsv (tab 分隔，可讀可編輯)
// ===========================================================================
#pragma once

#include "core/Platform.h"

namespace lumen {

struct HistoryEntry {
  int64_t timestamp = 0;     // Unix 秒
  std::wstring url;
  std::wstring title;
};

class HistoryStore {
 public:
  void Load(const std::wstring& path);
  void Flush();                                   // 有變更才寫檔
  void Add(const std::wstring& url, const std::wstring& title);
  void Clear();

  const std::vector<HistoryEntry>& entries() const { return entries_; }
  std::vector<HistoryEntry> MostRecent(size_t max) const;

 private:
  std::vector<HistoryEntry> entries_;
  std::wstring path_;
  bool dirty_ = false;
};

}  // namespace lumen
