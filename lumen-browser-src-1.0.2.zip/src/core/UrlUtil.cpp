#include "core/UrlUtil.h"

#include "util/WinUtil.h"

#include <cwchar>
#include <cstdlib>
#include <cstring>

namespace lumen {
namespace {

bool StartsWithNoCase(const std::wstring& s, const wchar_t* prefix) {
  const size_t n = ::wcslen(prefix);
  if (s.size() < n) return false;
  return _wcsnicmp(s.c_str(), prefix, n) == 0;
}

bool HasScheme(const std::wstring& s) {
  const size_t colon = s.find(L':');
  if (colon == std::wstring::npos || colon == 0) return false;
  for (size_t i = 0; i < colon; ++i) {
    const wchar_t c = s[i];
    const bool ok = (c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z') ||
                    (c >= L'0' && c <= L'9') || c == L'+' || c == L'-' || c == L'.';
    if (!ok) return false;
  }
  return true;   // 允許 http:, https:, file:, about:, data:, view-source: 等
}

bool LooksLikeHost(const std::wstring& s) {
  if (s.empty()) return false;
  if (s.find(L' ') != std::wstring::npos) return false;
  // localhost / IP / 含點的網域
  if (StartsWithNoCase(s, L"localhost")) return true;
  if (s.find(L'.') == std::wstring::npos) {
    // 單一詞彙：若使用者輸入 "intranet:8080" 之類仍視為網址
    const size_t colon = s.find(L':');
    return colon != std::wstring::npos && colon + 1 < s.size() &&
           s.find_first_not_of(L"0123456789", colon + 1) == std::wstring::npos;
  }
  // 網域最後一段必須是 2 個以上英文字母（排除 3.14 這種）
  const size_t dot = s.rfind(L'.');
  if (dot == std::wstring::npos || s.size() - dot - 1 < 2) {
    // 允許帶 port 的情況
    const size_t colon = s.find(L':');
    if (colon != std::wstring::npos) {
      const size_t hdot = s.rfind(L'.', colon);
      return hdot != std::wstring::npos;
    }
    return false;
  }
  for (size_t i = dot + 1; i < s.size(); ++i) {
    const wchar_t c = s[i];
    if (!((c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z'))) {
      // 可能遇到 :port 或 /path
      return c == L':' || c == L'/';
    }
  }
  return true;
}

void AppendUtf8PercentEscaped(std::wstring& out, const std::wstring& text) {
  const std::string utf8 = ToUtf8(text);
  for (unsigned char c : utf8) {
    const bool unreserved = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~';
    if (unreserved) {
      out.push_back((wchar_t)c);
    } else {
      wchar_t buf[8];
      ::swprintf_s(buf, L"%%%02X", c);
      out += buf;
    }
  }
}

std::wstring Trim(const std::wstring& s) {
  size_t b = 0, e = s.size();
  while (b < e && (s[b] == L' ' || s[b] == L'\t' || s[b] == L'\r' || s[b] == L'\n')) ++b;
  while (e > b && (s[e - 1] == L' ' || s[e - 1] == L'\t' || s[e - 1] == L'\r' || s[e - 1] == L'\n')) --e;
  return s.substr(b, e - b);
}

}  // namespace

std::wstring EscapeQueryParam(const std::wstring& text) {
  std::wstring out;
  out.reserve(text.size() * 3);
  AppendUtf8PercentEscaped(out, text);
  return out;
}

std::wstring ResolveUserInput(const std::wstring& input, const std::wstring& search_template) {
  std::wstring text = Trim(input);
  if (text.empty()) return L"about:blank";

  if (StartsWithNoCase(text, L"about:") || StartsWithNoCase(text, L"chrome:")) return text;
  if (StartsWithNoCase(text, L"view-source:")) return text;

  if (HasScheme(text)) {
    // 使用者已輸入完整 scheme
    return text;
  }

  // Windows 絕對路徑 → 轉成 file:// URL
  if (text.size() > 2 && ((text[1] == L':' && (text[2] == L'\\' || text[2] == L'/')) ||
                          StartsWithNoCase(text, L"\\\\"))) {
    return FileUrlFromPath(text);
  }

  // 相對/本地檔名：若執行檔旁真的存在就用 file://
  if (FileExists(text)) {
    return FileUrlFromPath(text);
  }

  if (LooksLikeHost(text)) {
    // 使用者輸入 "example.com/path" → https://example.com/path
    return L"https://" + text;
  }

  // 其餘一律當搜尋關鍵字
  std::wstring url = search_template.empty() ? L"https://www.google.com/search?q=%s" : search_template;
  const size_t pos = url.find(L"%s");
  if (pos == std::wstring::npos) return url + EscapeQueryParam(text);
  return url.substr(0, pos) + EscapeQueryParam(text) + url.substr(pos + 2);
}

std::wstring DisplayUrl(const std::wstring& url) {
  if (url.empty()) return url;
  if (StartsWithNoCase(url, L"https://")) {
    std::wstring out = url.substr(8);
    while (!out.empty() && out.back() == L'/') out.pop_back();
    return out;
  }
  if (StartsWithNoCase(url, L"http://")) {
    std::wstring out = url.substr(7);
    while (!out.empty() && out.back() == L'/') out.pop_back();
    return out;
  }
  return url;
}

std::wstring UrlHost(const std::wstring& url) {
  std::wstring rest;
  if (StartsWithNoCase(url, L"https://")) {
    rest = url.substr(8);
  } else if (StartsWithNoCase(url, L"http://")) {
    rest = url.substr(7);
  } else {
    return std::wstring();
  }
  const size_t slash = rest.find_first_of(L"/?#");
  return slash == std::wstring::npos ? rest : rest.substr(0, slash);
}

bool IsHttpsUrl(const std::wstring& url) { return StartsWithNoCase(url, L"https://"); }

bool IsFileUrl(const std::wstring& url) { return StartsWithNoCase(url, L"file://"); }

bool IsInternalUrl(const std::wstring& url) {
  return IsFileUrl(url) || StartsWithNoCase(url, L"about:") || StartsWithNoCase(url, L"data:");
}

}  // namespace lumen
