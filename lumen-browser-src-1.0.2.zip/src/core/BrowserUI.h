// ===========================================================================
//  Lumen Browser — core/BrowserUI.h
//  核心 (TabManager/CEF handlers) 與 UI 層 (MainWindow) 之間的單向介面。
//  用介面而非直接相依，避免 core <-> ui 的循環 include。
// ===========================================================================
#pragma once

#include "core/Platform.h"

#include "include/cef_context_menu_handler.h"
#include "include/cef_menu_model.h"

namespace lumen {

class Tab;

class BrowserUI {
 public:
  virtual ~BrowserUI() = default;

  // OSR 父視窗 (CEF 用來決定 popup / IME 行為)
  virtual HWND window_handle() = 0;

  // 分頁內容有新的 frame，需要重繪
  virtual void OnTabFrameReady(Tab* tab) = 0;
  // 標題 / URL / 載入狀態 / 上一頁下一頁狀態變更
  virtual void OnTabChanged(Tab* tab) = 0;
  // 分頁剛被建立 (尚未有 browser 物件)
  virtual void OnTabCreated(Tab* tab) = 0;
  // 分頁的 browser 已完全關閉
  virtual void OnTabClosed(Tab* tab) = 0;
  // 最後一個分頁也關了 → 關閉視窗
  virtual void OnAllTabsClosed() = 0;

  virtual void OnCursorChanged(HCURSOR cursor) = 0;
  virtual void OnPopupRequest(Tab* source, const std::wstring& url, bool foreground) = 0;
  virtual void OnStatusMessage(Tab* tab, const std::wstring& message) = 0;

  // 右鍵選單：由 UI 層繪製 Chrome 風格的深色選單
  virtual void OnContextMenuRequested(Tab* tab,
                                      CefRefPtr<CefMenuModel> model,
                                      CefRefPtr<CefRunContextMenuCallback> callback) = 0;
};

}  // namespace lumen
