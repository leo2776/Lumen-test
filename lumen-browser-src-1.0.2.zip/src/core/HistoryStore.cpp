#include "core/HistoryStore.h"

#include "util/WinUtil.h"

#include <cstdlib>

namespace lumen {
namespace {

constexpr size_t kMaxEntries = 20000;   // 超過就從最舊的開始丟

std::wstring SanitizeField(const std::wstring& in) {
  std::wstring out = in;
  for (auto& c : out) {
    if (c == L'\t' || c == L'\r' || c == L'\n') c = L' ';
  }
  return out;
}

}  // namespace

void HistoryStore::Load(const std::wstring& path) {
  path_ = path;
  entries_.clear();
  const std::string raw = ReadTextFile(path);
  if (raw.empty()) return;

  const std::wstring text = ToWide(raw);
  size_t pos = 0;
  while (pos < text.size()) {
    size_t eol = text.find(L'\n', pos);
    if (eol == std::wstring::npos) eol = text.size();
    const std::wstring line = text.substr(pos, eol - pos);
    pos = eol + 1;
    if (line.empty() || line[0] == L'#') continue;

    // timestamp \t url \t title
    const size_t t1 = line.find(L'\t');
    if (t1 == std::wstring::npos) continue;
    const size_t t2 = line.find(L'\t', t1 + 1);
    HistoryEntry entry;
    entry.timestamp = _wtoi64(line.substr(0, t1).c_str());
    entry.url = line.substr(t1 + 1, (t2 == std::wstring::npos ? line.size() : t2) - t1 - 1);
    if (t2 != std::wstring::npos) entry.title = line.substr(t2 + 1);
    if (entry.url.empty()) continue;
    entries_.push_back(std::move(entry));
  }
  dirty_ = false;
}

void HistoryStore::Flush() {
  if (!dirty_ || path_.empty()) return;
  std::string out;
  out.reserve(entries_.size() * 96);
  out += "# Lumen history: timestamp\\turl\\ttitle\r\n";
  for (const auto& e : entries_) {
    out += std::to_string((long long)e.timestamp);
    out += '\t';
    out += ToUtf8(e.url);
    out += '\t';
    out += ToUtf8(e.title);
    out += "\r\n";
  }
  if (WriteTextFile(path_, out)) dirty_ = false;
}

void HistoryStore::Add(const std::wstring& url, const std::wstring& title) {
  if (url.empty() || url == L"about:blank") return;
  // 同一 URL 連續瀏覽時只更新時間與標題，避免紀錄被洗版
  if (!entries_.empty() && entries_.back().url == url) {
    entries_.back().timestamp = UnixNow();
    if (!title.empty()) entries_.back().title = SanitizeField(title);
    dirty_ = true;
    return;
  }
  HistoryEntry entry;
  entry.timestamp = UnixNow();
  entry.url = url;
  entry.title = SanitizeField(title);
  entries_.push_back(std::move(entry));
  if (entries_.size() > kMaxEntries) {
    entries_.erase(entries_.begin(), entries_.begin() + (entries_.size() - kMaxEntries));
  }
  dirty_ = true;
  Flush();   // 每筆立即落地：可攜式瀏覽器被強制關閉也不會遺失
}

void HistoryStore::Clear() {
  entries_.clear();
  dirty_ = true;
  Flush();
}

std::vector<HistoryEntry> HistoryStore::MostRecent(size_t max) const {
  std::vector<HistoryEntry> out;
  out.reserve(std::min(max, entries_.size()));
  for (auto it = entries_.rbegin(); it != entries_.rend() && out.size() < max; ++it) {
    out.push_back(*it);
  }
  return out;
}

}  // namespace lumen
