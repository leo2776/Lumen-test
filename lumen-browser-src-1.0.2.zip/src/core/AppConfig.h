// ===========================================================================
//  Lumen Browser — core/AppConfig.h
//  使用者設定，持久化於 ./browser_data/config/settings.json
// ===========================================================================
#pragma once

#include "core/Platform.h"

namespace lumen {

struct AppConfig {
  // 外觀："dark" | "light"
  std::wstring theme_mode = L"dark";
  // 首頁
  std::wstring homepage = L"https://www.google.com/";
  // 搜尋引擎樣板，%s 會被取代為編碼後的查詢字串
  std::wstring search_url = L"https://www.google.com/search?q=%s";
  // 啟動模式："newtab" | "homepage"
  std::wstring startup_mode = L"newtab";
  bool show_bookmarks_bar = true;
  int window_width = 1440;
  int window_height = 920;
  int last_tab_count = 1;   // 上次關閉時的分頁數（僅供新分頁預設值參考）

  bool dark() const { return theme_mode != L"light"; }

  void Load(const std::wstring& path);
  void Save(const std::wstring& path) const;
};

}  // namespace lumen
