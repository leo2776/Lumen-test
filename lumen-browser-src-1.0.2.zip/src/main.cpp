// ===========================================================================
//  Lumen Browser — main.cpp
//  程式進入點：
//    1. 啟用 Per-Monitor V2 DPI
//    2. CEF 子行程分流 (renderer / gpu / utility ...)
//    3. 建立可攜資料夾 + 單一實例鎖
//    4. 初始化 CEF (視窗 + 離屏渲染 + 外部訊息幫浦)
//    5. 建立自研視窗、進入 Win32 訊息迴圈
//    6. 依序關閉：CEF → 繪圖層 → 解除鎖
// ===========================================================================
#include "app/LumenApp.h"
#include "app/MessagePump.h"
#include "core/AppConfig.h"
#include "core/BookmarkStore.h"
#include "core/HistoryStore.h"
#include "core/PortablePaths.h"
#include "ui/Gfx.h"
#include "ui/MainWindow.h"
#include "util/WinUtil.h"

#include "include/cef_app.h"
#include "include/cef_command_line.h"

#include <objbase.h>
#include <shellapi.h>

#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "advapi32.lib")

namespace lumen {
namespace {

HWND g_pump_window = nullptr;
UINT_PTR g_pump_timer = 0;
constexpr UINT_PTR kPumpTimerId = 0x4C50;   // 'LP'

// 隱藏訊息視窗：CEF 的需求 (OnScheduleMessagePumpWork) 會被轉成這裡的
// PostMessage / SetTimer，由主訊息迴圈喚醒 CefDoMessageLoopWork()。
LRESULT CALLBACK PumpWndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam) {
  switch (message) {
    case kMsgPumpWork:
      if (g_pump_timer) {
        ::KillTimer(hwnd, kPumpTimerId);
        g_pump_timer = 0;
      }
      CefDoMessageLoopWork();
      return 0;
    case WM_TIMER:
      if (wparam == kPumpTimerId) {
        ::KillTimer(hwnd, kPumpTimerId);
        g_pump_timer = 0;
        CefDoMessageLoopWork();
      }
      return 0;
    case WM_DESTROY:
      g_pump_window = nullptr;
      return 0;
    default:
      break;
  }
  return ::DefWindowProcW(hwnd, message, wparam, lparam);
}

bool CreatePumpWindow(HINSTANCE instance) {
  constexpr wchar_t kClass[] = L"LumenMessagePumpWindow";
  WNDCLASSEXW wc{};
  wc.cbSize = sizeof(wc);
  wc.lpfnWndProc = &PumpWndProc;
  wc.hInstance = instance;
  wc.lpszClassName = kClass;
  if (!::RegisterClassExW(&wc) && ::GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return false;
  // HWND_MESSAGE 子視窗不會出現在畫面上，也不需要任何 UI
  g_pump_window = ::CreateWindowExW(0, kClass, L"", 0, 0, 0, 0, 0, HWND_MESSAGE, nullptr, instance,
                                    nullptr);
  return g_pump_window != nullptr;
}

std::wstring FirstUrlArgument() {
  int argc = 0;
  LPWSTR* argv = ::CommandLineToArgvW(::GetCommandLineW(), &argc);
  if (!argv) return std::wstring();
  std::wstring url;
  for (int i = 1; i < argc; ++i) {
    const std::wstring arg = argv[i];
    if (arg.empty() || arg[0] == L'-' || arg[0] == L'/') continue;
    url = arg;
    break;
  }
  ::LocalFree(argv);
  return url;
}

}  // namespace

// 由 wWinMain 使用的錯誤提示 (需為 lumen 命名空間成員才能被外部呼叫)
static void ShowError(const wchar_t* text) {
  ::MessageBoxW(nullptr, text, kAppName, MB_ICONERROR | MB_OK);
}

// ---- app/MessagePump.h 的實作 -------------------------------------------
void InstallExternalPump(HWND pump_window) { g_pump_window = pump_window; }

void ScheduleExternalPumpWork(int64_t delay_ms) {
  if (!g_pump_window) return;
  if (delay_ms <= 0) {
    ::PostMessageW(g_pump_window, kMsgPumpWork, 0, 0);
  } else {
    if (!g_pump_timer) {
      g_pump_timer = ::SetTimer(g_pump_window, kPumpTimerId, (UINT)delay_ms, nullptr);
    }
  }
}

void ShutdownExternalPump() {
  if (g_pump_window) {
    ::DestroyWindow(g_pump_window);
    g_pump_window = nullptr;
  }
  g_pump_timer = 0;
}

}  // namespace lumen

int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow) {
  (void)hPrevInstance;
  (void)lpCmdLine;

  // ---- 1. DPI 與 COM --------------------------------------------------
  lumen::EnablePerMonitorDpi();
  const HRESULT com_result = ::OleInitialize(nullptr);
  (void)com_result;

  // ---- 2. 可攜路徑 (必須早於 CEF 初始化) -------------------------------
  if (!lumen::PortablePaths::Initialize()) {
    lumen::ShowError(L"無法在執行檔旁建立 browser_data 資料夾，請確認程式所在位置可寫入。");
    return 1;
  }
  lumen::PortablePaths::ApplyProcessEnvironment();

  // ---- 3. CEF 子行程分流 ----------------------------------------------
  //  同一個 exe 同時扮演 browser / renderer / gpu / utility 程序，
  //  因此 browser_subprocess_path 會指向自己 (見下方 CefSettings)。
  CefMainArgs main_args(hInstance);
  CefRefPtr<lumen::LumenApp> app(new lumen::LumenApp());
  {
    const int exit_code = CefExecuteProcess(main_args, app.get(), nullptr);
    if (exit_code >= 0) return exit_code;   // 這是子行程，工作已完成
  }

  // ---- 4. 單一實例 -----------------------------------------------------
  if (!lumen::PortablePaths::LockSingleInstance()) {
    // 已經有一份 Lumen 在使用同一個可攜資料夾 → 把它的視窗帶到前景
    HWND existing = ::FindWindowW(lumen::kWindowClass, nullptr);
    if (existing) {
      ::ShowWindow(existing, SW_RESTORE);
      ::SetForegroundWindow(existing);
    }
    return 0;
  }

  // ---- 5. CEF 設定 (可攜性 + OSR) --------------------------------------
  const std::wstring exe_path = lumen::PortablePaths::ExePath();
  const std::wstring data_dir = lumen::PortablePaths::DataDir();

  CefSettings settings;
  settings.no_sandbox = true;                 // 單一 exe 可攜模式 (見 README 的沙箱說明)
  settings.windowless_rendering_enabled = true;   // ★ 離屏渲染：UI 完全由我們合成
  settings.external_message_pump = true;          // ★ 與 Win32 訊息迴圈共用同一執行緒
  settings.multi_threaded_message_loop = false;
  settings.persist_session_cookies = true;
  settings.background_color = 0xFF202124;
  settings.log_severity = LOGSEVERITY_WARNING;

  CefString(&settings.browser_subprocess_path).FromWString(exe_path);
  CefString(&settings.root_cache_path).FromWString(data_dir);
  CefString(&settings.log_file).FromWString(lumen::PortablePaths::LogFile(L"cef.log"));
  CefString(&settings.locales_dir_path)
      .FromWString(lumen::JoinPath(lumen::PortablePaths::RootDir(), L"locales"));
  CefString(&settings.resources_dir_path).FromWString(lumen::PortablePaths::RootDir());
  CefString(&settings.locale).FromWString(L"zh-TW");
  CefString(&settings.accept_language_list).FromWString(L"zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7");
  // 注意：CEF >= 120 用 user_agent_product (舊版叫 product_version)
  CefString(&settings.user_agent_product).FromWString(L"Lumen/1.0.0");

  // 訊息幫浦視窗先建立，確保 CefInitialize 期間排入的工作不會遺失
  if (!lumen::CreatePumpWindow(hInstance)) {
    lumen::ShowError(L"無法建立訊息幫浦視窗。");
    return 1;
  }
  lumen::InstallExternalPump(lumen::g_pump_window);

  if (!CefInitialize(main_args, settings, app.get(), nullptr)) {
    lumen::ShowError(L"CEF/Chromium 初始化失敗，請查看 browser_data/logs/cef.log。");
    lumen::UnlockSingleInstance();
    return 1;
  }

  int exit_code = 0;
  {
    // ---- 6. 載入可攜設定 / 建立主視窗 --------------------------------
    lumen::AppConfig config;
    lumen::HistoryStore history;
    lumen::BookmarkStore bookmarks;

    config.Load(lumen::PortablePaths::ConfigFile(L"settings.json"));
    history.Load(lumen::PortablePaths::ConfigFile(L"history.tsv"));
    bookmarks.Load(lumen::PortablePaths::ConfigFile(L"bookmarks.tsv"));

    lumen::MainWindow window(hInstance, &config, &history, &bookmarks);
    if (!window.Create(nCmdShow)) {
      lumen::ShowError(L"主視窗建立失敗。");
      CefShutdown();
      lumen::UnlockSingleInstance();
      return 1;
    }

    const std::wstring startup_url = lumen::FirstUrlArgument();
    if (!startup_url.empty()) window.OpenExternalUrl(startup_url);

    // ---- 7. 主訊息迴圈 ----------------------------------------------
    //  CEF 的工作透過 pump 視窗的 PostMessage / WM_TIMER 進來，
    //  因此這裡可以是完全阻塞式的標準迴圈 (閒置時 CPU 使用率為 0)。
    MSG message;
    while (::GetMessageW(&message, nullptr, 0, 0) > 0) {
      ::TranslateMessage(&message);
      ::DispatchMessageW(&message);
    }
    exit_code = (int)message.wParam;

    // window 的解構會關閉所有分頁、儲存 session 與設定
  }

  // ---- 8. 收尾 --------------------------------------------------------
  lumen::ShutdownExternalPump();
  lumen::Gfx::Get().Shutdown();
  CefShutdown();
  lumen::PortablePaths::UnlockSingleInstance();
  ::OleUninitialize();
  return exit_code;
}
