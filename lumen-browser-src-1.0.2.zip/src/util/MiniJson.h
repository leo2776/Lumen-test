// ===========================================================================
//  Lumen Browser — util/MiniJson.h
//  零依賴的「扁平 JSON 物件」讀寫器。僅支援 top-level 的 key -> string/bool/number。
//  用於 settings.json（設定檔不需要嵌套結構，因此不需要完整 JSON 解析器）。
// ===========================================================================
#pragma once

#include <string>
#include <map>

namespace lumen {

class JsonObject {
 public:
  void SetString(const std::string& key, const std::string& value);
  void SetBool(const std::string& key, bool value);
  void SetInt(const std::string& key, long long value);
  void SetDouble(const std::string& key, double value);

  std::string GetString(const std::string& key, const std::string& fallback = std::string()) const;
  bool        GetBool(const std::string& key, bool fallback) const;
  long long   GetInt(const std::string& key, long long fallback) const;
  double      GetDouble(const std::string& key, double fallback) const;
  bool        Has(const std::string& key) const;

  bool Parse(const std::string& json);       // 回傳 false 表示格式錯誤（保留既有值）
  std::string Serialize() const;             // pretty-print，key 依字母排序

 private:
  enum class Type { String, Number, Bool, Null };
  struct Value {
    Type type = Type::Null;
    std::string text;
  };

  std::map<std::string, Value> values_;
};

}  // namespace lumen
