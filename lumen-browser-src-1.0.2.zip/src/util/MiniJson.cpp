#include "util/MiniJson.h"

#include <cstdlib>
#include <cstdio>
#include <cmath>

namespace lumen {
namespace {

std::string Escape(const std::string& in) {
  std::string out;
  out.reserve(in.size() + 8);
  for (unsigned char c : in) {
    switch (c) {
      case '"':  out += "\\\""; break;
      case '\\': out += "\\\\"; break;
      case '\n': out += "\\n"; break;
      case '\r': out += "\\r"; break;
      case '\t': out += "\\t"; break;
      default:
        if (c < 0x20) {
          char buf[8];
          ::snprintf(buf, sizeof(buf), "\\u%04x", c);
          out += buf;
        } else {
          out.push_back((char)c);
        }
    }
  }
  return out;
}

void SkipWhitespace(const std::string& s, size_t& i) {
  while (i < s.size() && (s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')) ++i;
}

// 解析 JSON 字串字面值，i 指向開頭的雙引號
bool ParseString(const std::string& s, size_t& i, std::string& out) {
  if (i >= s.size() || s[i] != '"') return false;
  ++i;
  out.clear();
  while (i < s.size()) {
    const char c = s[i++];
    if (c == '"') return true;
    if (c == '\\') {
      if (i >= s.size()) return false;
      const char esc = s[i++];
      switch (esc) {
        case '"':  out.push_back('"'); break;
        case '\\': out.push_back('\\'); break;
        case '/':  out.push_back('/'); break;
        case 'b':  out.push_back('\b'); break;
        case 'f':  out.push_back('\f'); break;
        case 'n':  out.push_back('\n'); break;
        case 'r':  out.push_back('\r'); break;
        case 't':  out.push_back('\t'); break;
        case 'u': {
          if (i + 4 > s.size()) return false;
          unsigned code = (unsigned)std::strtoul(s.substr(i, 4).c_str(), nullptr, 16);
          i += 4;
          // 只處理 BMP 基本字元 (設定檔皆為 ASCII)
          if (code < 0x80) {
            out.push_back((char)code);
          } else if (code < 0x800) {
            out.push_back((char)(0xC0 | (code >> 6)));
            out.push_back((char)(0x80 | (code & 0x3F)));
          } else {
            out.push_back((char)(0xE0 | (code >> 12)));
            out.push_back((char)(0x80 | ((code >> 6) & 0x3F)));
            out.push_back((char)(0x80 | (code & 0x3F)));
          }
          break;
        }
        default: return false;
      }
    } else {
      out.push_back(c);
    }
  }
  return false;
}

// 跳過任意 JSON 值（用於忽略不支援的嵌套結構而不使解析失敗）
bool SkipValue(const std::string& s, size_t& i) {
  SkipWhitespace(s, i);
  if (i >= s.size()) return false;
  const char c = s[i];
  if (c == '"') {
    std::string dummy;
    return ParseString(s, i, dummy);
  }
  if (c == '{' || c == '[') {
    const char close = (c == '{') ? '}' : ']';
    int depth = 0;
    while (i < s.size()) {
      const char ch = s[i++];
      if (ch == '"') { std::string d; if (!ParseString(s, i, d)) return false; continue; }
      if (ch == c) ++depth;
      if (ch == close) { if (--depth == 0) return true; }
    }
    return false;
  }
  // number / true / false / null
  while (i < s.size() && s[i] != ',' && s[i] != '}' && s[i] != ' ' && s[i] != '\n' && s[i] != '\r' &&
         s[i] != '\t') {
    ++i;
  }
  return true;
}

}  // namespace

void JsonObject::SetString(const std::string& key, const std::string& value) {
  values_[key] = Value{Type::String, value};
}
void JsonObject::SetBool(const std::string& key, bool value) {
  values_[key] = Value{Type::Bool, value ? "true" : "false"};
}
void JsonObject::SetInt(const std::string& key, long long value) {
  char buf[32];
  ::snprintf(buf, sizeof(buf), "%lld", value);
  values_[key] = Value{Type::Number, buf};
}
void JsonObject::SetDouble(const std::string& key, double value) {
  char buf[64];
  ::snprintf(buf, sizeof(buf), "%.6g", value);
  values_[key] = Value{Type::Number, buf};
}

std::string JsonObject::GetString(const std::string& key, const std::string& fallback) const {
  auto it = values_.find(key);
  if (it == values_.end()) return fallback;
  return it->second.text;
}

bool JsonObject::GetBool(const std::string& key, bool fallback) const {
  auto it = values_.find(key);
  if (it == values_.end()) return fallback;
  return it->second.text == "true" || it->second.text == "1";
}

long long JsonObject::GetInt(const std::string& key, long long fallback) const {
  auto it = values_.find(key);
  if (it == values_.end()) return fallback;
  return std::strtoll(it->second.text.c_str(), nullptr, 10);
}

double JsonObject::GetDouble(const std::string& key, double fallback) const {
  auto it = values_.find(key);
  if (it == values_.end()) return fallback;
  return std::strtod(it->second.text.c_str(), nullptr);
}

bool JsonObject::Has(const std::string& key) const {
  return values_.find(key) != values_.end();
}

bool JsonObject::Parse(const std::string& json) {
  size_t i = 0;
  SkipWhitespace(json, i);
  if (i >= json.size() || json[i] != '{') return false;
  ++i;

  std::map<std::string, Value> parsed;
  for (;;) {
    SkipWhitespace(json, i);
    if (i >= json.size()) return false;
    if (json[i] == '}') { ++i; break; }

    std::string key;
    if (!ParseString(json, i, key)) return false;
    SkipWhitespace(json, i);
    if (i >= json.size() || json[i] != ':') return false;
    ++i;
    SkipWhitespace(json, i);

    Value value;
    if (i < json.size() && json[i] == '"') {
      value.type = Type::String;
      if (!ParseString(json, i, value.text)) return false;
    } else if (i < json.size() && (json[i] == '{' || json[i] == '[')) {
      if (!SkipValue(json, i)) return false;   // 忽略不支援的嵌套值
      value.type = Type::Null;
    } else {
      const size_t start = i;
      while (i < json.size() && json[i] != ',' && json[i] != '}' && json[i] != ' ' && json[i] != '\n' &&
             json[i] != '\r' && json[i] != '\t') {
        ++i;
      }
      const std::string token = json.substr(start, i - start);
      if (token == "true" || token == "false") {
        value.type = Type::Bool;
        value.text = token;
      } else if (!token.empty()) {
        value.type = Type::Number;
        value.text = token;
      }
    }
    parsed[key] = value;

    SkipWhitespace(json, i);
    if (i < json.size() && json[i] == ',') { ++i; continue; }
    if (i < json.size() && json[i] == '}') { ++i; break; }
    return false;
  }

  values_ = std::move(parsed);
  return true;
}

std::string JsonObject::Serialize() const {
  std::string out = "{\n";
  size_t n = 0;
  for (const auto& kv : values_) {
    out += "  \"";
    out += Escape(kv.first);
    out += "\": ";
    switch (kv.second.type) {
      case Type::String: out += "\"" + Escape(kv.second.text) + "\""; break;
      case Type::Number:
      case Type::Bool:   out += kv.second.text; break;
      case Type::Null:   out += "null"; break;
    }
    if (++n < values_.size()) out += ",";
    out += "\n";
  }
  out += "}\n";
  return out;
}

}  // namespace lumen
