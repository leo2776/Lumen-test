@echo off
setlocal
title Lumen Browser - one click build
cd /d "%~dp0"

echo ==================================================
echo   Lumen Browser - one click build (Windows 10 x64)
echo ==================================================
echo.

if not exist "CMakeLists.txt" goto :wrongfolder
if not exist "scripts\fetch-cef.ps1" goto :wrongfolder

where powershell.exe >nul 2>nul
if errorlevel 1 goto :nops

echo [1/3] Checking toolchain ...
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if exist "%VSWHERE%" goto :vsok
echo       [WARN] vswhere.exe not found - Visual Studio 2022 may not be installed.
echo       [WARN] Install "Desktop development with C++" first, or this will fail.
goto :vsdone
:vsok
for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -property installationVersion`) do set "VSVER=%%i"
if defined VSVER echo       Visual Studio : %VSVER%
if not defined VSVER echo       [WARN] No Visual Studio installation detected.
:vsdone
where cmake.exe >nul 2>nul
if errorlevel 1 (echo       cmake        : not in PATH, script will look inside Visual Studio) else (echo       cmake        : found in PATH)
echo.

echo [2/3] Getting CEF 130 (about 320 MB, skipped if already present) ...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\fetch-cef.ps1"
if errorlevel 1 goto :ceffailed
echo.

echo [3/3] Configuring and building (first run takes 5-15 min) ...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\build.ps1" -NoFetch -Config Release
if errorlevel 1 goto :buildfailed
echo.

if not exist "build\Release\lumen.exe" goto :noexe
echo ==================================================
echo   BUILD OK
echo   executable : build\Release\lumen.exe
echo   portable   : build\Release\  (browser_data\ lives here)
echo ==================================================
echo.
choice /c YN /m "Start Lumen now"
if errorlevel 2 goto :end
start "" "build\Release\lumen.exe"
goto :end

:wrongfolder
echo [ERROR] Wrong folder.
echo         Run this file from the project root (the folder that contains
echo         CMakeLists.txt and the scripts\ folder).
echo.
echo         Current folder: %CD%
goto :end

:nops
echo [ERROR] powershell.exe not found.
goto :end

:ceffailed
echo.
echo [ERROR] CEF download or extraction failed.
echo         Check your network access to cef-builds.spotifycdn.com.
echo         Manual fallback: see QUICKSTART-WIN10-VM.md step 3.
goto :end

:buildfailed
echo.
echo [ERROR] Build failed.
echo         Scroll up for the first compiler error.
echo         Common causes: missing "Desktop development with C++" workload,
echo         Windows 10 SDK not installed, or a path with unusual characters.
goto :end

:noexe
echo [ERROR] build\Release\lumen.exe was not produced.
goto :end

:end
echo.
pause
endlocal
