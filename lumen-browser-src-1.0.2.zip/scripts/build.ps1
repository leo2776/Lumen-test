﻿# ===========================================================================
#  Lumen Browser - scripts/build.ps1
#  One command build: fetch CEF (if missing) -> CMake configure -> MSBuild.
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -Config Debug
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -CefRoot D:\sdk\cef
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -NoFetch
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -NativeFrame
#
#  NOTE: this file is intentionally ASCII-only. Windows PowerShell 5.1 reads
#        non-BOM UTF-8 as CP950 on zh-TW systems and corrupts string literals.
# ===========================================================================
param(
  [ValidateSet("Release", "Debug")]
  [string]$Config = "Release",
  [string]$CefRoot = "",
  [switch]$NativeFrame,
  [switch]$NoFetch
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Push-Location $root

try {
  Write-Host ""
  Write-Host "=== Lumen Browser build ===" -ForegroundColor Cyan
  Write-Host "root   : $root"
  Write-Host "config : $Config"
  Write-Host ""

  # ---- 1. locate CEF, download when missing -------------------------------
  if (-not $CefRoot) {
    if ($env:CEF_ROOT) { $CefRoot = $env:CEF_ROOT }
    else { $CefRoot = Join-Path $root (Join-Path "third_party" "cef") }
  }

  if (-not (Test-Path (Join-Path $CefRoot "include\cef_app.h"))) {
    if ($NoFetch) {
      Write-Host "CEF not found: $CefRoot" -ForegroundColor Red
      exit 1
    }
    Write-Host "CEF not found, downloading (~335 MB)..." -ForegroundColor Yellow
    $fetch = Join-Path $root "scripts\fetch-cef.ps1"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $fetch -CefRoot $CefRoot
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $CefRoot "include\cef_app.h"))) {
      throw "Could not obtain CEF"
    }
  }
  Write-Host "CEF    : $CefRoot"

  # ---- 2. locate CMake ----------------------------------------------------
  $vsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
  $cmake = $null
  $cmd = Get-Command cmake -ErrorAction SilentlyContinue
  if ($cmd) {
    $cmake = $cmd.Source
  } elseif (Test-Path $vsWhere) {
    $vsPath = & $vsWhere -latest -products * -property installationPath
    if ($vsPath) {
      $candidate = Join-Path $vsPath "Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
      if (Test-Path $candidate) { $cmake = $candidate }
    }
  }
  if (-not $cmake) {
    Write-Host "cmake.exe not found." -ForegroundColor Red
    Write-Host "Install CMake (https://cmake.org/download/) and tick 'Add to PATH'," -ForegroundColor Red
    Write-Host "or run this script from the 'x64 Native Tools Command Prompt for VS 2022'." -ForegroundColor Red
    exit 1
  }
  Write-Host "cmake  : $cmake"

  # ---- 3. CMake configure -------------------------------------------------
  $buildDir = Join-Path $root "build"
  $cmakeArgs = @("-S", $root, "-B", $buildDir, "-A", "x64", "-DCEF_ROOT=$CefRoot")

  $vsVersion = $null
  if (Test-Path $vsWhere) {
    $vsVersion = & $vsWhere -latest -products * `
      -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
      -property installationVersion
  }
  if ($vsVersion -and ("$vsVersion" -match '^17\.')) {
    $cmakeArgs = @("-G", "Visual Studio 17 2022") + $cmakeArgs
  }
  if ($NativeFrame) { $cmakeArgs += "-DLUMEN_NATIVE_FRAME=ON" }

  Write-Host ""
  Write-Host "--- cmake configure ---" -ForegroundColor Cyan
  & $cmake @cmakeArgs
  if ($LASTEXITCODE -ne 0) { throw "CMake configure failed" }

  # ---- 4. build -----------------------------------------------------------
  Write-Host ""
  Write-Host "--- building (first run compiles the CEF wrapper, 5-15 min) ---" -ForegroundColor Yellow
  & $cmake --build $buildDir --config $Config --parallel
  if ($LASTEXITCODE -ne 0) { throw "Build failed" }

  # ---- 5. report ----------------------------------------------------------
  $outDir = Join-Path $buildDir $Config
  $exe = Join-Path $outDir "lumen.exe"
  Write-Host ""
  if (Test-Path $exe) {
    Write-Host "Build OK." -ForegroundColor Green
    Write-Host "  executable : $exe"
    Write-Host "  portable   : $outDir   (browser_data\ is created next to the exe)"
    Write-Host ""
    Write-Host "  Run it with:  & '$exe'"
    Write-Host ""
  } else {
    Write-Host "lumen.exe was not produced - check the build output above." -ForegroundColor Yellow
    exit 1
  }
}
finally {
  Pop-Location
}
