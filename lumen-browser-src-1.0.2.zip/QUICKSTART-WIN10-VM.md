# 在「全新的 Windows 10 虛擬機」從零跑起 Lumen Browser

> 這份文件假設 VM 是**乾淨的 Windows 10 x64**（沒有任何開發工具、沒有網路帳號設定）。
> 全程約需 **60～90 分鐘**，其中 40 分鐘是下載與安裝，15 分鐘是編譯。
>
> ⚠️ **先講清楚一件事**：本專案的核心是 CEF (Chromium) 的 **Windows x64 原生程式庫**，
> 我無法在目前的 Linux 開發沙箱裡替你先編成 `lumen.exe`（沒有 MSVC / Windows SDK）。
> 因此你需要在 VM 內**編譯一次**。編譯完成後產生的資料夾本身就是可攜包，
> 之後整包複製到任何 Windows 10/11 都能直接跑，不需要再編譯。

---

## 步驟 0：VM 規格與前置條件

| 項目 | 建議值 | 說明 |
|---|---|---|
| 客體 OS | Windows 10 **x64** 21H2 / 22H2 | Chromium 130 不支援 Win7/8；一定要 64 位元 |
| vCPU | 4 核以上 | CEF wrapper 編譯可平行 |
| 記憶體 | **8 GB 以上**（最低 6 GB） | MSVC 連結 + Chromium 子行程很吃記憶體 |
| 磁碟 | **60 GB**，至少保留 20 GB 可用 | VS Build Tools ~7 GB、CEF 解開 ~1.2 GB、建置 ~2 GB |
| 網路 | VM 內需可上網 | 下載 VS Build Tools + CEF（約 1.5 GB 總流量） |
| 顯示 | 3D 加速可開可不開 | Lumen 用軟體離屏渲染，開不開都能跑 |

虛擬化平台：VMware Workstation Player / VMware Fusion / VirtualBox / Hyper-V / Windows 沙箱皆可。

若 VM **完全沒有網路**：請先在主機下載好
「VS 2022 Build Tools 離線安裝包」與 `cef_binary_130.1.16+...windows64.tar.bz2`，
再用共用資料夾 / ISO / 拖曳方式帶進 VM。

---

## 步驟 1：把專案放進 VM

1. 在本對話下載 **`lumen-browser-src-1.0.0.zip`**。
2. 用下列任一方式帶進 VM：VM 共用資料夾、拖曳（VMware/VirtualBox 支援）、
   或直接在 VM 內開瀏覽器重新下載一次。
3. 解壓到**短、純英文、可寫入**的路徑：

```
C:\Lumen\                ← 建議（不要放 C:\Program Files，也不要放 OneDrive 或含中文/空格的路徑）
├── CMakeLists.txt
├── src\
├── scripts\
├── docs\
├── res\
└── third_party\        ← 之後 CEF 會放在這裡
```

> 為什麼不能放 `Program Files`？因為建置與執行都要在旁邊寫 `build\` 與 `browser_data\`，
> 那兩個位置需要管理員權限。可攜式程式請放一般使用者可寫的資料夾。

---

## 步驟 2：安裝建置工具（唯一比較花時間的一步）

### 2.1 安裝 Visual Studio 2022 Build Tools（或 Community）

下載：<https://visualstudio.microsoft.com/visual-cpp-build-tools/>
（若你想要圖形化 IDE，裝 **Visual Studio 2022 Community** 也可以，步驟相同）

安裝時勾選：

- 工作負載：✅ **使用 C++ 的桌面開發**（Desktop development with C++）
- 個別元件（在右側「安裝詳細資料」確認）：
  - ✅ MSVC v143 - VS 2022 C++ x64/x86 建置工具
  - ✅ **Windows 10 SDK（10.0.19041.0 或更新）**
  - ✅ C++ CMake tools for Windows（會一併裝 CMake 與 Ninja）
  - ✅ Windows 10/11 SDK（若清單有兩個，選最新的即可）

安裝大小約 5～7 GB，時間約 20～40 分鐘（看機器）。

### 2.2 安裝 CMake（若 2.1 已勾選 CMake tools 可跳過）

最簡單的方式：<https://cmake.org/download/> → 下載 **Windows x64 Installer** →
安裝時選「Add CMake to the system PATH」。

或用 winget（若 VM 有 App Installer）：

```powershell
winget install --id Kitware.CMake -e
```

### 2.3 驗證工具鏈

開一個**新的** PowerShell 視窗（讓 PATH 生效），執行：

```powershell
cmake --version
# 應該顯示 cmake version 3.2x 以上
```

```powershell
# 確認 MSVC 存在
& "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -property installationPath
# 應該印出 C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools 之類
```

若 `cmake` 找不到，改用「**x64 Native Tools Command Prompt for VS 2022**」
（開始選單搜尋）來執行後面的指令，裡面 PATH 都已設好。

---

## 步驟 3：取得 CEF（約 335 MB，腳本自動處理）

```powershell
cd C:\Lumen
powershell -ExecutionPolicy Bypass -File .\scripts\fetch-cef.ps1
```

腳本會：

1. 從 `https://cef-builds.spotifycdn.com/` 下載**鎖定版本**
   `cef_binary_130.1.16+g5a7e5ed+chromium-130.0.6723.117_windows64.tar.bz2`
2. 驗證 SHA1（`5bc51f23…78b83e`）
3. 先試內建 `tar.exe`；若失敗（Windows 的 tar 沒有 bzip2）自動改用 7-Zip，
   系統沒裝 7-Zip 就下載官方免安裝主控台版到 `scripts\tools\`（約 1.6 MB）
4. 放到 `C:\Lumen\third_party\cef\`，並檢查關鍵檔案是否齊全

完成後 `C:\Lumen\third_party\cef\` 應該長這樣：

```
third_party\cef\
├── cmake\          cef_variables.cmake / cef_macros.cmake
├── include\        cef_app.h ... internal\cef_types.h
├── libcef_dll\     wrapper 原始碼（會被編進你的 exe）
├── Release\        libcef.dll, libcef.lib, chrome_elf.dll, *.pak, icudtl.dat, v8_context_snapshot.bin
├── Resources\      locales\, *.pak
├── Debug\
└── tests\
```

### 手動替代方案（腳本被公司網路擋住時）

1. 瀏覽器開 <https://cef-builds.spotifycdn.com/index.html>
2. 找 `130.1.16+g5a7e5ed+chromium-130.0.6723.117` → `windows64` → 下載 `Standard` 發行包
3. 用 7-Zip 解壓兩次（`.tar.bz2` → `.tar` → 資料夾）
4. 把資料夾改名為 `cef` 並放到 `C:\Lumen\third_party\cef`

> ⚠️ **請不要「順手升級成最新版 CEF」**。新版有破壞性 API 變更（詳見
> `docs/CEF-VERSION-NOTES.md`），本專案的程式碼是逐項對照 130 的標頭檔驗證過的。

---

> 下載檔案大小為 **335,346,714 bytes**。腳本完成時顯示「Downloaded 319.8 MB」是正常的 ——
> PowerShell 的 `1MB` 等於 1 MiB（1024×1024），換算後就是 335.3 MB。

**最省事的做法**（在 cmd 直接跑，不用碰 PowerShell 語法）：

```cmd
cd /d C:\Lumen
BUILD-WIN10.cmd
```

## 步驟 4：編譯

```powershell
cd C:\Lumen
powershell -ExecutionPolicy Bypass -File scripts\build.ps1
```

腳本做的事：找 CEF → 檢查 CMake → `cmake -A x64` 設定 → `MSBuild` 平行編譯
→ 把 CEF 執行期檔案複製到輸出目錄。

**首次編譯約 5～15 分鐘**（會編譯約 100 個 CEF wrapper 檔案）。看到以下訊息就是成功：

```
  Build succeeded.
  建置成功 ✔
    執行檔    : C:\Lumen\build\Release\lumen.exe
    可攜根目錄: C:\Lumen\build\Release
```

### 等價的手動指令（不想用腳本時）

```powershell
cd C:\Lumen
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --parallel
```

### 建置失敗時

| 訊息 | 原因 / 解法 |
|---|---|
| `找不到 CEF` | `third_party\cef\include\cef_app.h` 不存在 → 重跑 `fetch-cef.ps1` |
| `無法辨識 'cmake'` | CMake 不在 PATH → 用「x64 Native Tools Command Prompt」或重裝 CMake 並勾選 PATH |
| `MSB8020 / 找不到 v143` | 沒裝「使用 C++ 的桌面開發」工作負載 |
| `error MSB8036: 找不到 Windows SDK 10.0.xxxxx` | 安裝對應的 Windows 10 SDK 元件 |
| `LNK1104: 無法開啟檔案 'libcef.lib'` | `Release\libcef.lib` 缺失 → CEF 解壓不完整，重跑 `-Force` |
| `tar.exe: Error opening archive: Can't initialize filter; unable to run program "bzip2 -d"` | Windows 內建 tar 不含 bzip2 | 本版 `fetch-cef.ps1` 會自動改用 7-Zip（必要時自動下載免安裝版）。若你手上是舊版腳本，請換新版，或自行安裝 7-Zip 手動解壓兩次 |
| `LNK2038: mismatch detected for 'RuntimeLibrary'` | exe 用 `/MD` 而 CEF wrapper 用 `/MT` | 用本專案的 `CMakeLists.txt`（已設 `/MT`），不要自行改成 `MultiThreadedDLL` |
| `C1060: 編譯器超出堆疊空間` / 記憶體不足 | VM 記憶體加到 8 GB 以上，`--parallel` 改少一點：`cmake --build build --config Release --parallel 2` |
| 編譯很久卡住 | 正常，CEF wrapper 檔案很多；看工作管理員的 `cl.exe` 是否在跑 |

---

## 步驟 5：執行

```powershell
C:\Lumen\build\Release\lumen.exe
```

第一次啟動會在**執行檔旁**自動建立：

```
C:\Lumen\build\Release\lumen.exe
C:\Lumen\build\Release\libcef.dll  ...
C:\Lumen\build\Release\browser_data\      ← 這裡就是全部狀態
├── PORTABLE.txt
├── profile\      Cookie / LocalStorage
├── cache\        HTTP/GPU 快取
├── config\       settings.json / bookmarks.tsv / history.tsv / session.tsv
├── ui\           newtab.html / history.html
├── downloads\    下載的檔案
├── logs\cef.log
└── temp\
```

**驗收清單（建議照著點一遍）**

1. 打開新分頁 → 看到 Lumen 新分頁與搜尋框
2. 在網址列輸入 `github.com` → 能載入（Omnibox 會自動補 `https://`）
3. 輸入一串中文查詢詞 → 走 Google 搜尋（網址列中文輸入正常）
4. `Ctrl+T` 開分頁、`Ctrl+W` 關分頁、`Ctrl+D` 加書籤（書籤列會出現）
5. `Alt+←` 上一頁
6. ⋮ 選單 → 切換淺色/深色模式 → 整個外框、分頁、選單都會跟著變
7. 右鍵網頁 → 自繪深色右鍵選單
8. 隨便下載一個檔案 → 會落在 `browser_data\downloads\`
9. 關閉再開 → `browser_data\config\session.tsv` 有上次的分頁

**VM 效能不佳或畫面異常時**

```powershell
C:\Lumen\build\Release\lumen.exe --disable-gpu
```

（VM 的虛擬顯示卡對 Chromium 的 GPU 加速支援較差，關掉通常更穩。
 Lumen 本來就是用軟體離屏渲染合成畫面，關 GPU 影響有限。）

---

## 步驟 6：驗證「根目錄絕對隔離」（可攜性）

```powershell
# 1) 啟動前：這兩個資料夾應該「不存在」
Test-Path "$env:LOCALAPPDATA\CEF"
Test-Path "$env:APPDATA\Lumen"

# 2) 開幾個網頁、登入任何網站、下載檔案，然後完全關閉瀏覽器

# 3) 再檢查一次：仍然不存在
Test-Path "$env:LOCALAPPDATA\CEF"
Get-ChildItem "$env:LOCALAPPDATA" -Filter "*CEF*" -Recurse -ErrorAction SilentlyContinue

# 4) 所有狀態都在 exe 旁邊
Get-ChildItem C:\Lumen\build\Release\browser_data
```

想更嚴謹：下載 **Process Monitor**，Filter → `Process Name is lumen.exe` +
`Operation is WriteFile`，操作一輪瀏覽器，所有寫入路徑都應該在 `browser_data\` 底下。

### 進階驗證：整包搬到別台機器

1. 把 `C:\Lumen\build\Release\` **整個資料夾**壓成 zip
2. 複製到另一台 Windows 10/11（或插在 USB 上直接跑）
3. 解壓後直接執行 `lumen.exe` → 書籤、歷史、Cookie、登入狀態全部跟著走

> 這一步就是「可攜式瀏覽器」的成果驗收：**沒有任何檔案留在原本那台機器**。

---

## 步驟 7：常見執行期問題

| 症狀 | 原因與解法 |
|---|---|
| 雙擊沒反應、或閃一下就消失 | 用 PowerShell 執行看訊息：`& .\lumen.exe`；再看 `browser_data\logs\cef.log` |
| 錯誤視窗「找不到 VCRUNTIME140.dll / MSVCP140.dll」 | 本專案用 `/MT` 靜態 CRT，正常不會缺。若出現代表編譯設定被改過 |
| 「Windows 已保護您的電腦」（SmartScreen） | 自己編譯的未簽章程式，點「仍要執行」即可 |
| 白畫面、只有外框 | 缺 `icudtl.dat` / `*.pak` / `locales\` → CEF 執行期檔案沒複製齊；重新建置 |
| 網頁載入但畫面全黑/破碎 | 加 `--disable-gpu` 執行 |
| 提示「已有一個 Lumen 正在執行」 | 單一實例鎖在 `browser_data\` 內；要同時跑多份就複製整個資料夾 |
| 中文變亂碼 | 建置時必須有 `/utf-8`（CMakeLists 已設定）；若你改過 CMake 請保留 |
| VM 內很卡、滾動不順 | 記憶體加到 8 GB、關掉 VM 的 3D 加速、執行時加 `--disable-gpu` |
| 想改用原生標題列（版面異常時） | `cmake -S . -B build -A x64 -DLUMEN_NATIVE_FRAME=ON` 重新建置 |

---

## 步驟 8：之後要做的事

| 目標 | 做法 |
|---|---|
| 給朋友用（不用編譯） | 把 `build\Release\` 整包 zip 給他就好（含 CEF DLL 與 `browser_data`） |
| 完全重置瀏覽器 | 關閉程式 → 刪除 `browser_data\` → 重新啟動 |
| 改首頁 / 搜尋引擎 | 編輯 `browser_data\config\settings.json`（`homepage` / `search_url`） |
| 手動加書籤 | 編輯 `browser_data\config\bookmarks.tsv`（`標題<TAB>網址`） |
| 改 UI 配色 | `src/ui/Theme.cpp` 的 `Theme::Dark()` / `Theme::Light()` |
| 想升級 CEF | **先讀 `docs/CEF-VERSION-NOTES.md`**，那裡列了 5 個已知會讓編譯失敗的 API 破壞性變更 |

### 附錄 A：PowerShell 腳本相關錯誤

| 訊息 | 原因 | 解法 |
|---|---|---|
| `-File 參數的 'scripts\fetch-cef.ps1' 引數不存在` | 目前資料夾不是專案根目錄（通常是解壓後多了一層同名資料夾） | `dir` 確認看到 `scripts`、`src`、`CMakeLists.txt`；若看到另一層 `lumen-browser-src-*` 就再 `cd` 進去 |
| `字串遺漏結尾字元`、`未預期的 '}'`、訊息裡出現 `闈??愴望` 之類亂碼 | `.ps1` 是 **UTF-8 無 BOM**，Windows PowerShell 5.1 用 CP950 讀取，中文字串被打散 | 本版 `scripts\*.ps1` 已改為 **純 ASCII（英文訊息）**，不會再發生。若你手上是舊檔，重新解壓本版即可，或改用 `pwsh` |
| `無法辨識 'xxx' 詞彙` | 同上（編碼造成） | 同上 |
| `'$bom' 不是內部或外部命令` / `'Get-ChildItem' 不是內部或外部命令` | **在 cmd.exe 貼了 PowerShell 語法**。cmd 只認內建指令與 .exe | 兩種解法：① 先輸入 `powershell` 進入 PS（提示字元會變成 `PS C:\...>`）再貼；② 直接跑 `BUILD-WIN10.cmd`，完全不必打 PowerShell 語法 |
| 腳本被執行原則封鎖 | ExecutionPolicy | 一律加上 `-ExecutionPolicy Bypass`（本文件所有指令都已含） |

> 想雙重保險：也可以用 PowerShell 7（`pwsh`）執行，它預設以 UTF-8 讀取腳本：
> `winget install Microsoft.PowerShell` 後改用 `pwsh -File .\scripts\build.ps1`
