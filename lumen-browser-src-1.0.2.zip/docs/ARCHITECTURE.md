# Lumen Browser — 架構深入說明

本文件說明為什麼這樣設計、關鍵資料流，以及每個技術取捨的理由。

---

## 1. 三層架構與相依方向

```
            ┌──────────────────────────────────────────────┐
            │  ui/     MainWindow · TabStrip · Omnibox ·   │   ← 只依賴 core 的介面
            │          BookmarksBar · PopupMenu · Gfx      │
            └───────────────▲──────────────────────────────┘
                            │  BrowserUI (純虛介面)
            ┌───────────────┴──────────────────────────────┐
            │  core/   TabManager · Tab · stores · paths   │
            └───────────────▲──────────────────────────────┘
                            │  CefClient handlers
            ┌───────────────┴──────────────────────────────┐
            │  app/    LumenApp · TabClient · MessagePump  │
            └──────────────────────────────────────────────┘
                            │
                        CEF / Chromium
```

相依是單向的：

* `core/TabManager` 不認識 `MainWindow`，只透過 `core/BrowserUI.h` 的介面回呼 UI。
* `app/TabClient`（CEF 回呼入口）→ 呼叫 `TabManager::ui()->OnXxx()`，同樣只看到介面。
* `ui/` 是最上層，可以 include 所有下層，但沒有任何下層 include 它。

好處：CEF handler 的介面變動不會汙染 UI 層；`Tab` / `HistoryStore` / `UrlUtil` 等核心邏輯
可以在沒有視窗的情況下單獨測試（甚至寫成主控台測試程式）。

---

## 2. 執行緒模型：單一 UI 執行緒 + 外部訊息幫浦

```
Win32 主執行緒
├── CefInitialize(...)  ── external_message_pump = true
├── 自研視窗 MainWindow (Direct2D 繪製)
├── 標準 GetMessage 迴圈
│     └── 收到 pump 視窗的 PostMessage / WM_TIMER → CefDoMessageLoopWork()
└── TabClient 的所有回呼 (OnPaint / OnTitleChange / OnAfterCreated ...)
      ← 都在這個執行緒上！

Chromium 內部執行緒 (renderer / GPU / network，各自為獨立行程)
└── 只透過 CEF 的行程間通訊與上面的 UI 執行緒互動
```

**為什麼選 `external_message_pump` 而不是 `multi_threaded_message_loop`？**

| | external pump（本專案） | multi-threaded loop |
|---|---|---|
| CEF 回呼執行緒 | 與 Win32 UI 同一條 | 另一條 CEF UI 執行緒 |
| OSR `OnPaint` 拿到的緩衝 | 直接可用、無鎖 | 需要 mutex + PostMessage 轉送到視窗 |
| 除錯 | 單一 call stack | 跨執行緒競態難查 |
| 缺點 | 需自行實作幫浦（約 60 行） | 較少程式碼 |

實作在 `main.cpp`：`OnScheduleMessagePumpWork(delay_ms)`（CEF 說「我多久後需要工作」）→
`delay_ms <= 0` 時 `PostMessage`，否則 `SetTimer`；兩者最後都呼叫 `CefDoMessageLoopWork()`。
因為是**事件驅動**，閒置時訊息迴圈阻塞在 `GetMessage`，CPU 使用率為 0（不像輪詢式幫浦會空轉）。

---

## 3. 渲染管線：CEF 離屏 → Direct2D 合成

```
Blink/Skia (renderer 行程)
   │ 產生 frame
   ▼
CEF compositor → 軟體 OSR 讀回
   │  OnPaint(PET_VIEW, buffer=BGRA, w, h)
   ▼
TabClient::OnPaint
   └── Tab::SetFrame(buffer, w, h)          // 複製到分頁自己的緩衝
         └── MainWindow::OnTabFrameReady()  // 只有前景分頁才重繪
               └── InvalidateRect → WM_PAINT
                     └── ID2D1Bitmap::CopyFromMemory(tab->frame_data())
                           └── DrawBitmap(dest = 內容區 RectF)
```

分層合成順序（`MainWindow::Paint`）：

```
Clear(frame)
 ├─ 分頁列底色 + 各分頁 (Direct2D 路徑：只有上緣圓角)
 ├─ 視窗按鈕 (最小化/最大化/關閉，hover 變色)
 ├─ 工具列底色 + 上緣 1px 分隔線
 ├─ 導覽按鈕 / 網址列膠囊 (邊框在聚焦時變 accent 色) / 鎖頭 / 星號 / ⋮
 ├─ 書籤列
 ├─ 網頁內容：ID2D1Bitmap (CEF frame) + <select> popup layer (PET_POPUP)
 └─ 狀態氣泡 (link hover 的網址)
```

重點設計：

* **每個分頁各自持有 BGRA 緩衝**（`Tab::frame_`）。切到背景分頁時呼叫
  `WasHidden(true)` 讓 Chromium 降頻；切回來時先用快取畫面重繪避免白屏，
  再 `Invalidate(PET_VIEW)` 要求新畫面。
* **`<select>` 下拉選單必須自己合成**。OSR 模式下 CEF 會把 popup 畫到
  `PET_POPUP` 層，若不處理，所有下拉選單都不會出現。這是 OSR 瀏覽器最常見的缺陷，
  本專案在 `Tab` 內保留 popup 緩衝與位移矩形，於 `PaintContent` 中疊在正確位置。
* 影像格式為 BGRA + premultiplied alpha；頁面底色不透明，因此可與 D2D 的
  `B8G8R8A8_UNORM / PREMULTIPLIED` 目標直接對接。

---

## 4. 輸入轉送

```
WM_MOUSEMOVE / WM_LBUTTONDOWN / WM_MOUSEWHEEL / WM_KEYDOWN / WM_CHAR
        │
        ├─ 座標落在「chrome」(分頁列/工具列/書籤列) → 由 MainWindow 自己處理
        │     · 命中測試全部用 DIP 座標 (px / scale)，與繪製共用同一套 Layout
        │     · hover 狀態集中在一處，重繪整個視窗 (D2D 很快)
        │
        └─ 座標落在「內容區」→ 轉成 CEF view 座標 (DIP，相對於內容區原點)
              · SendMouseMoveEvent / SendMouseClickEvent / SendMouseWheelEvent
              · SendKeyEvent (RAWKEYDOWN → CHAR → KEYUP，與 Chromium 的期待一致)
              · 修飾鍵由 GetKeyState 轉成 EVENTFLAG_*
```

DPI 處理原則：

| 概念 | 單位 | 使用者 |
|---|---|---|
| 佈局常數 (`kTabStripHeight` …) | DIP | 所有 Direct2D 繪製 |
| 視窗/子視窗位置 | 實體像素 | `SetWindowPos`、`Omnibox::SetBoundsPx` |
| CEF `GetViewRect` | DIP | `Tab::view_dip_width()` |
| CEF `OnPaint` 緩衝 | 實體像素 | `width × device_scale_factor` |
| CEF 滑鼠座標 | DIP | `MainWindow::ClientPxToViewDip()` |

`GetScreenInfo` 回報 `device_scale_factor`，讓 Chromium 在 150% / 200% 螢幕上
渲染高解析度內容（而不是被放大成模糊畫面）。

---

## 5. 無邊框視窗（自研外框）

```
WS_POPUP | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_CLIPCHILDREN

WM_NCCALCSIZE  → 回傳 0：整個視窗都是 client area（＝沒有原生標題列）
                 最大化時把 rgrc[0] 縮回工作區，避免內容被螢幕邊緣裁掉
WM_GETMINMAXINFO → ptMaxSize/ptMaxPosition 配合上面的縮減，兩者必須成對調整
WM_NCHITTEST   → 邊緣 6px 對應 HTLEFT/HTTOP/HTTOPRIGHT …
                 空白分頁列區域 → HTCAPTION（可拖曳、雙擊最大化、Aero Snap）
                 分頁 / 按鈕 / 網頁內容 → HTCLIENT（我們要自己收滑鼠事件）
```

**為什麼要 `HTCLIENT` 而不是 `HTMAXBUTTON`？** 因為按鈕是自繪的，需要收到
`WM_LBUTTONDOWN`。代價是失去 Windows 11 的「滑鼠停在最大化鈕顯示分割版面」功能；
若日後要補回，只要讓最大化鈕回傳 `HTMAXBUTTON` 並監聽 `WM_NCLBUTTONDOWN` 即可。

---

## 6. 分頁生命週期（含非同步關閉）

```
CreateTab(url, foreground)
  ├─ new Tab(id)                       // 先建狀態物件
  ├─ tabs_.insert(index, tab)          // 修正 active_ 索引
  ├─ ui_->OnTabCreated(tab)            // 分頁列立刻出現（標題「新分頁」）
  └─ CefBrowserHost::CreateBrowser(OSR …)   // 非同步！

  … Chromium 建立 browser 行程 …
  └─ TabClient::OnAfterCreated
        └─ TabManager::OnBrowserCreated
              ├─ tab->SetBrowser(browser)  → WasResized()
              ├─ 非前景分頁 → WasHidden(true)
              └─ ui_->OnTabChanged(tab)

關閉：
  CloseTab(i) → browser->GetHost()->CloseBrowser(false)   // 允許 beforeunload 攔截
      └─ TabClient::DoClose()      → return false（讓 CEF 繼續關閉流程）
      └─ TabClient::OnBeforeClose()
            └─ TabManager::OnBrowserClosed(tab)   // 這裡才 delete Tab
                  ├─ 還有分頁 → 重新 ActivateTab
                  └─ 沒分頁了 → ui_->OnAllTabsClosed()
                        └─ PostMessage(kMsgAllTabsClosed)   // ★ 不可同步 DestroyWindow
                              └─ DestroyWindow → WM_DESTROY → PostQuitMessage
```

★ 的關鍵：`OnAllTabsClosed` 是從 CEF 的回呼堆疊裡被呼叫的，如果直接
`DestroyWindow`，會把 `TabManager`（連同 `TabClient` 的 `manager_`）解構掉，
CEF 返回到自己的程式碼時就可能踩到已釋放的物件。改用 `PostMessage` 把銷毀
延後到回呼返回之後，是最穩定的做法（同時 3 秒強制關閉計時器可避免
`beforeunload` 卡死視窗）。

---

## 7. UI 元件的實作取捨

| 元件 | 作法 | 理由 |
|---|---|---|
| 分頁列 | 純 Direct2D 路徑（`ID2D1PathGeometry` 畫只有上緣圓角的分頁） | Chrome 的招牌視覺；Win32 沒有任何現成控制項能做到 |
| 網址列 | D2D 畫膠囊 + **原生 `EDIT` 子視窗**疊上去 | 只有原生 EDIT 能免費取得完整 IME 組字、觸控選字、協助工具支援。外觀仍 100% 由我們控制（`WM_CTLCOLOREDIT` 換色、無邊框、自訂字型） |
| 書籤列 | D2D 膠囊 + DWrite 量測寬度 | 需要精準的 CJK 文字寬度，自己排版比 owner-draw 按鈕簡單 |
| 彈出選單 | `WS_POPUP` 視窗 + D2D + 巢狀訊息迴圈 | 原生 `TrackPopupMenu` 在 Win10 無法深色化，外觀與 Chrome 差距太大 |
| 圖示 | `ID2D1PathGeometry` 向量描邊（圓頭線帽） | 任何 DPI 都銳利、不需圖檔、不需 icon font |
| App 圖示 | 執行時用 `ID2D1DCRenderTarget` 畫進 DIB → `CreateIconIndirect` | 專案零二進位資產，圖示仍可隨 DPI 產生多尺寸 |
| 設定檔 | 自寫扁平 JSON (`MiniJson`) | 只有十幾個 key，不值得引入第三方 JSON 函式庫 |
| 書籤/歷史 | TSV 純文字 | 使用者可直接用記事本編輯、可用 git diff、不需要解析器 |

---

## 8. 可攜性的四道防線（為什麼要四道）

Chromium 的資料位置分散在非常多地方：profile、disk cache、GPU shader cache、
crash dumps、log、各子行程的 TEMP、下載預設目錄……
單靠一個設定一定會漏，因此：

1. `CefSettings`（`root_cache_path` / `log_file` / `locales_dir_path`）
2. 命令列開關（**會被所有子行程繼承**，包含 renderer / utility）
3. `TMP` / `TEMP` 環境變數重導
4. 應用層所有檔案 I/O 都經過 `PortablePaths`（唯一 SSOT）

外加一個「單一實例鎖」綁在資料夾雜湊上，讓同一台機器上可以同時跑多份
不同資料夾的可攜副本，互不干擾。

---

## 9. 若要繼續擴充，建議的切入點

| 目標 | 建議改動 |
|---|---|
| 分頁拖曳排序 | `TabStrip` 增加 drag 狀態 + `MainWindow` 處理 `WM_LBUTTONDOWN` 後的追蹤；`TabManager` 加 `MoveTab(from, to)` |
| 多視窗 | 把 `MainWindow` 的擁有權交給一個 `WindowManager`；`TabManager` 改為每視窗一個 |
| 硬體加速合成 | `window_info.shared_texture_enabled = true` + `OnAcceleratedPaint` + 共享紋理直接呈現給 D3D11 交換鏈 |
| 完整沙箱 | 連結 `cef_sandbox.lib`、`CefScopedSandboxInfo`、移除 `no_sandbox`、`browser_subprocess_path` 保持指向自己 |
| 網址列建議 | `CefRequestHandler::GetResourceRequestHandler` 或接自訂 HTTP 客戶端查詢搜尋建議；`Omnibox` 加下拉清單視窗 |
| 書籤管理 UI | 已有 `ui_pages::WriteBookmarksPage`，改成可互動（拖曳/編輯）需要 `CefMessageRouter` 或自訂 scheme handler |
