# CEF 版本鎖定與 API 相容性筆記

本專案的 C++ 程式碼是**逐項對照 CEF 130 的實際標頭檔**驗證過的，不是憑印象寫的。
升級 CEF 前請務必讀完這份文件。

---

## 1. 鎖定版本

| 項目 | 值 |
|---|---|
| CEF 版本 | `130.1.16+g5a7e5ed+chromium-130.0.6723.117` |
| Chromium | `130.0.6723.117` |
| 平台 | `windows64`，**Standard** 發行包（非 minimal） |
| 檔名 | `cef_binary_130.1.16+g5a7e5ed+chromium-130.0.6723.117_windows64.tar.bz2` |
| 大小 | 335.3 MB |
| SHA1 | `5bc51f2378ddcf0d05abbb7d07681e48ba78b83e` |
| 下載 | <https://cef-builds.spotifycdn.com/index.html> |

取得方式：`scripts/fetch-cef.ps1`（已內建上述版本與 SHA1 驗證）。

**可用性備註**：CEF 141+ 的發行包結構有變動，且 `OnBeforePopup` 增加 `popup_id` 參數
（見 §2），因此本專案刻意停在 130。

---

## 2. 實際核對發現的「會讓編譯失敗」差異

以下是作者在撰寫時實際比對 `cef/include/*.h`（branch 6723 = Chromium 130）
與 **master / M132+** 後，確認的破壞性變更。本專案程式碼已針對 **130** 修正，
若你升級到 M132 以上，**這 5 處一定會編不過**：

### 2.1 `CefBrowserHost` 沒有獨立標頭檔

```cpp
// ✗ 錯：這個檔案不存在
#include "include/cef_browser_host.h"

// ✓ 對：CefBrowserHost 宣告在 cef_browser.h 裡
#include "include/cef_browser.h"
```

### 2.2 `OnCursorChange` 從 `CefRenderHandler` 搬到 `CefDisplayHandler`，且回傳 `bool`

```cpp
// CEF 130：宣告在 CefDisplayHandler
virtual bool OnCursorChange(CefRefPtr<CefBrowser> browser,
                            CefCursorHandle cursor,
                            cef_cursor_type_t type,
                            const CefCursorInfo& custom_cursor_info);
```

舊版（M9x 以前）在 `CefRenderHandler` 且回傳 `void`。
本專案在 `src/app/TabClient.h` 把它實作在 DisplayHandler 區塊，回傳 `true`
（表示游標由自繪視窗自行套用）。

### 2.3 `OnBeforeDownload` 回傳 `bool`

```cpp
virtual bool OnBeforeDownload(CefRefPtr<CefBrowser> browser,
                              CefRefPtr<CefDownloadItem> download_item,
                              const CefString& suggested_name,
                              CefRefPtr<CefBeforeDownloadCallback> callback);
```

本專案在 `Continue()` 之後 `return true`。

### 2.4 `CefBrowser::Reload()` 不吃參數

```cpp
virtual void Reload() = 0;              // 普通重新載入
virtual void ReloadIgnoreCache() = 0;   // 忽略快取的硬重載 (Ctrl+Shift+R)
```

舊版是 `Reload(bool ignore_cache)`。

### 2.5 `CefSettings` 的產品字串欄位改名

```cpp
// CEF >= 120
CefString(&settings.user_agent_product).FromWString(L"Lumen/1.0.0");

// 舊版寫法（CEF 100 附近）：settings.product_version
```

### 2.6 尚未影響本專案、但升級到 M132+ 一定會撞到的變更

```cpp
// CEF M132+ 的 CefLifeSpanHandler::OnBeforePopup 多了第 3 個參數 popup_id
virtual bool OnBeforePopup(CefRefPtr<CefBrowser> browser,
                           CefRefPtr<CefFrame> frame,
                           int popup_id,                 // ← 新增
                           const CefString& target_url,
                           ...);
```

若要升到 M132+，必須在 `src/app/TabClient.h/.cpp` 的 `OnBeforePopup`
簽名中加上 `int popup_id,`（並用 `CEF_VERSION_MAJOR` 做條件編譯）。

---

## 2.7 CMake 整合的 5 個硬事實（已對照封裝內實際檔案驗證）

CEF 發行包的 CMake 結構和一般專案不同，**照一般習慣寫會直接 configure 失敗或連結失敗**：

| # | 事實 | 錯誤寫法（會炸） | 正確寫法 |
|---|---|---|---|
| 1 | `cmake/` 目錄裡**只有 3 個 `.cmake`，沒有 `CMakeLists.txt`** | `add_subdirectory(${CEF_ROOT}/cmake)` | `list(APPEND CMAKE_MODULE_PATH "${CEF_ROOT}/cmake")` + `find_package(CEF REQUIRED)` |
| 2 | `libcef_dll_wrapper` 目標來自 `libcef_dll/CMakeLists.txt` | 只依賴 `find_package` 就以為有目標 | `add_subdirectory("${CEF_LIBCEF_DLL_WRAPPER_PATH}" libcef_dll_wrapper)` |
| 3 | `libcef.lib` 是 **IMPORTED 目標 `libcef_lib`，必須自己建立** | 只 link `libcef_dll_wrapper` → 整排 `LNK2019 CefXxx 未解析` | `add_logical_target("libcef_lib" "${CEF_LIB_DEBUG}" "${CEF_LIB_RELEASE}")` |
| 4 | 官方 wrapper 用 **`/MT`（靜態 CRT）**：`CEF_RUNTIME_LIBRARY_FLAG = "/MT"` | 專案用 `/MD` → `LNK2038 RuntimeLibrary mismatch` | `MSVC_RUNTIME_LIBRARY = MultiThreaded$<$<CONFIG:Debug>:Debug>` |
| 5 | 執行期檔在 `${CEF_ROOT}/$<CONFIG>`（不是固定 `Release/`），資源在 `${CEF_ROOT}/Resources`（含 `locales/`） | 只複製 `Release/` → Debug 建置拿到錯的 DLL | POST_BUILD `copy_directory "${CEF_ROOT}/$<CONFIG>"` + `"${CEF_ROOT}/Resources"` |

附帶結論：因為採 `/MT`，**使用者端不需要安裝 VC++ 可轉散發套件**（`VCRUNTIME140.dll` 已靜態進 exe）。

### 2.8 Windows 內建 `tar.exe` 解不開 `.tar.bz2`

CEF 的 windows64 只提供 `.tar.bz2`。Windows 10 的 `tar.exe` 是 bsdtar，**沒編入 bzip2 filter**，所以：

```
tar.exe: Error opening archive: Can't initialize filter; unable to run program "bzip2 -d"
```

解法（`scripts/fetch-cef.ps1` 已自動處理三段式）：

1. 先試 `tar.exe`（若系統剛好有 `bzip2.exe` 就能用）；
2. 否則找已安裝的 7-Zip（`%ProgramFiles%\7-Zip\7z.exe` 或 PATH）；
3. 都沒有就下載**7-Zip 官方免安裝主控台版**到 `scripts\tools\`：
   `https://www.7-zip.org/a/7zr.exe`（602,624 bytes）
   → 解 `https://www.7-zip.org/a/7z2301-extra.7z`（1,027,828 bytes，內含 `x64/7za.exe`）
   → 用 `7za.exe` 兩段解壓（`.tar.bz2` → `.tar` → 檔案）。全程不需要管理員權限、不寫登錄檔。

手動替代：直接從 <https://www.7-zip.org/> 安裝 7-Zip，右鍵 `.tar.bz2` → 7-Zip → 解壓兩次。

## 3. 已確認「存在且用法正確」的 API（節錄）

| 用途 | API | 備註 |
|---|---|---|
| 離屏渲染 | `CefWindowInfo::SetAsWindowless(parent)` | 在 `include/internal/cef_win.h` |
| 共享紋理開關 | `CefWindowInfo::shared_texture_enabled` | 在 `include/internal/cef_types_win.h` |
| 影格率 | **`CefBrowserSettings::windowless_frame_rate`** | ⚠️ 不在 CefWindowInfo |
| 外部訊息幫浦 | `CefSettings::external_message_pump` + `CefBrowserProcessHandler::OnScheduleMessagePumpWork` | |
| 可攜路徑 | `CefSettings::root_cache_path` / `log_file` / `locales_dir_path` / `resources_dir_path` | |
| 金鑰事件 | `cef_key_event_t{type, modifiers, windows_key_code, native_key_code, is_system_key, character(char16_t), unmodified_character}` | |
| 選單 id | `MENUITEMTYPE_SEPARATOR`（`CefMenuModel::MenuItemType`） | |
| 右鍵選單回呼 | `CefRunContextMenuCallback::Continue(int, cef_event_flags_t)` / `Cancel()` | |
| 編輯命令 | `CefFrame::Copy/Cut/Paste/SelectAll/Undo/ViewSource` | |
| 錯誤碼 | `ERR_ABORTED` 等由 `include/base/internal/cef_net_error_list.h` 巨集展開 | 需經 `cef_load_handler.h` 的 `ErrorCode` typedef |

---

## 4. 升級 CEF 的檢查清單

1. 到 <https://cef-builds.spotifycdn.com/index.html> 找目標版本的 `windows64` **Standard** 包。
2. 解壓後，先把 `include/` 與本專案用到的標頭檔 diff 一次，重點看：
   - `cef_life_span_handler.h` → `OnBeforePopup`
   - `cef_display_handler.h` / `cef_render_handler.h` → `OnCursorChange`、`OnPaint`、`GetScreenInfo`
   - `cef_download_handler.h` → `OnBeforeDownload`
   - `cef_browser.h` → `CefBrowserHost` 的方法簽名（`Reload`、`SendKeyEvent`…）
   - `include/internal/cef_types.h` → `cef_settings_t` 欄位
3. 改完程式碼後，更新 `scripts/fetch-cef.ps1` 裡的 `-Version` 預設值與 SHA1。
4. 重新建置（`scripts/build.ps1`）。

---

## 5. CEF 發行包內容備忘

`cef_binary_*_windows64` **Standard** 包包含：

```
cmake/            官方 CMake 包裝層 (cef_variables.cmake / cef_macros.cmake)
include/          CEF 標頭（含 internal/ 的 C struct 與 C++ wrapper）
libcef_dll/       wrapper 原始碼（編譯成 libcef_dll_wrapper 靜態庫）
Release/          libcef.dll, libcef.lib, chrome_elf.dll, d3dcompiler_47.dll,
                  libEGL.dll, libGLESv2.dll, vk_swiftshader.dll, vulkan-1.dll,
                  *.pak, icudtl.dat, v8_context_snapshot.bin, swiftshader/
Resources/        locales/*.pak, *.pak
Debug/            除錯版執行期（可選）
tests/            cefclient / cefsimple 範例
```

`minimal` 包**不含** `cmake/`、`libcef_dll/`、`tests/`，**不能**用來建置本專案。
