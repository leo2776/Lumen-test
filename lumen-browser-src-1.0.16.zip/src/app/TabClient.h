// ===========================================================================
//  Lumen Browser — app/TabClient.h
//  每個分頁一個 CefClient。實作所有需要的 Handler：
//    CefRenderHandler      離屏渲染 (把 BGRA 緩衝交給 Tab)
//    CefDisplayHandler     標題 / URL / 狀態列
//    CefLoadHandler        載入狀態 / 進度 / 錯誤頁
//    CefLifeSpanHandler    建立 / 關閉 / popup 攔截
//    CefRequestHandler     renderer 崩潰復原
//    CefContextMenuHandler 自繪深色右鍵選單
//    CefDownloadHandler    下載導向 ./browser_data/downloads
// ===========================================================================
#pragma once

#include "core/Platform.h"

#include "include/cef_client.h"
#include "include/cef_context_menu_handler.h"
#include "include/cef_download_handler.h"
#include "include/cef_life_span_handler.h"
#include "include/cef_load_handler.h"
#include "include/cef_render_handler.h"
#include "include/cef_request_handler.h"

namespace lumen {

class Tab;
class TabManager;

class TabClient : public CefClient,
                  public CefRenderHandler,
                  public CefDisplayHandler,
                  public CefLoadHandler,
                  public CefLifeSpanHandler,
                  public CefRequestHandler,
                  public CefContextMenuHandler,
                  public CefDownloadHandler {
 public:
  TabClient(TabManager* manager, Tab* tab);

  // ---- CefClient --------------------------------------------------------
  CefRefPtr<CefRenderHandler> GetRenderHandler() override { return this; }
  CefRefPtr<CefDisplayHandler> GetDisplayHandler() override { return this; }
  CefRefPtr<CefLoadHandler> GetLoadHandler() override { return this; }
  CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override { return this; }
  CefRefPtr<CefRequestHandler> GetRequestHandler() override { return this; }
  CefRefPtr<CefContextMenuHandler> GetContextMenuHandler() override { return this; }
  CefRefPtr<CefDownloadHandler> GetDownloadHandler() override { return this; }

  // ---- CefRenderHandler -------------------------------------------------
  void GetViewRect(CefRefPtr<CefBrowser> browser, CefRect& rect) override;
  bool GetScreenInfo(CefRefPtr<CefBrowser> browser, CefScreenInfo& screen_info) override;
  void OnPaint(CefRefPtr<CefBrowser> browser, PaintElementType type, const RectList& dirtyRects,
               const void* buffer, int width, int height) override;
  void OnPopupShow(CefRefPtr<CefBrowser> browser, bool show) override;
  void OnPopupSize(CefRefPtr<CefBrowser> browser, const CefRect& rect) override;
  // ---- CefDisplayHandler ------------------------------------------------
  //  注意：CEF 新版本把 OnCursorChange 從 CefRenderHandler 移到
  //  CefDisplayHandler，且回傳值改為 bool (true = 已自行處理游標)。
  bool OnCursorChange(CefRefPtr<CefBrowser> browser, CefCursorHandle cursor, cef_cursor_type_t type,
                      const CefCursorInfo& custom_cursor_info) override;
  void OnAddressChange(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                       const CefString& url) override;
  void OnTitleChange(CefRefPtr<CefBrowser> browser, const CefString& title) override;
  void OnStatusMessage(CefRefPtr<CefBrowser> browser, const CefString& value) override;

  // ---- CefLoadHandler ---------------------------------------------------
  void OnLoadingStateChange(CefRefPtr<CefBrowser> browser, bool isLoading, bool canGoBack,
                            bool canGoForward) override;
  void OnLoadStart(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                   TransitionType transition_type) override;
  void OnLoadEnd(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                 int httpStatusCode) override;
  void OnLoadError(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame, ErrorCode errorCode,
                   const CefString& errorText, const CefString& failedUrl) override;

  // ---- CefLifeSpanHandler ----------------------------------------------
  bool OnBeforePopup(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                     const CefString& target_url, const CefString& target_frame_name,
                     CefLifeSpanHandler::WindowOpenDisposition target_disposition,
                     bool user_gesture,
                     const CefPopupFeatures& popup_features, CefWindowInfo& window_info,
                     CefRefPtr<CefClient>& client, CefBrowserSettings& settings,
                     CefRefPtr<CefDictionaryValue>& extra_info,
                     bool* no_javascript_access) override;
  void OnAfterCreated(CefRefPtr<CefBrowser> browser) override;
  bool DoClose(CefRefPtr<CefBrowser> browser) override;
  void OnBeforeClose(CefRefPtr<CefBrowser> browser) override;

  // ---- CefRequestHandler -----------------------------------------------
  void OnRenderProcessTerminated(CefRefPtr<CefBrowser> browser, TerminationStatus status,
                                 int error_code, const CefString& error_string) override;

  // ---- CefContextMenuHandler -------------------------------------------
  void OnBeforeContextMenu(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                           CefRefPtr<CefContextMenuParams> params,
                           CefRefPtr<CefMenuModel> model) override;
  bool RunContextMenu(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                      CefRefPtr<CefContextMenuParams> params, CefRefPtr<CefMenuModel> model,
                      CefRefPtr<CefRunContextMenuCallback> callback) override;
  bool OnContextMenuCommand(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                            CefRefPtr<CefContextMenuParams> params, int command_id,
                            EventFlags event_flags) override;

  // ---- CefDownloadHandler ----------------------------------------------
  bool OnBeforeDownload(CefRefPtr<CefBrowser> browser, CefRefPtr<CefDownloadItem> download_item,
                        const CefString& suggested_name,
                        CefRefPtr<CefBeforeDownloadCallback> callback) override;
  void OnDownloadUpdated(CefRefPtr<CefBrowser> browser, CefRefPtr<CefDownloadItem> download_item,
                         CefRefPtr<CefDownloadItemCallback> callback) override;

  // 右鍵選單的自訂命令 ID
  enum MenuCommand {
    kCmdBack = 2001,
    kCmdForward,
    kCmdReload,
    kCmdCopy,
    kCmdPaste,
    kCmdCut,
    kCmdSelectAll,
    kCmdViewSource,
    kCmdPrint,
  };

 private:
  void NotifyChanged();

  TabManager* manager_ = nullptr;   // 不持有
  Tab* tab_ = nullptr;              // 不持有 (由 TabManager 擁有)
  bool closing_ = false;
  int frames_seen_ = 0;        // 診斷用：收到幾張 frame
  int renderer_crashes_ = 0;   // 診斷用：渲染程序結束次數（避免無限重載）

  IMPLEMENT_REFCOUNTING(TabClient);
};

}  // namespace lumen
