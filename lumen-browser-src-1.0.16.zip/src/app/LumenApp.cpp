#include "app/LumenApp.h"

#include "app/MessagePump.h"
#include "core/PortablePaths.h"
#include "util/WinUtil.h"

#include "include/cef_command_line.h"

namespace lumen {

LumenApp::LumenApp() = default;

// ---------------------------------------------------------------------------
//  ★ 可攜性的第二道防線 ★
//  即使 CefSettings 已經指定路徑，Chromium 內部仍有許多路徑來自命令列
//  開關 (而且會被 renderer / gpu / utility 子行程沿用)。這裡把所有
//  「會寫檔」的開關全部釘死在 ./browser_data 之下。
// ---------------------------------------------------------------------------
void LumenApp::OnBeforeCommandLineProcessing(const CefString& process_type,
                                            CefRefPtr<CefCommandLine> command_line) {
  if (!command_line) return;

  const std::wstring profile = PortablePaths::ProfileDir();
  const std::wstring cache = PortablePaths::CacheDir();
  const std::wstring crash = PortablePaths::CrashDir();
  const std::wstring logs = PortablePaths::LogDir();

  if (!profile.empty()) {
    command_line->AppendSwitchWithValue("user-data-dir", ToUtf8(profile));
  }
  if (!cache.empty()) {
    command_line->AppendSwitchWithValue("disk-cache-dir", ToUtf8(cache));
    command_line->AppendSwitchWithValue("gpu-shader-cache-dir", ToUtf8(JoinPath(cache, L"gpu")));
  }
  if (!crash.empty()) {
    command_line->AppendSwitchWithValue("crash-dumps-dir", ToUtf8(crash));
    command_line->AppendSwitchWithValue("database", ToUtf8(JoinPath(crash, L"db")));
  }
  command_line->AppendSwitchWithValue("log-file", ToUtf8(PortablePaths::LogFile(L"cef.log")));
  (void)logs;

  // 不產生任何系統層級副作用 / 不打擾使用者的開關
  command_line->AppendSwitch("no-first-run");
  command_line->AppendSwitch("no-default-browser-check");
  command_line->AppendSwitch("disable-component-update");
  command_line->AppendSwitch("disable-background-networking");
  command_line->AppendSwitch("disable-sync");
  command_line->AppendSwitch("disable-domain-reliability");
  command_line->AppendSwitch("disable-breakpad");           // crash 由 CEF 內部紀錄即可
  command_line->AppendSwitch("disable-client-side-phishing-detection");
  command_line->AppendSwitch("disable-extensions");
  command_line->AppendSwitch("disable-plugins-discovery");
  command_line->AppendSwitch("disable-prompt-on-repost");
  command_line->AppendSwitch("no-pings");
  command_line->AppendSwitch("metrics-recording-only");
  command_line->AppendSwitchWithValue("force-color-profile", "srgb");
  // ★ 沙箱 / 子行程相關：
  //   Lumen 是「單一 exe 可攜」模式，沒有連結 cef_sandbox.lib，因此必須全面關閉沙箱。
  //   其中 NetworkServiceSandbox 與 RendererCodeIntegrity 在未簽章的執行檔上特別容易
  //   讓子行程直接被擋掉 —— 症狀就是 "Network service crashed, restarting service."
  //   然後所有網路請求永遠不完成（分頁一直轉圈）。
  command_line->AppendSwitch("no-sandbox");
  command_line->AppendSwitchWithValue(
      "disable-features",
      "Translate,MediaRouter,OptimizationHints,NetworkServiceSandbox,RendererCodeIntegrity");

  // ★ 虛擬機 / 遠端桌面 / 老顯卡：硬體合成常常起不來，會導致「畫面永遠不來、
  //   分頁一直轉圈」。OSR 走軟體繪製最穩，成本也只有一點 CPU。
  command_line->AppendSwitch("disable-gpu");
  command_line->AppendSwitch("disable-gpu-compositing");
  command_line->AppendSwitch("disable-gpu-vsync");

  // 選用的最後手段：若這台機器根本無法啟動子行程（企業防毒/AppLocker 常見），
  // 用  lumen.exe --lumen-single-process  可以把渲染拉回同一個行程，用來確認病因。
  {
    const std::wstring cmd = ::GetCommandLineW();
    if (cmd.find(L"--lumen-single-process") != std::wstring::npos) {
      command_line->AppendSwitch("single-process");
      DiagLog("SAFE MODE: --single-process enabled by user");
    }
  }

  DiagLog("command line prepared (disable-gpu, software compositing)");
}

void LumenApp::OnContextInitialized() {
  // Browser 程序已就緒。真正的視窗由 main.cpp 在 CefInitialize 回傳後建立，
  // 這樣 UI 物件生命週期完全由我們掌控。
}

void LumenApp::OnScheduleMessagePumpWork(int64_t delay_ms) {
  ScheduleExternalPumpWork(delay_ms);
}

}  // namespace lumen
