// ===========================================================================
//  Lumen Browser — util/WinUtil.h
//  Win32 小工具：字串轉換、DPI、檔案 I/O、路徑拼接。
//  刻意不使用 <filesystem> 以避免 MinGW/MSVC 版本差異，全部走 Win32 API。
// ===========================================================================
#pragma once

#include "core/Platform.h"

namespace lumen {

// ---- 字串 ----------------------------------------------------------------
std::string  ToUtf8(const std::wstring& w);
std::wstring ToWide(const std::string& s);

// ---- 路徑 ----------------------------------------------------------------
std::wstring ExePath();                       // 執行檔完整路徑
std::wstring ExeDirectory();                   // 執行檔所在資料夾 (可攜根目錄)
std::wstring JoinPath(const std::wstring& base, const std::wstring& child);
bool         DirectoryExists(const std::wstring& path);
bool         FileExists(const std::wstring& path);
bool         EnsureDirectory(const std::wstring& path);
std::wstring AbsolutePath(const std::wstring& path);
std::wstring FileUrlFromPath(const std::wstring& path);   // C:\a b\x.html -> file:///C:/a%20b/x.html

// ---- 檔案 I/O (UTF-8) ----------------------------------------------------
std::string  ReadTextFile(const std::wstring& path);
bool         WriteTextFile(const std::wstring& path, const std::string& content, bool append = false);
bool         DeleteFileQuiet(const std::wstring& path);

// ---- DPI -----------------------------------------------------------------
int   DpiForWindow(HWND hwnd);
int   SystemDpi();
int   ScaleDip(int dip, int dpi);             // DIP -> 實體像素
float UnscalePx(int px, int dpi);             // 實體像素 -> DIP
float DpiScale(int dpi);                      // 1.0 / 1.25 / 1.5 ...

// ---- 診斷日誌 (browser_data\logs\lumen.log) -------------------------------
//  為什麼要有這個：CEF 的失敗常常只表現成「一直轉圈」，沒有訊息。
//  這裡把關鍵里程碑 (初始化/建立 browser/載入/第一張 frame/渲染程序死掉)
//  寫成純文字日誌，出問題時只要看最後 20 行就能定位。
void DiagInit(const std::wstring& log_path);
void DiagLog(const char* fmt, ...);

// ---- 其他 ----------------------------------------------------------------
bool  EnablePerMonitorDpi();                  // Per-Monitor V2 (執行時動態呼叫)
void  SetDarkTitleBar(HWND hwnd, bool dark);  // DWM 深色邊框 (Win10 1809+)
void  SetRoundedCorners(HWND hwnd, bool enable);
int64_t UnixNow();
std::wstring FormatTimeForHistory(int64_t unix_seconds);

}  // namespace lumen
