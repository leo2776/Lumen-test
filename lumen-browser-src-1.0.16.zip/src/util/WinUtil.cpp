#include "util/WinUtil.h"

#include <cstdarg>
#include <dwmapi.h>
#include <shellapi.h>
#include <ctime>

#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "shell32.lib")

namespace lumen {
namespace {

std::wstring g_diag_path;
CRITICAL_SECTION g_diag_cs;
bool g_diag_cs_ready = false;

}  // namespace

void DiagInit(const std::wstring& log_path) {
  if (!g_diag_cs_ready) {
    ::InitializeCriticalSection(&g_diag_cs);
    g_diag_cs_ready = true;
  }
  g_diag_path = log_path;
}

void DiagLog(const char* fmt, ...) {
  if (g_diag_path.empty() || !g_diag_cs_ready || !fmt) return;

  char body[1024] = {0};
  va_list ap;
  va_start(ap, fmt);
  _vsnprintf_s(body, sizeof(body), _TRUNCATE, fmt, ap);
  va_end(ap);

  SYSTEMTIME st{};
  ::GetLocalTime(&st);
  char line[1200] = {0};
  _snprintf_s(line, sizeof(line), _TRUNCATE, "[%02u:%02u:%02u.%03u] %s\r\n", (unsigned)st.wHour,
              (unsigned)st.wMinute, (unsigned)st.wSecond, (unsigned)st.wMilliseconds, body);

  ::EnterCriticalSection(&g_diag_cs);
  const HANDLE h = ::CreateFileW(g_diag_path.c_str(), FILE_APPEND_DATA,
                                FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS,
                                FILE_ATTRIBUTE_NORMAL, nullptr);
  if (h != INVALID_HANDLE_VALUE) {
    DWORD written = 0;
    ::WriteFile(h, line, (DWORD)::strlen(line), &written, nullptr);
    ::CloseHandle(h);
  }
  ::LeaveCriticalSection(&g_diag_cs);
}

std::string ToUtf8(const std::wstring& w) {
  if (w.empty()) return std::string();
  const int len = ::WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
  if (len <= 0) return std::string();
  std::string out((size_t)len, '\0');
  ::WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &out[0], len, nullptr, nullptr);
  return out;
}

std::wstring ToWide(const std::string& s) {
  if (s.empty()) return std::wstring();
  const int len = ::MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
  if (len <= 0) return std::wstring();
  std::wstring out((size_t)len, L'\0');
  ::MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &out[0], len);
  return out;
}

std::wstring ExePath() {
  static std::wstring cached;
  if (!cached.empty()) return cached;
  std::wstring buf(MAX_PATH, L'\0');
  for (;;) {
    const DWORD n = ::GetModuleFileNameW(nullptr, &buf[0], (DWORD)buf.size());
    if (n == 0) return std::wstring();
    if (n < buf.size() - 1) { buf.resize(n); break; }
    buf.resize(buf.size() * 2);   // 路徑過長，擴張緩衝
  }
  cached = buf;
  return cached;
}

std::wstring ExeDirectory() {
  std::wstring path = ExePath();
  const size_t pos = path.find_last_of(L"\\/");
  if (pos == std::wstring::npos) return L".";
  return path.substr(0, pos);
}

std::wstring JoinPath(const std::wstring& base, const std::wstring& child) {
  if (base.empty()) return child;
  if (child.empty()) return base;
  wchar_t last = base[base.size() - 1];
  if (last == L'\\' || last == L'/') return base + child;
  return base + L"\\" + child;
}

bool DirectoryExists(const std::wstring& path) {
  const DWORD attr = ::GetFileAttributesW(path.c_str());
  return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) != 0;
}

bool FileExists(const std::wstring& path) {
  const DWORD attr = ::GetFileAttributesW(path.c_str());
  return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) == 0;
}

bool EnsureDirectory(const std::wstring& path) {
  if (path.empty()) return false;
  if (DirectoryExists(path)) return true;
  // 逐層建立，避免依賴 SHCreateDirectoryEx
  std::wstring current;
  for (size_t i = 0; i < path.size(); ++i) {
    current.push_back(path[i]);
    const bool separator = (path[i] == L'\\' || path[i] == L'/');
    const bool last = (i + 1 == path.size());
    if (separator || last) {
      if (current.size() > 1 && current != L"C:\\") {
        ::CreateDirectoryW(current.c_str(), nullptr);
      }
    }
  }
  return DirectoryExists(path);
}

std::wstring AbsolutePath(const std::wstring& path) {
  if (path.empty()) return path;
  wchar_t full[MAX_PATH * 2] = {0};
  const DWORD n = ::GetFullPathNameW(path.c_str(), (DWORD)(sizeof(full) / sizeof(full[0])), full, nullptr);
  if (n == 0 || n >= sizeof(full) / sizeof(full[0])) return path;
  return std::wstring(full, n);
}

std::wstring FileUrlFromPath(const std::wstring& path) {
  std::wstring abs = AbsolutePath(path);
  for (auto& c : abs) {
    if (c == L'\\') c = L'/';
  }
  std::wstring out = L"file:///";
  for (wchar_t c : abs) {
    const bool keep = (c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z') ||
                      (c >= L'0' && c <= L'9') || c == L'/' || c == L'-' || c == L'_' ||
                      c == L'.' || c == L'~' || c == L':' || c == L'?' || c == L'#' ||
                      c == L'=' || c == L'&' || c == L'%';
    if (keep) {
      out.push_back(c);
    } else {
      char utf8[8] = {0};
      const int len = ::WideCharToMultiByte(CP_UTF8, 0, &c, 1, utf8, sizeof(utf8), nullptr, nullptr);
      for (int i = 0; i < len; ++i) {
        wchar_t hex[8];
        ::swprintf_s(hex, L"%%%02X", (unsigned char)utf8[i]);
        out += hex;
      }
    }
  }
  return out;
}

std::string ReadTextFile(const std::wstring& path) {
  const HANDLE f = ::CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                 nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f == INVALID_HANDLE_VALUE) return std::string();
  LARGE_INTEGER size{};
  if (!::GetFileSizeEx(f, &size) || size.QuadPart <= 0 || size.QuadPart > (64ll << 20)) {
    ::CloseHandle(f);
    return std::string();
  }
  std::string data((size_t)size.QuadPart, '\0');
  DWORD read = 0;
  const BOOL ok = ::ReadFile(f, &data[0], (DWORD)data.size(), &read, nullptr);
  ::CloseHandle(f);
  if (!ok) return std::string();
  data.resize(read);
  // 去除 UTF-8 BOM
  if (data.size() >= 3 && (unsigned char)data[0] == 0xEF && (unsigned char)data[1] == 0xBB &&
      (unsigned char)data[2] == 0xBF) {
    data.erase(0, 3);
  }
  return data;
}

bool WriteTextFile(const std::wstring& path, const std::string& content, bool append) {
  const HANDLE f = ::CreateFileW(path.c_str(), append ? FILE_APPEND_DATA : GENERIC_WRITE,
                                 FILE_SHARE_READ, nullptr,
                                 append ? OPEN_ALWAYS : CREATE_ALWAYS,
                                 FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f == INVALID_HANDLE_VALUE) return false;
  DWORD written = 0;
  const BOOL ok = content.empty() ? TRUE : ::WriteFile(f, content.data(), (DWORD)content.size(), &written, nullptr);
  ::CloseHandle(f);
  return ok == TRUE && (content.empty() || written == content.size());
}

bool DeleteFileQuiet(const std::wstring& path) {
  return ::DeleteFileW(path.c_str()) == TRUE;
}

int SystemDpi() {
  HDC screen = ::GetDC(nullptr);
  int dpi = 96;
  if (screen) {
    dpi = ::GetDeviceCaps(screen, LOGPIXELSX);
    ::ReleaseDC(nullptr, screen);
  }
  return dpi > 0 ? dpi : 96;
}

int DpiForWindow(HWND hwnd) {
  // GetDpiForWindow 為 Win10 1607+ API，動態載入以免舊系統載入失敗
  using PFN_GetDpiForWindow = UINT(WINAPI*)(HWND);
  static PFN_GetDpiForWindow fn = reinterpret_cast<PFN_GetDpiForWindow>(
      ::GetProcAddress(::GetModuleHandleW(L"user32.dll"), "GetDpiForWindow"));
  if (fn && hwnd) {
    const UINT dpi = fn(hwnd);
    if (dpi > 0) return (int)dpi;
  }
  return SystemDpi();
}

int ScaleDip(int dip, int dpi) {
  return ::MulDiv(dip, dpi, 96);
}

float UnscalePx(int px, int dpi) {
  if (dpi <= 0) return (float)px;
  return (float)px * 96.0f / (float)dpi;
}

float DpiScale(int dpi) {
  return dpi > 0 ? (float)dpi / 96.0f : 1.0f;
}

bool EnablePerMonitorDpi() {
  using PFN_SetCtx = BOOL(WINAPI*)(DPI_AWARENESS_CONTEXT);
  static PFN_SetCtx fn = reinterpret_cast<PFN_SetCtx>(
      ::GetProcAddress(::GetModuleHandleW(L"user32.dll"), "SetProcessDpiAwarenessContext"));
  if (fn) {
    if (fn(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)) return true;
    if (fn(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE)) return true;
  }
  using PFN_SetAware = HRESULT(WINAPI*)(int);
  static PFN_SetAware legacy = []() -> PFN_SetAware {
    HMODULE shcore = ::LoadLibraryW(L"shcore.dll");
    if (!shcore) return nullptr;
    return reinterpret_cast<PFN_SetAware>(::GetProcAddress(shcore, "SetProcessDpiAwareness"));
  }();
  if (legacy && legacy(2 /*PROCESS_PER_MONITOR_DPI_AWARE*/) == S_OK) return true;
  ::SetProcessDPIAware();
  return false;
}

void SetDarkTitleBar(HWND hwnd, bool dark) {
  const BOOL value = dark ? TRUE : FALSE;
  // 20H1+ 使用 20，1809+ 使用 19
  constexpr DWORD kAttrImmersiveDarkMode = 20;
  constexpr DWORD kAttrImmersiveDarkModeOld = 19;
  if (FAILED(::DwmSetWindowAttribute(hwnd, kAttrImmersiveDarkMode, &value, sizeof(value)))) {
    ::DwmSetWindowAttribute(hwnd, kAttrImmersiveDarkModeOld, &value, sizeof(value));
  }
}

void SetRoundedCorners(HWND hwnd, bool enable) {
  constexpr DWORD kAttrWindowCornerPreference = 33;   // Win11
  const int pref = enable ? 2 /*DWMWCP_ROUND*/ : 1 /*DWMWCP_DONOTROUND*/;
  ::DwmSetWindowAttribute(hwnd, kAttrWindowCornerPreference, &pref, sizeof(pref));
}

int64_t UnixNow() {
  return (int64_t)::time(nullptr);
}

std::wstring FormatTimeForHistory(int64_t unix_seconds) {
  const time_t t = (time_t)unix_seconds;
  struct tm local {};
  localtime_s(&local, &t);
  wchar_t buf[64] = {0};
  ::swprintf_s(buf, L"%04d-%02d-%02d %02d:%02d", local.tm_year + 1900, local.tm_mon + 1,
               local.tm_mday, local.tm_hour, local.tm_min);
  return std::wstring(buf);
}

}  // namespace lumen
