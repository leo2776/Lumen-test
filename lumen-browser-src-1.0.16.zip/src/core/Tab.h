// ===========================================================================
//  Lumen Browser — core/Tab.h
//  單一分頁的狀態容器：CEF browser 物件、標題/URL/載入狀態、
//  離屏渲染 (OSR) 的像素緩衝、視圖尺寸與縮放係數。
//
//  設計說明：
//   Lumen 採用 CEF 的 Windowless Rendering (OSR)。每個分頁各自有
//   一份 BGRA 像素緩衝，只有「前景分頁」會被合成到視窗上；背景分頁
//   透過 WasHidden(true) 讓 Chromium 降低繪製頻率，節省 CPU。
// ===========================================================================
#pragma once

#include "core/Platform.h"

#include "include/cef_browser.h"

namespace lumen {

class Tab {
 public:
  explicit Tab(int id);

  int id() const { return id_; }

  CefRefPtr<CefBrowser> browser() const { return browser_; }
  void SetBrowser(CefRefPtr<CefBrowser> browser);
  bool HasBrowser() const;

  const std::wstring& title() const { return title_; }
  void SetTitle(const std::wstring& title);

  const std::wstring& url() const { return url_; }
  void SetUrl(const std::wstring& url);

  bool loading() const { return loading_; }
  void SetLoading(bool loading);

  double progress() const { return progress_; }
  void SetProgress(double progress);

  bool can_go_back() const { return can_go_back_; }
  bool can_go_forward() const { return can_go_forward_; }
  void SetNavState(bool back, bool forward);

  // ---- 離屏渲染緩衝 ------------------------------------------------------
  void SetFrame(const void* bgra, int width, int height);
  bool has_frame() const { return frame_width_ > 0 && frame_height_ > 0 && !frame_.empty(); }
  int frame_width() const { return frame_width_; }
  int frame_height() const { return frame_height_; }
  const uint8_t* frame_data() const { return frame_.empty() ? nullptr : frame_.data(); }
  // 每收到一張新畫面就 +1，用來判斷「畫面已經靜止多久」
  unsigned frame_serial() const { return frame_serial_; }

  // ---- 視圖尺寸 ----------------------------------------------------------
  // pixel 尺寸 = 用戶端內容區的實體像素；dpi_scale 供 GetScreenInfo 使用。
  void ResizeView(int pixel_width, int pixel_height, float dpi_scale);
  int view_pixel_width() const { return view_width_; }
  int view_pixel_height() const { return view_height_; }
  float dpi_scale() const { return dpi_scale_; }
  int view_dip_width() const;
  int view_dip_height() const;

  void SetHidden(bool hidden);
  bool hidden() const { return hidden_; }

  // ---- 下拉選單 / <select> popup (OSR 必須自行合成) ----------------------
  void SetPopupVisible(bool visible);
  bool popup_visible() const { return popup_visible_; }
  void SetPopupRect(int x, int y, int width, int height);
  int popup_x() const { return popup_x_; }
  int popup_y() const { return popup_y_; }
  int popup_width() const { return popup_width_; }
  int popup_height() const { return popup_height_; }
  void SetPopupFrame(const void* bgra, int width, int height);
  bool has_popup_frame() const { return popup_width_ > 0 && popup_height_ > 0 && !popup_frame_.empty(); }
  const uint8_t* popup_data() const { return popup_frame_.empty() ? nullptr : popup_frame_.data(); }

  // 讓 CEF 重新查詢 GetViewRect (視窗大小改變後呼叫)
  void NotifyWasResized();

 private:
  const int id_;
  CefRefPtr<CefBrowser> browser_;
  std::wstring title_ = L"新分頁";
  std::wstring url_;
  bool loading_ = false;
  double progress_ = 0.0;
  bool can_go_back_ = false;
  bool can_go_forward_ = false;

  std::vector<uint8_t> frame_;   // BGRA, 由下到上 (top-down)
  int frame_width_ = 0;
  int frame_height_ = 0;
  unsigned frame_serial_ = 0;

  int view_width_ = 0;
  int view_height_ = 0;
  float dpi_scale_ = 1.0f;
  bool hidden_ = false;
  bool was_resized_pending_ = false;

  std::vector<uint8_t> popup_frame_;
  bool popup_visible_ = false;
  int popup_x_ = 0;
  int popup_y_ = 0;
  int popup_width_ = 0;
  int popup_height_ = 0;
};

}  // namespace lumen
