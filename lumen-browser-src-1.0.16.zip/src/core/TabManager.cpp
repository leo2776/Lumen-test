#include "core/TabManager.h"

#include "app/TabClient.h"
#include "core/BrowserUI.h"
#include "core/PortablePaths.h"
#include "core/UrlUtil.h"
#include "util/WinUtil.h"

#include "include/cef_browser.h"

namespace lumen {

TabManager::TabManager(BrowserUI* ui, AppConfig* config, HistoryStore* history,
                       BookmarkStore* bookmarks)
    : ui_(ui), config_(config), history_(history), bookmarks_(bookmarks) {}

TabManager::~TabManager() = default;

std::wstring TabManager::SessionFile() const {
  return PortablePaths::ConfigFile(L"session.tsv");
}

bool TabManager::Initialize() {
  std::wstring start_url;
  if (config_->startup_mode == L"homepage" && !config_->homepage.empty()) {
    start_url = config_->homepage;
  } else {
    start_url = FileUrlFromPath(JoinPath(PortablePaths::UiDir(), L"newtab.html"));
  }

  if (config_->startup_mode == L"restore") {
    const std::string raw = ReadTextFile(SessionFile());
    if (!raw.empty()) {
      const std::wstring text = ToWide(raw);
      size_t pos = 0;
      int created = 0;
      while (pos < text.size()) {
        size_t eol = text.find(L'\n', pos);
        if (eol == std::wstring::npos) eol = text.size();
        std::wstring line = text.substr(pos, eol - pos);
        pos = eol + 1;
        if (!line.empty() && line.back() == L'\r') line.pop_back();
        if (line.empty() || line[0] == L'#') continue;
        CreateTab(line, created == 0);
        ++created;
      }
      if (created > 0) return true;
    }
  }

  CreateTab(start_url, true);
  return true;
}

Tab* TabManager::CreateTab(const std::wstring& url, bool foreground, int index) {
  const int new_id = next_id_++;
  auto owned = std::make_unique<Tab>(new_id);
  Tab* tab = owned.get();
  tab->ResizeView(content_width_, content_height_, dpi_scale_);

  if (index < 0 || index > (int)tabs_.size()) index = (int)tabs_.size();
  tabs_.insert(tabs_.begin() + index, std::move(owned));

  // 插入位置在前景分頁之前 → 前景索引要後移
  if (active_ >= index) ++active_;

  ui_->OnTabCreated(tab);

  CefWindowInfo window_info;
  window_info.SetAsWindowless(ui_->window_handle());
  window_info.shared_texture_enabled = false;   // 軟體離屏渲染 (相容性最高)

  CefBrowserSettings browser_settings;
  browser_settings.windowless_frame_rate = 60;   // 注意：此欄位在 CefBrowserSettings
  browser_settings.background_color = 0xFFFFFFFFu;   // 不透明白底，避免殘影
  browser_settings.javascript_access_clipboard = STATE_DISABLED;

  CefRefPtr<CefClient> client = new TabClient(this, tab);

  const std::wstring target = url.empty() ? L"about:blank" : url;
  DiagLog("CreateBrowser url=%s view=%dx%d scale=%.2f", ToUtf8(target).c_str(),
          tab->view_pixel_width(), tab->view_pixel_height(), tab->dpi_scale());
  CefBrowserHost::CreateBrowser(window_info, client, CefString(target), browser_settings, nullptr,
                                nullptr);

  if (foreground) {
    ActivateTab(index);
  } else {
    ui_->OnTabChanged(tab);   // 讓分頁列更新
  }
  return tab;
}

void TabManager::FocusOnly(Tab* tab) {
  for (auto& t : tabs_) {
    t->SetHidden(t.get() != tab);
  }
  if (tab) tab->SetHidden(false);
}

void TabManager::ActivateTab(int index) {
  if (index < 0 || index >= (int)tabs_.size()) return;
  active_ = index;
  Tab* tab = tabs_[index].get();
  ApplyContentSizeTo(tab);
  FocusOnly(tab);

  if (tab->HasBrowser()) {
    tab->browser()->GetHost()->SetFocus(true);
    if (tab->has_frame()) {
      // 立刻用快取畫面重繪，避免切換時白屏
      ui_->OnTabFrameReady(tab);
    } else {
      tab->browser()->GetHost()->Invalidate(PET_VIEW);
    }
  }
  ui_->OnTabChanged(tab);
}

void TabManager::ApplyContentSizeTo(Tab* tab) {
  if (!tab || content_width_ <= 0 || content_height_ <= 0) return;
  tab->ResizeView(content_width_, content_height_, dpi_scale_);
}

void TabManager::SetContentSize(int pixel_width, int pixel_height, float dpi_scale) {
  if (pixel_width <= 0 || pixel_height <= 0) return;
  content_width_ = pixel_width;
  content_height_ = pixel_height;
  dpi_scale_ = dpi_scale > 0.1f ? dpi_scale : 1.0f;
  for (auto& tab : tabs_) {
    tab->ResizeView(content_width_, content_height_, dpi_scale_);
  }
}

void TabManager::CloseTab(int index) {
  if (index < 0 || index >= (int)tabs_.size()) return;

  Tab* tab = tabs_[index].get();
  if (tab->HasBrowser()) {
    // force=false：允許頁面 beforeunload 攔截（Chrome 行為一致）
    tab->browser()->GetHost()->CloseBrowser(false);
    // 真正的移除在 OnBrowserClosed 中進行
    return;
  }

  // 尚未建立 browser 的分頁：直接移除
  const int id = tab->id();
  ui_->OnTabClosed(tab);
  tabs_.erase(tabs_.begin() + index);
  if (active_ >= index && active_ > 0) --active_;
  if (!tabs_.empty()) {
    if (active_ >= (int)tabs_.size()) active_ = (int)tabs_.size() - 1;
    ActivateTab(active_);
  } else {
    ui_->OnAllTabsClosed();
  }
  (void)id;
}

void TabManager::CloseAll(bool force) {
  closing_all_ = true;
  SaveSession();
  for (auto& tab : tabs_) {
    if (tab->HasBrowser()) {
      tab->browser()->GetHost()->CloseBrowser(force);
    }
  }
  if (tabs_.empty()) ui_->OnAllTabsClosed();
}

void TabManager::OnBrowserCreated(Tab* tab, CefRefPtr<CefBrowser> browser) {
  tab->SetBrowser(browser);
  ApplyContentSizeTo(tab);
  if (TabAt(active_) != tab) {
    tab->SetHidden(true);
  }
  ui_->OnTabChanged(tab);
}

void TabManager::OnBrowserClosing(Tab* tab) {
  (void)tab;
  // 由 MainWindow 決定是否允許關閉；此處僅記錄
}

void TabManager::OnBrowserClosed(Tab* tab) {
  int index = -1;
  for (int i = 0; i < (int)tabs_.size(); ++i) {
    if (tabs_[i].get() == tab) { index = i; break; }
  }
  if (index < 0) return;

  ui_->OnTabClosed(tab);
  tabs_.erase(tabs_.begin() + index);

  if (tabs_.empty()) {
    active_ = -1;
    ui_->OnAllTabsClosed();
    return;
  }
  if (active_ >= index) --active_;
  if (active_ < 0) active_ = 0;
  if (active_ >= (int)tabs_.size()) active_ = (int)tabs_.size() - 1;
  ActivateTab(active_);
}

Tab* TabManager::ActiveTab() const {
  if (active_ < 0 || active_ >= (int)tabs_.size()) return nullptr;
  return tabs_[active_].get();
}

Tab* TabManager::TabAt(int index) const {
  if (index < 0 || index >= (int)tabs_.size()) return nullptr;
  return tabs_[index].get();
}

Tab* TabManager::FindTabByBrowser(CefRefPtr<CefBrowser> browser) const {
  if (!browser) return nullptr;
  for (const auto& tab : tabs_) {
    if (tab->browser() && tab->browser()->IsSame(browser)) return tab.get();
  }
  return nullptr;
}

void TabManager::LoadUrl(const std::wstring& url) {
  Tab* tab = ActiveTab();
  if (!tab || !tab->HasBrowser()) return;
  tab->browser()->GetMainFrame()->LoadURL(CefString(url));
}

void TabManager::GoBack() {
  Tab* tab = ActiveTab();
  if (tab && tab->HasBrowser() && tab->browser()->CanGoBack()) tab->browser()->GoBack();
}

void TabManager::GoForward() {
  Tab* tab = ActiveTab();
  if (tab && tab->HasBrowser() && tab->browser()->CanGoForward()) tab->browser()->GoForward();
}

void TabManager::Reload(bool bypass_cache) {
  Tab* tab = ActiveTab();
  if (!tab || !tab->HasBrowser()) return;
  if (tab->loading()) {
    tab->browser()->StopLoad();
  } else if (bypass_cache) {
    tab->browser()->ReloadIgnoreCache();
  } else {
    tab->browser()->Reload();
  }
}

void TabManager::StopLoading() {
  Tab* tab = ActiveTab();
  if (tab && tab->HasBrowser()) tab->browser()->StopLoad();
}

void TabManager::ZoomStep(double delta) {
  Tab* tab = ActiveTab();
  if (!tab || !tab->HasBrowser()) return;
  CefRefPtr<CefBrowserHost> host = tab->browser()->GetHost();
  double level = host->GetZoomLevel() + delta;
  level = std::max(-5.0, std::min(5.0, level));
  host->SetZoomLevel(level);
}

void TabManager::ResetZoom() {
  Tab* tab = ActiveTab();
  if (tab && tab->HasBrowser()) tab->browser()->GetHost()->SetZoomLevel(0.0);
}

void TabManager::PrintActive() {
  Tab* tab = ActiveTab();
  if (tab && tab->HasBrowser()) tab->browser()->GetHost()->Print();
}

void TabManager::SavePageActive() {
  Tab* tab = ActiveTab();
  if (tab && tab->HasBrowser()) tab->browser()->GetHost()->StartDownload(CefString(tab->url()));
}

void TabManager::RecordHistory(Tab* tab) {
  if (!tab || !history_) return;
  if (tab->url().empty() || IsInternalUrl(tab->url())) return;
  history_->Add(tab->url(), tab->title());
}

void TabManager::SaveSession() {
  std::string out;
  out += "# Lumen session (one URL per line)\r\n";
  for (const auto& tab : tabs_) {
    if (tab->url().empty()) continue;
    out += ToUtf8(tab->url());
    out += "\r\n";
  }
  WriteTextFile(SessionFile(), out);
}

}  // namespace lumen
