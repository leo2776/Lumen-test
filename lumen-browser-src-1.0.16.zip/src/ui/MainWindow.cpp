#include "ui/MainWindow.h"

#include "core/PortablePaths.h"
#include "core/UiPages.h"
#include "core/UrlUtil.h"
#include "ui/Gfx.h"
#include "util/WinUtil.h"

#include "include/cef_browser.h"

#include <d2d1helper.h>
#include <cstdlib>
#include <shellapi.h>
#include <windowsx.h>

#pragma comment(lib, "shell32.lib")

namespace lumen {
namespace {

// ---- 尺寸常數 (DIP) ------------------------------------------------------
constexpr float kTabStripHeight = 40.0f;
constexpr float kToolbarHeight = 48.0f;
constexpr float kBookmarksHeight = 30.0f;
constexpr float kCaptionButtonWidth = 46.0f;
constexpr float kNavButtonSize = 32.0f;
constexpr float kOmniboxHeight = 32.0f;
constexpr float kLeftNavStart = 8.0f;

// ---- 選單命令 ID --------------------------------------------------------
enum MenuCommand {
  kCmdNewTab = 100,
  kCmdCloseTab,
  kCmdAddBookmark,
  kCmdShowBookmarks,
  kCmdShowHistory,
  kCmdShowDownloads,
  kCmdZoomIn,
  kCmdZoomOut,
  kCmdZoomReset,
  kCmdPrint,
  kCmdToggleTheme,
  kCmdToggleBookmarksBar,
  kCmdOpenDataFolder,
  kCmdAbout,
  kCmdExit,
  kCmdBookmarkBase = 5000,   // + index
};

RECT DipRectToPx(const D2D1_RECT_F& r, float scale) {
  RECT px;
  px.left = (LONG)std::lround(r.left * scale);
  px.top = (LONG)std::lround(r.top * scale);
  px.right = (LONG)std::lround(r.right * scale);
  px.bottom = (LONG)std::lround(r.bottom * scale);
  return px;
}

bool PointInRect(const D2D1_RECT_F& r, D2D1_POINT_2F p) {
  return p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom;
}

}  // namespace

MainWindow::MainWindow(HINSTANCE instance, AppConfig* config, HistoryStore* history,
                       BookmarkStore* bookmarks)
    : instance_(instance), config_(config), history_(history), bookmarks_(bookmarks) {}

MainWindow::~MainWindow() {
  if (web_bitmap_) web_bitmap_->Release();
  if (popup_bitmap_) popup_bitmap_->Release();
  if (target_) target_->Release();
  if (icon_big_) ::DestroyIcon(icon_big_);
  if (icon_small_) ::DestroyIcon(icon_small_);
}

// ---------------------------------------------------------------------------
//  建立視窗
// ---------------------------------------------------------------------------
bool MainWindow::Create(int show_command) {
  if (!Gfx::Get().Initialize()) {
    ::MessageBoxW(nullptr, L"無法初始化 Direct2D / DirectWrite。", kAppName, MB_ICONERROR);
    return false;
  }

  WNDCLASSEXW wc{};
  wc.cbSize = sizeof(wc);
  wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
  wc.lpfnWndProc = &MainWindow::WndProc;
  wc.hInstance = instance_;
  wc.hCursor = ::LoadCursorW(nullptr, IDC_ARROW);
  wc.hbrBackground = nullptr;
  wc.lpszClassName = kWindowClass;
  wc.lpszMenuName = nullptr;
  if (!::RegisterClassExW(&wc) && ::GetLastError() != ERROR_CLASS_ALREADY_EXISTS) {
    return false;
  }

  dpi_ = SystemDpi();
  scale_ = DpiScale(dpi_);
  theme_ = Theme::ForMode(config_->dark());

  int width = config_->window_width;
  int height = config_->window_height;
  RECT work{};
  ::SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
  if (width > work.right - work.left) width = work.right - work.left;
  if (height > work.bottom - work.top) height = work.bottom - work.top;

#ifdef LUMEN_NATIVE_FRAME
  const DWORD style = WS_OVERLAPPEDWINDOW;
#else
  const DWORD style = WS_POPUP | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_CLIPCHILDREN;
#endif

  RECT window_rect{0, 0, ScaleDip(width, dpi_), ScaleDip(height, dpi_)};
  ::AdjustWindowRectEx(&window_rect, style, FALSE, 0);
  const int window_w = window_rect.right - window_rect.left;
  const int window_h = window_rect.bottom - window_rect.top;

  const int x = work.left + ((work.right - work.left) - window_w) / 2;
  const int y = work.top + ((work.bottom - work.top) - window_h) / 2;

  hwnd_ = ::CreateWindowExW(0, kWindowClass, L"Lumen", style, x, y, window_w, window_h, nullptr,
                            nullptr, instance_, this);
  if (!hwnd_) return false;

  // DPI 可能因為視窗落在高 DPI 螢幕而改變
  dpi_ = DpiForWindow(hwnd_);
  scale_ = DpiScale(dpi_);

  icon_big_ = CreateAppIcon(64, theme_.dark);
  icon_small_ = CreateAppIcon(20, theme_.dark);
  if (icon_big_) ::SendMessageW(hwnd_, WM_SETICON, ICON_BIG, (LPARAM)icon_big_);
  if (icon_small_) ::SendMessageW(hwnd_, WM_SETICON, ICON_SMALL, (LPARAM)icon_small_);

  SetDarkTitleBar(hwnd_, theme_.dark);
  SetRoundedCorners(hwnd_, true);

  omnibox_.Create(hwnd_, instance_);
  omnibox_.on_submit = [this](const std::wstring&) { NavigateFromOmnibox(); };
  omnibox_.on_cancel = [this]() {
    SyncOmniboxWithActiveTab();
    ::SetFocus(hwnd_);          // 把鍵盤焦點交還給網頁內容
    FocusWebContent();
  };
  omnibox_.on_focus_changed = [this](bool) { ::InvalidateRect(hwnd_, nullptr, FALSE); };
  omnibox_.on_text_changed = [this](const std::wstring&) {
    ::InvalidateRect(hwnd_, nullptr, FALSE);
  };
  // 焦點在網址列時仍可使用的全域快速鍵 (與 Chrome 一致)
  omnibox_.on_pre_key = [this](UINT message, WPARAM wparam, LPARAM) -> bool {
    if (message != WM_KEYDOWN && message != WM_SYSKEYDOWN) return false;
    const bool ctrl = (::GetKeyState(VK_CONTROL) & 0x8000) != 0;
    const bool shift = (::GetKeyState(VK_SHIFT) & 0x8000) != 0;
    const bool alt = (::GetKeyState(VK_MENU) & 0x8000) != 0;
    return HandleShortcut((UINT)wparam, ctrl, shift, alt);
  };
  omnibox_.ApplyTheme(theme_, dpi_);

  menu_ = std::make_unique<PopupMenu>(hwnd_);
  bookmarks_bar_.SetItems(bookmarks_->items());

  ui_pages::EnsureDefaultPages(PortablePaths::UiDir());

  tabs_ = std::make_unique<TabManager>(this, config_, history_, bookmarks_);

  RecalcLayout();
  tabs_->Initialize();

  ::SetTimer(hwnd_, 4, 1000, nullptr);   // 看門狗：每秒一次
  ::ShowWindow(hwnd_, show_command);
  ::UpdateWindow(hwnd_);
  return true;
}

LRESULT CALLBACK MainWindow::WndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam) {
  MainWindow* self = reinterpret_cast<MainWindow*>(::GetWindowLongPtrW(hwnd, GWLP_USERDATA));
  if (message == WM_NCCREATE) {
    auto* create = reinterpret_cast<CREATESTRUCTW*>(lparam);
    self = reinterpret_cast<MainWindow*>(create->lpCreateParams);
    ::SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
    if (self) self->hwnd_ = hwnd;
  }
  if (self) return self->HandleMessage(message, wparam, lparam);
  return ::DefWindowProcW(hwnd, message, wparam, lparam);
}

LRESULT MainWindow::HandleMessage(UINT message, WPARAM wparam, LPARAM lparam) {
  switch (message) {
    // ---- 無邊框視窗 --------------------------------------------------
    case WM_NCCALCSIZE: {
#ifndef LUMEN_NATIVE_FRAME
      if (wparam == TRUE) {
        if (::IsZoomed(hwnd_)) {
          // 最大化時把 client 縮回工作區 (與 WM_GETMINMAXINFO 搭配)
          auto* params = reinterpret_cast<NCCALCSIZE_PARAMS*>(lparam);
          const int frame_x =
              ::GetSystemMetrics(SM_CXSIZEFRAME) + ::GetSystemMetrics(SM_CXPADDEDBORDER);
          const int frame_y =
              ::GetSystemMetrics(SM_CYSIZEFRAME) + ::GetSystemMetrics(SM_CXPADDEDBORDER);
          params->rgrc[0].left += frame_x;
          params->rgrc[0].right -= frame_x;
          params->rgrc[0].top += frame_y;
          params->rgrc[0].bottom -= frame_y;
        }
        return 0;
      }
#endif
      break;
    }

    case WM_GETMINMAXINFO: {
#ifndef LUMEN_NATIVE_FRAME
      auto* info = reinterpret_cast<MINMAXINFO*>(lparam);
      HMONITOR monitor = ::MonitorFromWindow(hwnd_, MONITOR_DEFAULTTONEAREST);
      MONITORINFO mi{};
      mi.cbSize = sizeof(mi);
      if (::GetMonitorInfoW(monitor, &mi)) {
        const int frame_x =
            ::GetSystemMetrics(SM_CXSIZEFRAME) + ::GetSystemMetrics(SM_CXPADDEDBORDER);
        const int frame_y =
            ::GetSystemMetrics(SM_CYSIZEFRAME) + ::GetSystemMetrics(SM_CXPADDEDBORDER);
        info->ptMaxPosition.x = mi.rcWork.left - mi.rcMonitor.left - frame_x;
        info->ptMaxPosition.y = mi.rcWork.top - mi.rcMonitor.top - frame_y;
        info->ptMaxSize.x = (mi.rcWork.right - mi.rcWork.left) + frame_x * 2;
        info->ptMaxSize.y = (mi.rcWork.bottom - mi.rcWork.top) + frame_y * 2;
      }
      info->ptMinTrackSize.x = ScaleDip(720, dpi_);
      info->ptMinTrackSize.y = ScaleDip(480, dpi_);
#endif
      return 0;
    }

    case WM_NCHITTEST: {
#ifndef LUMEN_NATIVE_FRAME
      POINT screen{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      RECT window_rect{};
      ::GetWindowRect(hwnd_, &window_rect);
      if (!::IsZoomed(hwnd_)) {
        const int border = ScaleDip(6, dpi_);
        const bool left = screen.x < window_rect.left + border;
        const bool right = screen.x >= window_rect.right - border;
        const bool top = screen.y < window_rect.top + border;
        const bool bottom = screen.y >= window_rect.bottom - border;
        if (top && left) return HTTOPLEFT;
        if (top && right) return HTTOPRIGHT;
        if (bottom && left) return HTBOTTOMLEFT;
        if (bottom && right) return HTBOTTOMRIGHT;
        if (left) return HTLEFT;
        if (right) return HTRIGHT;
        if (top) return HTTOP;
        if (bottom) return HTBOTTOM;
      }

      POINT client = screen;
      ::ScreenToClient(hwnd_, &client);
      const D2D1_POINT_2F dip = D2D1::Point2F((float)client.x / scale_, (float)client.y / scale_);

      if (PointInRect(layout_.btn_minimize, dip) || PointInRect(layout_.btn_maximize, dip) ||
          PointInRect(layout_.btn_close, dip)) {
        return HTCLIENT;
      }
      if (dip.y <= layout_.tab_strip.bottom) {
        int index = -1;
        const Hover hit = HitTestChrome(dip, &index);
        if (hit == Hover::Tab || hit == Hover::CloseTab || hit == Hover::NewTab) return HTCLIENT;
        if (hit == Hover::Caption) return HTCAPTION;
      }
      return HTCLIENT;
#else
      break;
#endif
    }

    case WM_ERASEBKGND:
      return 1;

    case WM_PAINT: {
      PAINTSTRUCT ps;
      ::BeginPaint(hwnd_, &ps);
      Paint();
      ::EndPaint(hwnd_, &ps);
      return 0;
    }

    case WM_SIZE: {
      const UINT width = LOWORD(lparam);
      const UINT height = HIWORD(lparam);
      if (target_ && width > 0 && height > 0) {
        target_->Resize(D2D1::SizeU(width, height));
      }
      RebuildTabStrip();
      RecalcLayout();
      ::InvalidateRect(hwnd_, nullptr, FALSE);
      return 0;
    }

    case WM_DPICHANGED: {
      dpi_ = HIWORD(wparam);
      scale_ = DpiScale(dpi_);
      const RECT* suggested = reinterpret_cast<const RECT*>(lparam);
      if (suggested) {
        ::SetWindowPos(hwnd_, nullptr, suggested->left, suggested->top,
                       suggested->right - suggested->left, suggested->bottom - suggested->top,
                       SWP_NOZORDER | SWP_NOACTIVATE);
      }
      omnibox_.ApplyTheme(theme_, dpi_);
      ReleaseRenderTarget();
      RecalcLayout();
      ::InvalidateRect(hwnd_, nullptr, FALSE);
      return 0;
    }

    // ---- 滑鼠 --------------------------------------------------------
    case WM_MOUSEMOVE: {
      POINT client{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      OnMouseMove(client, wparam);
      return 0;
    }

    case WM_MOUSELEAVE:
      OnMouseLeave();
      return 0;

    case WM_LBUTTONDOWN: {
      POINT client{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      OnLeftButtonDown(client);
      return 0;
    }

    case WM_LBUTTONUP: {
      POINT client{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      OnLeftButtonUp(client);
      return 0;
    }

    case WM_MBUTTONUP: {
      POINT client{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      const D2D1_POINT_2F dip = D2D1::Point2F((float)client.x / scale_, (float)client.y / scale_);
      int index = -1;
      if (HitTestChrome(dip, &index) == Hover::Tab && index >= 0) {
        CloseTab(index);   // 中鍵關閉分頁 (Chrome 行為)
      }
      return 0;
    }

    case WM_RBUTTONUP: {
      POINT client{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      OnRightButtonUp(client);
      return 0;
    }

    case WM_MOUSEWHEEL: {
      POINT client{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
      ::ScreenToClient(hwnd_, &client);
      OnMouseWheel(wparam, client);
      return 0;
    }

    // ---- 鍵盤 --------------------------------------------------------
    case WM_KEYDOWN:
    case WM_SYSKEYDOWN: {
      const bool ctrl = (::GetKeyState(VK_CONTROL) & 0x8000) != 0;
      const bool shift = (::GetKeyState(VK_SHIFT) & 0x8000) != 0;
      const bool alt = (::GetKeyState(VK_MENU) & 0x8000) != 0;
      if (HandleShortcut((UINT)wparam, ctrl, shift, alt)) return 0;
      ForwardKey(message == WM_SYSKEYDOWN ? WM_KEYDOWN : message, wparam, lparam);
      return 0;
    }

    case WM_KEYUP:
    case WM_SYSKEYUP:
      ForwardKey(WM_KEYUP, wparam, lparam);
      return 0;

    case WM_CHAR:
      ForwardKey(WM_CHAR, wparam, lparam);
      return 0;

    // ---- 子控制項 ----------------------------------------------------
    case WM_COMMAND: {
      if (HIWORD(wparam) == EN_CHANGE && (HWND)lparam == omnibox_.hwnd()) {
        if (omnibox_.on_text_changed) omnibox_.on_text_changed(omnibox_.GetText());
        return 0;
      }
      break;
    }

    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORSTATIC: {
      if ((HWND)lparam == omnibox_.hwnd()) {
        HDC dc = reinterpret_cast<HDC>(wparam);
        ::SetTextColor(dc, omnibox_.text_color());
        ::SetBkColor(dc, RGB((int)(theme_.omnibox.r * 255.0f), (int)(theme_.omnibox.g * 255.0f),
                             (int)(theme_.omnibox.b * 255.0f)));
        if (omnibox_.background_brush()) return (LRESULT)omnibox_.background_brush();
      }
      break;
    }

    case WM_SETFOCUS:
      if (!omnibox_.has_focus()) FocusWebContent();
      return 0;

    case WM_ACTIVATE:
      if (LOWORD(wparam) == WA_INACTIVE) {
        status_text_.clear();
      }
      return 0;

    // ---- 生命週期 ----------------------------------------------------
    case WM_CLOSE:
      BeginClose();
      return 0;

    case WM_DESTROY:
      ::KillTimer(hwnd_, 2);
      ::KillTimer(hwnd_, 4);
      if (target_) {
        target_->Release();
        target_ = nullptr;
      }
      ::PostQuitMessage(0);
      return 0;

    case WM_TIMER:
      if (wparam == 3) {
        ::KillTimer(hwnd_, 3);
        if (tabs_) tabs_->CloseAll(true);
        if (hwnd_) ::DestroyWindow(hwnd_);
        return 0;
      }
      if (wparam == 4) {
        // 每秒一次的健康檢查。三件事：
        //   1) 有沒有收到第一張畫面（沒有 -> 畫面管線卡住）
        //   2) 畫面是否已靜止超過 8 秒，卻還掛著「載入中」
        //      -> 這是「明明畫好了卻一直轉圈」的成因，直接清掉轉圈狀態
        //   3) 20 秒完全沒畫面 -> 主動踢一次 CEF 重畫
        Tab* watch_tab = tabs_ ? tabs_->ActiveTab() : nullptr;
        if (!watch_tab) return 0;

        if (watch_tab->has_frame()) {
          if (!saw_first_frame_) {
            saw_first_frame_ = true;
            DiagLog("watchdog: first frame after %d s", no_frame_ticks_);
            status_text_.clear();
            no_frame_ticks_ = 0;
            ::InvalidateRect(hwnd_, nullptr, FALSE);
          }
          if (watch_tab->frame_serial() != last_frame_serial_) {
            last_frame_serial_ = watch_tab->frame_serial();
            idle_ticks_ = 0;
          } else {
            ++idle_ticks_;
          }
          if (watch_tab->loading() && idle_ticks_ >= 8) {
            DiagLog("watchdog: page painted but still 'loading' with no new frame for 8 s "
                    "-> clearing spinner (url=%s)",
                    ToUtf8(watch_tab->url()).c_str());
            watch_tab->SetLoading(false);
            watch_tab->SetProgress(1.0);
            RebuildTabStrip();
            ::InvalidateRect(hwnd_, nullptr, FALSE);
            idle_ticks_ = 0;
          }
          return 0;
        }

        ++no_frame_ticks_;
        if (no_frame_ticks_ == 8) {
          DiagLog("watchdog: NO FRAME after 8 s (loading=%d url=%s)", watch_tab->loading() ? 1 : 0,
                  ToUtf8(watch_tab->url()).c_str());
        }
        if (no_frame_ticks_ == 20 && !no_frame_kicked_) {
          no_frame_kicked_ = true;
          DiagLog("watchdog: forcing WasResized + Invalidate at 20 s");
          if (watch_tab->HasBrowser()) {
            watch_tab->browser()->GetHost()->WasResized();
            watch_tab->browser()->GetHost()->Invalidate(PET_VIEW);
          }
        }
        if (no_frame_ticks_ >= 8) {
          status_text_ = L"已 " + std::to_wstring(no_frame_ticks_) +
                         L" 秒沒有收到畫面 ─ 請開啟 browser_data\\logs\\lumen.log";
          ::InvalidateRect(hwnd_, nullptr, FALSE);
        }
        return 0;
      }
      if (wparam == 2) {
        spinner_phase_ += 0.05f;
        if (spinner_phase_ > 1.0f) spinner_phase_ -= 1.0f;
        tab_strip_.SetSpinnerPhase(spinner_phase_);
        RECT tab_area = DipRectToPx(layout_.tab_strip, scale_);
        ::InvalidateRect(hwnd_, &tab_area, FALSE);
        return 0;
      }
      break;

    case kMsgAllTabsClosed:
      if (!::IsWindow(hwnd_)) return 0;
      shutting_down_ = true;
      ::DestroyWindow(hwnd_);
      return 0;

    default:
      break;
  }
  return ::DefWindowProcW(hwnd_, message, wparam, lparam);
}

// ---------------------------------------------------------------------------
//  佈局
// ---------------------------------------------------------------------------
void MainWindow::RecalcLayout() {
  RECT client{};
  ::GetClientRect(hwnd_, &client);
  const float width = (float)client.right / scale_;
  const float height = (float)client.bottom / scale_;

  layout_ = Layout{};

  layout_.tab_strip = D2D1::RectF(0.0f, 0.0f, width, kTabStripHeight);
  layout_.tab_area = D2D1::RectF(0.0f, 0.0f, std::max(0.0f, width - kCaptionButtonWidth * 3.0f),
                                 kTabStripHeight);
  layout_.btn_close = D2D1::RectF(width - kCaptionButtonWidth, 0.0f, width, kTabStripHeight);
  layout_.btn_maximize =
      D2D1::RectF(width - kCaptionButtonWidth * 2.0f, 0.0f, width - kCaptionButtonWidth,
                  kTabStripHeight);
  layout_.btn_minimize = D2D1::RectF(width - kCaptionButtonWidth * 3.0f, 0.0f,
                                     width - kCaptionButtonWidth * 2.0f, kTabStripHeight);

  layout_.toolbar =
      D2D1::RectF(0.0f, kTabStripHeight, width, kTabStripHeight + kToolbarHeight);

  const bool show_bookmarks = config_->show_bookmarks_bar;
  const float bookmarks_top = layout_.toolbar.bottom;
  layout_.bookmarks = show_bookmarks
                          ? D2D1::RectF(0.0f, bookmarks_top, width, bookmarks_top + kBookmarksHeight)
                          : D2D1::RectF(0.0f, bookmarks_top, width, bookmarks_top);
  layout_.content = D2D1::RectF(0.0f, layout_.bookmarks.bottom, width, std::max(height, layout_.bookmarks.bottom));

  // 導覽按鈕
  const float button_y =
      layout_.toolbar.top + (kToolbarHeight - kNavButtonSize) * 0.5f;
  float x = kLeftNavStart;
  layout_.back = D2D1::RectF(x, button_y, x + kNavButtonSize, button_y + kNavButtonSize);
  x += kNavButtonSize + 4.0f;
  layout_.forward = D2D1::RectF(x, button_y, x + kNavButtonSize, button_y + kNavButtonSize);
  x += kNavButtonSize + 4.0f;
  layout_.reload = D2D1::RectF(x, button_y, x + kNavButtonSize, button_y + kNavButtonSize);
  x += kNavButtonSize + 4.0f;
  layout_.home = D2D1::RectF(x, button_y, x + kNavButtonSize, button_y + kNavButtonSize);
  x += kNavButtonSize + 12.0f;

  const float pill_top = layout_.toolbar.top + (kToolbarHeight - kOmniboxHeight) * 0.5f;
  const float pill_bottom = pill_top + kOmniboxHeight;
  const float menu_left = width - 8.0f - kNavButtonSize;
  layout_.menu_button = D2D1::RectF(menu_left, button_y, menu_left + kNavButtonSize,
                                    button_y + kNavButtonSize);
  layout_.pill = D2D1::RectF(x, pill_top, menu_left - 8.0f, pill_bottom);
  if (layout_.pill.right < layout_.pill.left + 120.0f) {
    layout_.pill.right = layout_.pill.left + 120.0f;
  }
  layout_.lock = D2D1::RectF(layout_.pill.left + 10.0f, pill_top + 8.0f,
                             layout_.pill.left + 26.0f, pill_top + 24.0f);
  layout_.star = D2D1::RectF(layout_.pill.right - 30.0f, pill_top + 4.0f, layout_.pill.right - 6.0f,
                             pill_bottom - 4.0f);

  tab_strip_.Layout(layout_.tab_area);
  bookmarks_bar_.Layout(layout_.bookmarks);

  // 網址列的 EDIT 子視窗：左右各留給鎖頭與星號
  RECT edit_px = DipRectToPx(D2D1::RectF(layout_.pill.left + 30.0f, layout_.pill.top + 6.0f,
                                         layout_.star.left - 4.0f, layout_.pill.bottom - 6.0f),
                             scale_);
  omnibox_.SetBoundsPx(edit_px);

  // 同步給 CEF 的視圖尺寸 (實體像素)
  if (tabs_) {
    const int content_px_w = (int)std::lround((layout_.content.right - layout_.content.left) * scale_);
    const int content_px_h = (int)std::lround((layout_.content.bottom - layout_.content.top) * scale_);
    if (content_px_w > 0 && content_px_h > 0) {
      tabs_->SetContentSize(content_px_w, content_px_h, scale_);
    }
  }
}

void MainWindow::ApplyTheme() {
  theme_ = Theme::ForMode(config_->dark());
  SetDarkTitleBar(hwnd_, theme_.dark);
  omnibox_.ApplyTheme(theme_, dpi_);
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::RebuildTabStrip() {
  if (!tabs_) return;
  std::vector<TabVisual> visuals;
  visuals.reserve((size_t)tabs_->Count());
  for (int i = 0; i < tabs_->Count(); ++i) {
    Tab* tab = tabs_->TabAt(i);
    if (!tab) continue;
    TabVisual visual;
    visual.title = tab->title().empty() ? L"新分頁" : tab->title();
    visual.loading = tab->loading();
    visuals.push_back(std::move(visual));
  }
  tab_strip_.SetTabs(visuals, tabs_->ActiveIndex());

  // 載入動畫計時器
  bool any_loading = false;
  for (const auto& visual : visuals) {
    if (visual.loading) {
      any_loading = true;
      break;
    }
  }
  if (any_loading && !spinner_active_) {
    spinner_active_ = true;
    ::SetTimer(hwnd_, 2, 60, nullptr);
  } else if (!any_loading && spinner_active_) {
    spinner_active_ = false;
    ::KillTimer(hwnd_, 2);
  }
}

void MainWindow::SyncOmniboxWithActiveTab() {
  Tab* tab = tabs_ ? tabs_->ActiveTab() : nullptr;
  const std::wstring url = tab ? tab->url() : std::wstring();
  if (omnibox_.has_focus()) return;
  if (url == omnibox_display_url_) return;
  omnibox_display_url_ = url;
  omnibox_.SetText(url.empty() ? L"" : DisplayUrl(url), false);
}

bool MainWindow::ContentAreaContains(D2D1_POINT_2F dip) const {
  return PointInRect(layout_.content, dip);
}

// ---------------------------------------------------------------------------
//  BrowserUI 回呼
// ---------------------------------------------------------------------------
void MainWindow::OnTabFrameReady(Tab* tab) {
  if (!tabs_ || tab != tabs_->ActiveTab()) return;   // 背景分頁不需重繪
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::OnTabChanged(Tab* tab) {
  if (!tabs_) return;
  // 任何狀態變化都重新計時（切換分頁/開始載入時不該延續上一個分頁的計數）
  no_frame_ticks_ = 0;
  idle_ticks_ = 0;
  RebuildTabStrip();
  RecalcLayout();
  if (tab == tabs_->ActiveTab()) SyncOmniboxWithActiveTab();
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::OnTabCreated(Tab* tab) {
  RebuildTabStrip();
  // 看門狗：每秒檢查一次「到底有沒有收到畫面」。CEF 出問題時常常只表現成
  // 「一直轉圈」而沒有任何訊息，這裡把狀態直接寫在畫面上 + 寫進日誌。
  no_frame_ticks_ = 0;
  no_frame_kicked_ = false;
  if (hwnd_) ::SetTimer(hwnd_, 4, 1000, nullptr);
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::OnTabClosed(Tab* tab) {
  RebuildTabStrip();
  SyncOmniboxWithActiveTab();
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::OnAllTabsClosed() {
  // 不可在 CEF 回呼中直接 DestroyWindow，改為非同步處理
  if (hwnd_) ::PostMessageW(hwnd_, kMsgAllTabsClosed, 0, 0);
}

void MainWindow::OnCursorChanged(HCURSOR cursor) {
  custom_cursor_ = cursor;
}

void MainWindow::OnPopupRequest(Tab* source, const std::wstring& url, bool foreground) {
  NewTab(url, foreground);
}

void MainWindow::OnStatusMessage(Tab* tab, const std::wstring& message) {
  status_text_ = message;
  if (status_text_.size() > 160) status_text_ = status_text_.substr(0, 160) + L"…";
  RECT content = DipRectToPx(layout_.content, scale_);
  ::InvalidateRect(hwnd_, &content, FALSE);
}

void MainWindow::OnContextMenuRequested(Tab* tab, CefRefPtr<CefMenuModel> model,
                                        CefRefPtr<CefRunContextMenuCallback> callback) {
  if (!model || !callback || !menu_) return;

  std::vector<MenuItem> items;
  for (size_t i = 0; i < (size_t)model->GetCount(); ++i) {
    if (model->GetTypeAt((int)i) == MENUITEMTYPE_SEPARATOR) {
      items.push_back(MenuItem::Separator());
      continue;
    }
    MenuItem item;
    item.id = model->GetCommandIdAt((int)i);
    item.label = model->GetLabelAt((int)i).ToWString();
    item.enabled = model->IsEnabledAt((int)i);
    items.push_back(std::move(item));
  }
  // 額外加上 Lumen 自己的項目
  items.push_back(MenuItem::Separator());
  {
    MenuItem item;
    item.id = kCmdAddBookmark;
    item.label = L"加入書籤";
    items.push_back(item);
    MenuItem reload{};
    reload.id = kCmdShowHistory;
    reload.label = L"瀏覽紀錄";
    items.push_back(reload);
  }

  POINT cursor{};
  ::GetCursorPos(&cursor);
  const int chosen = menu_->Track(cursor, items, theme_);
  if (chosen == 0) {
    callback->Cancel();
    return;
  }
  if (chosen >= kCmdNewTab && chosen <= kCmdExit) {
    callback->Cancel();
    OnMenuCommand(chosen);
    return;
  }
  // 交回 CEF 執行標準編輯命令
  callback->Continue(chosen, EVENTFLAG_NONE);
}

// ---------------------------------------------------------------------------
//  繪製
// ---------------------------------------------------------------------------
void MainWindow::EnsureRenderTarget() {
  RECT client{};
  ::GetClientRect(hwnd_, &client);
  if (client.right <= 0 || client.bottom <= 0) return;

  if (!target_) {
    ID2D1Factory* factory = Gfx::Get().d2d();
    if (!factory) return;
    const D2D1_RENDER_TARGET_PROPERTIES props = D2D1::RenderTargetProperties();
    const D2D1_HWND_RENDER_TARGET_PROPERTIES hwnd_props = D2D1::HwndRenderTargetProperties(
        hwnd_, D2D1::SizeU((UINT32)client.right, (UINT32)client.bottom),
        D2D1_PRESENT_OPTIONS_IMMEDIATELY);
    if (FAILED(factory->CreateHwndRenderTarget(props, hwnd_props, &target_)) || !target_) {
      target_ = nullptr;
      return;
    }
  }
  target_->SetDpi((float)dpi_, (float)dpi_);
}

void MainWindow::ReleaseRenderTarget() {
  if (web_bitmap_) {
    web_bitmap_->Release();
    web_bitmap_ = nullptr;
  }
  if (popup_bitmap_) {
    popup_bitmap_->Release();
    popup_bitmap_ = nullptr;
  }
  web_bitmap_width_ = web_bitmap_height_ = 0;
  popup_bitmap_width_ = popup_bitmap_height_ = 0;
  if (target_) {
    target_->Release();
    target_ = nullptr;
  }
}

void MainWindow::Paint() {
  EnsureRenderTarget();
  if (!target_) return;

  target_->BeginDraw();
  target_->SetTransform(D2D1::Matrix3x2F::Identity());
  target_->Clear(theme_.frame_background);

  PaintChrome(target_);
  PaintContent(target_);

  // 狀態列 (左下角氣泡)
  if (!status_text_.empty()) {
    const D2D1_RECT_F content = layout_.content;
    const float text_width = MeasureText(status_text_, FontRole::Small);
    const float bubble_width = std::min(text_width + 20.0f, content.right - content.left - 24.0f);
    const D2D1_RECT_F bubble = D2D1::RectF(content.left + 10.0f, content.bottom - 30.0f,
                                           content.left + 10.0f + bubble_width,
                                           content.bottom - 8.0f);
    FillRoundedRect(target_, bubble, 6.0f, D2D1::ColorF(0x202124, 0.92f));
    DrawTextClipped(target_, status_text_, FontRole::Small,
                    D2D1::RectF(bubble.left + 10.0f, bubble.top, bubble.right - 10.0f,
                                bubble.bottom),
                    D2D1::ColorF(0xF1F3F4), DWRITE_TEXT_ALIGNMENT_LEADING,
                    DWRITE_PARAGRAPH_ALIGNMENT_CENTER, true);
  }

  const HRESULT hr = target_->EndDraw();
  if (hr == D2DERR_RECREATE_TARGET) ReleaseRenderTarget();
}

void MainWindow::PaintToolbarButton(ID2D1RenderTarget* rt, const D2D1_RECT_F& rect, Icon icon,
                                    bool hovered, bool enabled) const {
  if (hovered && enabled) {
    FillRoundedRect(rt, rect, kNavButtonSize * 0.5f, theme_.button_hover);
  }
  const D2D1_COLOR_F color = enabled ? theme_.icon : theme_.text_disabled;
  const D2D1_RECT_F icon_box = D2D1::RectF(rect.left + 8.0f, rect.top + 8.0f, rect.right - 8.0f,
                                           rect.bottom - 8.0f);
  DrawIcon(rt, icon, icon_box, color, 1.7f);
}

void MainWindow::PaintCaptionButtons(ID2D1RenderTarget* rt) const {
#ifndef LUMEN_NATIVE_FRAME
  const Hover hits[3] = {Hover::Minimize, Hover::Maximize, Hover::Close};
  const D2D1_RECT_F rects[3] = {layout_.btn_minimize, layout_.btn_maximize, layout_.btn_close};
  const Icon icons[3] = {Icon::Minimize, ::IsZoomed(hwnd_) ? Icon::Restore : Icon::Maximize,
                         Icon::Close};

  for (int i = 0; i < 3; ++i) {
    const bool hovered = (hover_ == hits[i]);
    if (hovered) {
      const D2D1_COLOR_F background =
          (hits[i] == Hover::Close) ? theme_.caption_close_hover : theme_.caption_hover;
      FillRect(rt, rects[i], background);
    }
    const D2D1_COLOR_F color =
        (hovered && hits[i] == Hover::Close) ? D2D1::ColorF(0xFFFFFF) : theme_.icon;
    const D2D1_RECT_F box = D2D1::RectF(rects[i].left + 15.0f, rects[i].top + 12.0f,
                                        rects[i].right - 15.0f, rects[i].bottom - 12.0f);
    DrawIcon(rt, icons[i], box, color, 1.2f);
  }
#endif
}

void MainWindow::PaintChrome(ID2D1RenderTarget* rt) {
  // 分頁列底色
  FillRect(rt, layout_.tab_strip, theme_.frame_background);
  tab_strip_.Paint(rt, theme_);
  PaintCaptionButtons(rt);

  // 工具列
  FillRect(rt, layout_.toolbar, theme_.toolbar);
  DrawLine(rt, D2D1::Point2F(0.0f, layout_.toolbar.top),
           D2D1::Point2F(layout_.tab_strip.right, layout_.toolbar.top), theme_.toolbar_separator,
           1.0f);

  Tab* active = tabs_ ? tabs_->ActiveTab() : nullptr;
  const bool has_tab = active != nullptr;

  PaintToolbarButton(rt, layout_.back, Icon::Back, hover_ == Hover::Back,
                     has_tab && active->can_go_back());
  PaintToolbarButton(rt, layout_.forward, Icon::Forward, hover_ == Hover::Forward,
                     has_tab && active->can_go_forward());
  PaintToolbarButton(rt, layout_.reload, Icon::Reload, hover_ == Hover::Reload, has_tab);
  PaintToolbarButton(rt, layout_.home, Icon::Home, hover_ == Hover::Home, true);
  PaintToolbarButton(rt, layout_.menu_button, Icon::MenuDots, hover_ == Hover::MenuButton, true);

  // 網址列膠囊
  const bool focused = omnibox_.has_focus();
  // 注意：這裡的填色必須與 Omnibox (原生 EDIT) 的背景色完全一致，
  // 否則疊在上面的 EDIT 子視窗會露出一塊色差。因此 hover/聚焦只改邊框。
  FillRoundedRect(rt, layout_.pill, kOmniboxHeight * 0.5f, theme_.omnibox);
  StrokeRoundedRect(rt, layout_.pill, kOmniboxHeight * 0.5f,
                    focused ? theme_.accent : theme_.omnibox_border, focused ? 2.0f : 1.0f);

  // 安全指示燈
  if (has_tab) {
    const std::wstring url = active->url();
    const bool secure = IsHttpsUrl(url);
    const bool internal = IsInternalUrl(url);
    DrawIcon(rt, secure || internal ? Icon::Lock : Icon::Globe, layout_.lock,
             secure ? theme_.text_secondary : theme_.text_secondary, 1.4f);
  }

  // 書籤星號
  if (has_tab) {
    const bool starred = bookmarks_->Contains(active->url());
    if (hover_ == Hover::Star) {
      FillRoundedRect(rt, D2D1::RectF(layout_.star.left - 1.0f, layout_.star.top - 1.0f,
                                      layout_.star.right + 1.0f, layout_.star.bottom + 1.0f),
                      5.0f, theme_.button_hover);
    }
    DrawIcon(rt, starred ? Icon::StarFilled : Icon::Star, layout_.star,
             starred ? theme_.accent : theme_.icon, 1.4f);
  }

  // 書籤列
  if (config_->show_bookmarks_bar) {
    FillRect(rt, layout_.bookmarks, theme_.toolbar);
    bookmarks_bar_.Paint(rt, theme_);
  }
}

void MainWindow::PaintContent(ID2D1RenderTarget* rt) {
  FillRect(rt, layout_.content, theme_.web_backdrop);

  Tab* tab = tabs_ ? tabs_->ActiveTab() : nullptr;
  if (!tab || !tab->has_frame() || !tab->frame_data()) return;

  const int frame_w = tab->frame_width();
  const int frame_h = tab->frame_height();
  if (frame_w <= 0 || frame_h <= 0) return;

  if (!web_bitmap_ || web_bitmap_width_ != frame_w || web_bitmap_height_ != frame_h) {
    if (web_bitmap_) {
      web_bitmap_->Release();
      web_bitmap_ = nullptr;
    }
    const D2D1_BITMAP_PROPERTIES props = D2D1::BitmapProperties(
        D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED), 96.0f, 96.0f);
    if (FAILED(target_->CreateBitmap(D2D1::SizeU((UINT32)frame_w, (UINT32)frame_h), nullptr, 0,
                                     props, &web_bitmap_)) ||
        !web_bitmap_) {
      web_bitmap_ = nullptr;
      return;
    }
    web_bitmap_width_ = frame_w;
    web_bitmap_height_ = frame_h;
  }

  const UINT32 pitch = (UINT32)frame_w * 4u;
  web_bitmap_->CopyFromMemory(nullptr, tab->frame_data(), pitch);
  rt->DrawBitmap(web_bitmap_, layout_.content, 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);

  // <select> 等下拉選單 (OSR 的 popup layer)
  if (tab->popup_visible() && tab->has_popup_frame()) {
    const int popup_w = tab->popup_width();
    const int popup_h = tab->popup_height();
    if (!popup_bitmap_ || popup_bitmap_width_ != popup_w || popup_bitmap_height_ != popup_h) {
      if (popup_bitmap_) {
        popup_bitmap_->Release();
        popup_bitmap_ = nullptr;
      }
      const D2D1_BITMAP_PROPERTIES props = D2D1::BitmapProperties(
          D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED), 96.0f,
          96.0f);
      if (SUCCEEDED(target_->CreateBitmap(D2D1::SizeU((UINT32)popup_w, (UINT32)popup_h), nullptr, 0,
                                          props, &popup_bitmap_)) &&
          popup_bitmap_) {
        popup_bitmap_width_ = popup_w;
        popup_bitmap_height_ = popup_h;
      }
    }
    if (popup_bitmap_) {
      popup_bitmap_->CopyFromMemory(nullptr, tab->popup_data(), (UINT32)popup_w * 4u);
      const D2D1_RECT_F dest =
          D2D1::RectF(layout_.content.left + (float)tab->popup_x() / scale_,
                      layout_.content.top + (float)tab->popup_y() / scale_,
                      layout_.content.left + (float)(tab->popup_x() + popup_w) / scale_,
                      layout_.content.top + (float)(tab->popup_y() + popup_h) / scale_);
      rt->DrawBitmap(popup_bitmap_, dest, 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);
    }
  }
}

// ---------------------------------------------------------------------------
//  互動
// ---------------------------------------------------------------------------
MainWindow::Hover MainWindow::HitTestChrome(D2D1_POINT_2F dip, int* out_index) const {
  if (out_index) *out_index = -1;

  if (PointInRect(layout_.btn_close, dip)) return Hover::Close;
  if (PointInRect(layout_.btn_maximize, dip)) return Hover::Maximize;
  if (PointInRect(layout_.btn_minimize, dip)) return Hover::Minimize;

  if (dip.y <= layout_.tab_strip.bottom) {
    const TabStrip::Hit hit = tab_strip_.HitTest(dip);
    if (hit.part == TabStrip::Part::CloseTab) {
      if (out_index) *out_index = hit.index;
      return Hover::CloseTab;
    }
    if (hit.part == TabStrip::Part::Tab) {
      if (out_index) *out_index = hit.index;
      return Hover::Tab;
    }
    if (hit.part == TabStrip::Part::NewTab) return Hover::NewTab;
    return Hover::Caption;
  }

  if (PointInRect(layout_.back, dip)) return Hover::Back;
  if (PointInRect(layout_.forward, dip)) return Hover::Forward;
  if (PointInRect(layout_.reload, dip)) return Hover::Reload;
  if (PointInRect(layout_.home, dip)) return Hover::Home;
  if (PointInRect(layout_.menu_button, dip)) return Hover::MenuButton;
  if (PointInRect(layout_.star, dip)) return Hover::Star;
  if (PointInRect(layout_.pill, dip)) return Hover::WebContent;   // 由 EDIT 子視窗處理

  if (config_->show_bookmarks_bar) {
    const int index = bookmarks_bar_.HitTest(dip);
    if (index >= 0) {
      if (out_index) *out_index = index;
      return Hover::Bookmark;
    }
  }

  if (ContentAreaContains(dip)) return Hover::WebContent;
  return Hover::None;
}

void MainWindow::OnMouseMove(POINT client_px, WPARAM flags) {
  last_mouse_px_ = client_px;
  mouse_dip_ = D2D1::Point2F((float)client_px.x / scale_, (float)client_px.y / scale_);

  if (!tracking_leave_) {
    TRACKMOUSEEVENT track{};
    track.cbSize = sizeof(track);
    track.dwFlags = TME_LEAVE;
    track.hwndTrack = hwnd_;
    ::TrackMouseEvent(&track);
    tracking_leave_ = true;
  }

  int index = -1;
  const Hover hit = HitTestChrome(mouse_dip_, &index);

  // 更新 hover 狀態
  if (hit != hover_ || index != hover_index_) {
    hover_ = hit;
    hover_index_ = index;
    int tab_hover = -1;
    int close_hover = -1;
    if (hit == Hover::Tab) tab_hover = index;
    if (hit == Hover::CloseTab) {
      tab_hover = index;
      close_hover = index;
    }
    if (hit == Hover::NewTab) tab_hover = -2;   // 讓 + 按鈕顯示 hover 底色
    tab_strip_.SetHover(tab_hover, close_hover);
    bookmarks_bar_.SetHover(hit == Hover::Bookmark ? index : -1);
    ::InvalidateRect(hwnd_, nullptr, FALSE);
  }

  const bool in_content = (hit == Hover::WebContent) && ContentAreaContains(mouse_dip_);
  if (in_content) {
    ::SetCursor(custom_cursor_ ? custom_cursor_ : ::LoadCursorW(nullptr, IDC_ARROW));
    ForwardMouseMove(client_px, CefBrowserHost::MouseButtonType::MBT_LEFT);
  } else {
    mouse_in_content_ = false;
    ::SetCursor(::LoadCursorW(nullptr, IDC_ARROW));
  }
  mouse_in_content_ = in_content;
  (void)flags;
}

void MainWindow::OnMouseLeave() {
  tracking_leave_ = false;
  hover_ = Hover::None;
  hover_index_ = -1;
  tab_strip_.SetHover(-1, -1);
  bookmarks_bar_.SetHover(-1);
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::OnLeftButtonDown(POINT client_px) {
  const D2D1_POINT_2F dip =
      D2D1::Point2F((float)client_px.x / scale_, (float)client_px.y / scale_);
  int index = -1;
  const Hover hit = HitTestChrome(dip, &index);

  switch (hit) {
    case Hover::Minimize:
      ::SendMessageW(hwnd_, WM_SYSCOMMAND, SC_MINIMIZE, 0);
      return;
    case Hover::Maximize:
      ToggleMaximize();
      return;
    case Hover::Close:
      ::PostMessageW(hwnd_, WM_CLOSE, 0, 0);
      return;
    case Hover::NewTab:
      NewTab();
      return;
    case Hover::CloseTab:
      CloseTab(index);
      return;
    case Hover::Tab:
      ActivateTab(index);
      return;
    case Hover::Back:
      if (tabs_) tabs_->GoBack();
      return;
    case Hover::Forward:
      if (tabs_) tabs_->GoForward();
      return;
    case Hover::Reload:
      if (tabs_) tabs_->Reload(false);
      return;
    case Hover::Home:
      GoHome();
      return;
    case Hover::Star:
      ToggleBookmark();
      return;
    case Hover::MenuButton:
      ShowMainMenu();
      return;
    case Hover::Bookmark: {
      const auto& items = bookmarks_->items();
      if (index >= 0 && index < (int)items.size()) {
        NewTab(items[(size_t)index].url, true);
      }
      return;
    }
    case Hover::WebContent: {
      if (!ContentAreaContains(dip)) return;   // 點在網址列膠囊上
      ::SetFocus(hwnd_);
      FocusWebContent();

      static DWORD last_time = 0;
      static POINT last_point{0, 0};
      const DWORD now = ::GetMessageTime();
      const bool same_place = (std::abs(client_px.x - last_point.x) < 4 &&
                               std::abs(client_px.y - last_point.y) < 4);
      int click_count = 1;
      if (same_place && (now - last_time) < (DWORD)::GetDoubleClickTime()) {
        click_count = 2;
      }
      last_time = now;
      last_point = client_px;

      ForwardMouseButton(client_px, CefBrowserHost::MouseButtonType::MBT_LEFT, false, click_count);
      return;
    }
    default:
      return;
  }
}

void MainWindow::OnLeftButtonUp(POINT client_px) {
  const D2D1_POINT_2F dip =
      D2D1::Point2F((float)client_px.x / scale_, (float)client_px.y / scale_);
  if (!ContentAreaContains(dip)) return;
  ForwardMouseButton(client_px, CefBrowserHost::MouseButtonType::MBT_LEFT, true, 1);
}

void MainWindow::OnRightButtonUp(POINT client_px) {
  const D2D1_POINT_2F dip =
      D2D1::Point2F((float)client_px.x / scale_, (float)client_px.y / scale_);
  int index = -1;
  const Hover hit = HitTestChrome(dip, &index);
  if (hit == Hover::Bookmark) {
    ShowBookmarkMenu(index);
    return;
  }
  if (hit != Hover::WebContent || !ContentAreaContains(dip)) return;

  // 讓 CEF 產生右鍵事件 → OnBeforeContextMenu → 我們的深色選單
  ForwardMouseButton(client_px, CefBrowserHost::MouseButtonType::MBT_RIGHT, false, 1);
  ForwardMouseButton(client_px, CefBrowserHost::MouseButtonType::MBT_RIGHT, true, 1);
}

void MainWindow::OnMouseWheel(WPARAM wparam, POINT client_px) {
  const D2D1_POINT_2F dip =
      D2D1::Point2F((float)client_px.x / scale_, (float)client_px.y / scale_);
  if (!ContentAreaContains(dip)) return;
  Tab* tab = tabs_ ? tabs_->ActiveTab() : nullptr;
  if (!tab || !tab->HasBrowser()) return;

  const D2D1_POINT_2F view = ClientPxToViewDip(client_px);
  int delta = GET_WHEEL_DELTA_WPARAM(wparam);
  if (::GetKeyState(VK_CONTROL) & 0x8000) {
    // Ctrl + 滾輪 = 縮放 (Chrome 行為)
    if (tabs_) tabs_->ZoomStep(delta > 0 ? 0.5 : -0.5);
    return;
  }
  CefMouseEvent event;
  event.x = (int)view.x;
  event.y = (int)view.y;
  event.modifiers = CurrentCefModifiers();
  tab->browser()->GetHost()->SendMouseWheelEvent(event, 0, delta);
}

int MainWindow::CurrentCefModifiers() const {
  int modifiers = 0;
  if (::GetKeyState(VK_SHIFT) & 0x8000) modifiers |= EVENTFLAG_SHIFT_DOWN;
  if (::GetKeyState(VK_CONTROL) & 0x8000) modifiers |= EVENTFLAG_CONTROL_DOWN;
  if (::GetKeyState(VK_MENU) & 0x8000) modifiers |= EVENTFLAG_ALT_DOWN;
  if (::GetKeyState(VK_LBUTTON) & 0x8000) modifiers |= EVENTFLAG_LEFT_MOUSE_BUTTON;
  if (::GetKeyState(VK_MBUTTON) & 0x8000) modifiers |= EVENTFLAG_MIDDLE_MOUSE_BUTTON;
  if (::GetKeyState(VK_RBUTTON) & 0x8000) modifiers |= EVENTFLAG_RIGHT_MOUSE_BUTTON;
  return modifiers;
}

D2D1_POINT_2F MainWindow::ClientPxToViewDip(POINT client_px) const {
  const RECT content_px = DipRectToPx(layout_.content, scale_);
  const float x = (float)(client_px.x - content_px.left) / scale_;
  const float y = (float)(client_px.y - content_px.top) / scale_;
  return D2D1::Point2F(std::max(0.0f, x), std::max(0.0f, y));
}

void MainWindow::ForwardMouseMove(POINT client_px, CefBrowserHost::MouseButtonType button) {
  Tab* tab = tabs_ ? tabs_->ActiveTab() : nullptr;
  if (!tab || !tab->HasBrowser()) return;
  const D2D1_POINT_2F view = ClientPxToViewDip(client_px);
  CefMouseEvent event;
  event.x = (int)view.x;
  event.y = (int)view.y;
  event.modifiers = CurrentCefModifiers();
  if (button == CefBrowserHost::MouseButtonType::MBT_RIGHT) {
    // 已在 modifiers 內
  }
  tab->browser()->GetHost()->SendMouseMoveEvent(event, false);
}

void MainWindow::ForwardMouseButton(POINT client_px, CefBrowserHost::MouseButtonType button,
                                    bool up, int click_count) {
  Tab* tab = tabs_ ? tabs_->ActiveTab() : nullptr;
  if (!tab || !tab->HasBrowser()) return;
  const D2D1_POINT_2F view = ClientPxToViewDip(client_px);
  CefMouseEvent event;
  event.x = (int)view.x;
  event.y = (int)view.y;
  event.modifiers = CurrentCefModifiers();
  tab->browser()->GetHost()->SendMouseClickEvent(event, button, up, click_count);
}

void MainWindow::ForwardKey(UINT message, WPARAM wparam, LPARAM lparam) {
  Tab* tab = tabs_ ? tabs_->ActiveTab() : nullptr;
  if (!tab || !tab->HasBrowser()) return;

  CefKeyEvent event;
  event.modifiers = CurrentCefModifiers();
  event.windows_key_code = (int)wparam;
  event.native_key_code = (int)lparam;
  event.is_system_key = 0;

  if (message == WM_KEYDOWN) {
    event.type = KEYEVENT_RAWKEYDOWN;
  } else if (message == WM_KEYUP) {
    event.type = KEYEVENT_KEYUP;
  } else {
    event.type = KEYEVENT_CHAR;
    event.character = static_cast<char16_t>(wparam);
    event.unmodified_character = static_cast<char16_t>(wparam);
  }
  tab->browser()->GetHost()->SendKeyEvent(event);
}

bool MainWindow::FocusWebContent() {
  Tab* tab = tabs_ ? tabs_->ActiveTab() : nullptr;
  if (!tab || !tab->HasBrowser()) return false;
  tab->browser()->GetHost()->SetFocus(true);
  return true;
}

bool MainWindow::HandleShortcut(UINT key, bool ctrl, bool shift, bool alt) {
  if (ctrl && !alt) {
    switch (key) {
      case 'T': NewTab(); return true;
      case 'W': if (tabs_) CloseTab(tabs_->ActiveIndex()); return true;
      case 'L': omnibox_.FocusAndSelectAll(); return true;
      case 'R': if (tabs_) tabs_->Reload(shift); return true;
      case 'D': ToggleBookmark(); return true;
      case 'B':
        if (shift) {
          ToggleBookmarksBar();
          return true;
        }
        return false;
      case 'H': ShowHistory(); return true;
      case 'J': OpenFolder(PortablePaths::DownloadsDir()); return true;
      case VK_TAB: {
        if (!tabs_ || tabs_->Count() < 2) return true;
        const int count = tabs_->Count();
        const int next = (tabs_->ActiveIndex() + (shift ? count - 1 : 1)) % count;
        ActivateTab(next);
        return true;
      }
      case VK_OEM_PLUS:
      case VK_ADD: if (tabs_) tabs_->ZoomStep(0.5); return true;
      case VK_OEM_MINUS:
      case VK_SUBTRACT: if (tabs_) tabs_->ZoomStep(-0.5); return true;
      case '0': if (tabs_) tabs_->ResetZoom(); return true;
      default: break;
    }
    if (key >= '1' && key <= '8') {
      ActivateTab((int)(key - '1'));
      return true;
    }
    if (key == '9') {
      if (tabs_) ActivateTab(tabs_->Count() - 1);
      return true;
    }
    return false;
  }

  if (alt) {
    if (key == VK_LEFT) {
      if (tabs_) tabs_->GoBack();
      return true;
    }
    if (key == VK_RIGHT) {
      if (tabs_) tabs_->GoForward();
      return true;
    }
    if (key == VK_HOME) {
      GoHome();
      return true;
    }
    return false;
  }

  if (key == VK_F5) {
    if (tabs_) tabs_->Reload(shift);
    return true;
  }
  if (key == VK_F11) {
    ToggleMaximize();
    return true;
  }
  if (key == VK_BROWSER_BACK) {
    if (tabs_) tabs_->GoBack();
    return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
//  動作
// ---------------------------------------------------------------------------
void MainWindow::NewTab(const std::wstring& url, bool foreground) {
  if (!tabs_) return;
  std::wstring target = url;
  if (target.empty()) {
    target = FileUrlFromPath(JoinPath(PortablePaths::UiDir(), L"newtab.html"));
  }
  tabs_->CreateTab(target, foreground);
  if (foreground) {
    omnibox_.FocusAndSelectAll();
    omnibox_.SetText(L"", false);
  }
  RebuildTabStrip();
  RecalcLayout();
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::CloseTab(int index) {
  if (tabs_) tabs_->CloseTab(index);
}

void MainWindow::ActivateTab(int index) {
  if (!tabs_) return;
  tabs_->ActivateTab(index);
  RebuildTabStrip();
  SyncOmniboxWithActiveTab();
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::NavigateFromOmnibox() {
  const std::wstring input = omnibox_.GetText();
  if (input.empty()) return;
  const std::wstring url = ResolveUserInput(input, config_->search_url);
  if (tabs_ && tabs_->ActiveTab()) {
    tabs_->LoadUrl(url);
  } else {
    NewTab(url, true);
  }
  omnibox_display_url_.clear();
  ::SetFocus(hwnd_);
  FocusWebContent();
}

void MainWindow::GoHome() {
  if (!tabs_) return;
  if (tabs_->ActiveTab()) {
    tabs_->LoadUrl(config_->homepage);
  } else {
    NewTab(config_->homepage, true);
  }
}

void MainWindow::ToggleBookmark() {
  Tab* tab = tabs_ ? tabs_->ActiveTab() : nullptr;
  if (!tab || tab->url().empty()) return;
  bookmarks_->Toggle(tab->title(), tab->url());
  bookmarks_bar_.SetItems(bookmarks_->items());
  RecalcLayout();
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::ToggleTheme() {
  config_->theme_mode = config_->dark() ? L"light" : L"dark";
  config_->Save(PortablePaths::ConfigFile(L"settings.json"));
  ApplyTheme();
}

void MainWindow::ToggleBookmarksBar() {
  config_->show_bookmarks_bar = !config_->show_bookmarks_bar;
  config_->Save(PortablePaths::ConfigFile(L"settings.json"));
  RecalcLayout();
  ::InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::ShowMainMenu() {
  if (!menu_) return;

  std::vector<MenuItem> items;
  auto add = [&items](int id, const wchar_t* label, const wchar_t* shortcut = L"") {
    MenuItem item;
    item.id = id;
    item.label = label;
    item.shortcut = shortcut;
    items.push_back(std::move(item));
  };

  add(kCmdNewTab, L"新增分頁", L"Ctrl+T");
  add(kCmdCloseTab, L"關閉分頁", L"Ctrl+W");
  items.push_back(MenuItem::Separator());
  add(kCmdAddBookmark, L"加入書籤", L"Ctrl+D");
  add(kCmdShowBookmarks, L"書籤管理員");
  add(kCmdShowHistory, L"瀏覽紀錄", L"Ctrl+H");
  add(kCmdShowDownloads, L"下載項目", L"Ctrl+J");
  items.push_back(MenuItem::Separator());
  add(kCmdZoomIn, L"放大", L"Ctrl++");
  add(kCmdZoomOut, L"縮小", L"Ctrl+-");
  add(kCmdZoomReset, L"重設縮放", L"Ctrl+0");
  add(kCmdPrint, L"列印…", L"Ctrl+P");
  items.push_back(MenuItem::Separator());
  {
    MenuItem theme_item;
    theme_item.id = kCmdToggleTheme;
    theme_item.label = config_->dark() ? L"切換為淺色模式" : L"切換為深色模式";
    items.push_back(theme_item);
    MenuItem bar_item;
    bar_item.id = kCmdToggleBookmarksBar;
    bar_item.label = config_->show_bookmarks_bar ? L"隱藏書籤列" : L"顯示書籤列";
    items.push_back(bar_item);
  }
  add(kCmdOpenDataFolder, L"開啟資料夾 (可攜資料)");
  items.push_back(MenuItem::Separator());
  add(kCmdAbout, L"關於 Lumen");
  add(kCmdExit, L"結束", L"Alt+F4");

  RECT menu_px = DipRectToPx(layout_.menu_button, scale_);
  POINT screen{menu_px.left, menu_px.bottom + 4};
  ::ClientToScreen(hwnd_, &screen);

  const int chosen = menu_->Track(screen, items, theme_);
  if (chosen) OnMenuCommand(chosen);
}

void MainWindow::ShowBookmarkMenu(int index) {
  const auto& items = bookmarks_->items();
  if (index < 0 || index >= (int)items.size()) return;

  std::vector<MenuItem> menu_items;
  MenuItem open_item;
  open_item.id = 1;
  open_item.label = L"在新分頁開啟";
  menu_items.push_back(open_item);
  MenuItem remove_item;
  remove_item.id = 2;
  remove_item.label = L"移除書籤";
  menu_items.push_back(remove_item);

  POINT cursor{};
  ::GetCursorPos(&cursor);
  const int chosen = menu_->Track(cursor, menu_items, theme_);
  if (chosen == 1) {
    NewTab(items[(size_t)index].url, true);
  } else if (chosen == 2) {
    bookmarks_->RemoveAt((size_t)index);
    bookmarks_bar_.SetItems(bookmarks_->items());
    RecalcLayout();
    ::InvalidateRect(hwnd_, nullptr, FALSE);
  }
}

void MainWindow::OnMenuCommand(int command_id) {
  switch (command_id) {
    case kCmdNewTab: NewTab(); break;
    case kCmdCloseTab: if (tabs_) CloseTab(tabs_->ActiveIndex()); break;
    case kCmdAddBookmark: ToggleBookmark(); break;
    case kCmdShowBookmarks: ShowBookmarks(); break;
    case kCmdShowHistory: ShowHistory(); break;
    case kCmdShowDownloads: OpenFolder(PortablePaths::DownloadsDir()); break;
    case kCmdZoomIn: if (tabs_) tabs_->ZoomStep(0.5); break;
    case kCmdZoomOut: if (tabs_) tabs_->ZoomStep(-0.5); break;
    case kCmdZoomReset: if (tabs_) tabs_->ResetZoom(); break;
    case kCmdPrint: if (tabs_) tabs_->PrintActive(); break;
    case kCmdToggleTheme: ToggleTheme(); break;
    case kCmdToggleBookmarksBar: ToggleBookmarksBar(); break;
    case kCmdOpenDataFolder: OpenFolder(PortablePaths::DataDir()); break;
    case kCmdAbout: ShowAbout(); break;
    case kCmdExit:
      ::PostMessageW(hwnd_, WM_CLOSE, 0, 0);
      break;
    default:
      break;
  }
}

void MainWindow::OpenInternalPage(const std::wstring& file_path) {
  if (file_path.empty()) return;
  NewTab(FileUrlFromPath(file_path), true);
}

void MainWindow::ShowHistory() {
  const std::wstring path =
      ui_pages::WriteHistoryPage(PortablePaths::UiDir(), history_->entries());
  OpenInternalPage(path);
}

void MainWindow::ShowBookmarks() {
  const std::wstring path =
      ui_pages::WriteBookmarksPage(PortablePaths::UiDir(), bookmarks_->items());
  OpenInternalPage(path);
}

void MainWindow::OpenFolder(const std::wstring& path) {
  EnsureDirectory(path);
  ::ShellExecuteW(hwnd_, L"open", path.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

void MainWindow::ShowAbout() {
  std::wstring message;
  message += L"Lumen Browser ";
  message += kAppVersion;
  message += L"\n\n";
  message += L"外殼：C++ / Win32 / Direct2D / DirectWrite (完全自研)\n";
  message += L"渲染核心：CEF (Chromium) — 完整 HTML5 / CSS3 / JavaScript / WebGL\n\n";
  message += L"可攜資料目錄：\n";
  message += PortablePaths::DataDir();
  message += L"\n\n（所有快取、Cookie、設定、歷史都只存在這個資料夾內）";
  ::MessageBoxW(hwnd_, message.c_str(), L"關於 Lumen", MB_ICONINFORMATION | MB_OK);
}

void MainWindow::ToggleMaximize() {
  if (::IsZoomed(hwnd_)) {
    ::ShowWindow(hwnd_, SW_RESTORE);
  } else {
    ::ShowWindow(hwnd_, SW_MAXIMIZE);
  }
  InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::SaveWindowState() {
  if (!config_ || !hwnd_) return;
  WINDOWPLACEMENT placement{};
  placement.length = sizeof(placement);
  if (::GetWindowPlacement(hwnd_, &placement)) {
    const RECT& normal = placement.rcNormalPosition;
    config_->window_width = (int)UnscalePx(normal.right - normal.left, dpi_);
    config_->window_height = (int)UnscalePx(normal.bottom - normal.top, dpi_);
  }
  if (tabs_) {
    config_->last_tab_count = std::max(1, tabs_->Count());
    tabs_->SaveSession();
  }
  config_->Save(PortablePaths::ConfigFile(L"settings.json"));
  bookmarks_->Flush();
  history_->Flush();
}

void MainWindow::BeginClose() {
  if (closing_) return;
  closing_ = true;
  SaveWindowState();
  if (tabs_ && tabs_->Count() > 0) {
    tabs_->CloseAll(false);
    // 保險：3 秒後若仍有分頁沒關完就強制結束
    ::SetTimer(hwnd_, 3, 3000, nullptr);
  } else {
    ::DestroyWindow(hwnd_);
  }
}

}  // namespace lumen
