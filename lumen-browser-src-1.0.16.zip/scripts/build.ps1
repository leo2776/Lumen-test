﻿# ===========================================================================
#  Lumen Browser - scripts/build.ps1
#  One command build: fetch CEF (if missing) -> check toolchain -> CMake -> MSBuild
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -Config Debug
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -CefRoot D:\sdk\cef
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -NoFetch
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -NativeFrame
#    powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1 -Generator "NMake Makefiles"
#
#  This file is intentionally ASCII-only: Windows PowerShell 5.1 reads
#  non-BOM UTF-8 as CP950 on zh-TW systems and corrupts string literals.
# ===========================================================================
param(
  [ValidateSet("Release", "Debug")]
  [string]$Config = "Release",
  [string]$CefRoot = "",
  [string]$Generator = "",
  [switch]$NativeFrame,
  [switch]$NoFetch
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Push-Location $root

function Write-Step($text) { Write-Host $text -ForegroundColor Cyan }
function Write-Bad($text)  { Write-Host $text -ForegroundColor Red }

try {
  Write-Host ""
  Write-Host "=== Lumen Browser build ===" -ForegroundColor Cyan
  Write-Host "root   : $root"
  Write-Host "config : $Config"
  Write-Host ""

  # ---- 0. source tree sanity check ---------------------------------------
  #  Explorer's "Extract All" happily creates an EXTRA sub-folder when the zip
  #  already has a matching name, which leaves this folder without src\ and
  #  produces the confusing "Cannot find source file: src/main.cpp".
  $need = @("CMakeLists.txt", "src\main.cpp", "src\ui\MainWindow.cpp", "res\browser.rc")
  $lost = @()
  foreach ($n in $need) { if (-not (Test-Path (Join-Path $root $n))) { $lost += $n } }
  if ($lost.Count -gt 0) {
    Write-Bad "================ SOURCE TREE INCOMPLETE ================"
    foreach ($l in $lost) { Write-Bad "  missing: $l" }
    Write-Host ""
    $nested = Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue |
              Where-Object { Test-Path (Join-Path $_.FullName "src\main.cpp") } |
              Select-Object -First 1
    if ($nested) {
      Write-Host "A complete copy was found in the sub-folder: $($nested.Name)" -ForegroundColor Yellow
      Write-Host "Move it into the project root with:" -ForegroundColor White
      Write-Host "  xcopy /E /I /Y `"$($nested.Name)\*`" `".`""
    } else {
      Write-Host "The ZIP was never unpacked here (or it was unpacked elsewhere)." -ForegroundColor Yellow
      Write-Host "Do NOT use Explorer's 'Extract All' - it creates an extra folder." -ForegroundColor White
      Write-Host "Unpack it straight into this folder instead:" -ForegroundColor White
      Write-Host "  cd /d `"$root`""
      Write-Host "  powershell -NoProfile -Command `"Expand-Archive -Path '<path-to-zip>' -DestinationPath '.' -Force`""
      Write-Host "  (alternative: tar -xf `"<path-to-zip>`"   -- Windows' bsdtar also reads zip)"
    }
    Write-Host ""
    Write-Host "Then verify with:  powershell -ExecutionPolicy Bypass -File .\scripts\check-tree.ps1"
    exit 1
  }

  # ---- 1. locate CEF, download when missing -------------------------------
  if (-not $CefRoot) {
    if ($env:CEF_ROOT) { $CefRoot = $env:CEF_ROOT }
    else { $CefRoot = Join-Path $root (Join-Path "third_party" "cef") }
  }
  $CefRoot = [IO.Path]::GetFullPath($CefRoot)

  if (-not (Test-Path (Join-Path $CefRoot "include\cef_app.h"))) {
    if ($NoFetch) {
      Write-Bad "CEF not found: $CefRoot"
      Write-Host "Run: powershell -ExecutionPolicy Bypass -File .\scripts\fetch-cef.ps1"
      exit 1
    }
    Write-Host "CEF not found, downloading (~335 MB)..." -ForegroundColor Yellow
    $fetch = Join-Path $root "scripts\fetch-cef.ps1"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $fetch -CefRoot $CefRoot
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $CefRoot "include\cef_app.h"))) {
      throw "Could not obtain CEF"
    }
  }
  Write-Host "CEF    : $CefRoot"

  # ---- 2. locate cmake ----------------------------------------------------
  $vsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
  $cmake = $null
  $cmd = Get-Command cmake.exe -ErrorAction SilentlyContinue
  if ($cmd) {
    $cmake = $cmd.Source
  } elseif (Test-Path $vsWhere) {
    $vsPath = & $vsWhere -latest -products * -property installationPath
    if ($vsPath) {
      $candidate = Join-Path $vsPath "Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
      if (Test-Path $candidate) { $cmake = $candidate }
    }
  }
  if (-not $cmake) {
    Write-Bad "cmake.exe not found."
    Write-Host "Install CMake (https://cmake.org/download/) and tick 'Add to PATH',"
    Write-Host "or run this script from the 'x64 Native Tools Command Prompt for VS 2022'."
    exit 1
  }
  Write-Host "cmake  : $cmake"

  # ---- 3. toolchain / generator detection ---------------------------------
  #  A Visual Studio instance that provides the C++ toolset is REQUIRED.
  #  If none is found, CMake silently falls back to "NMake Makefiles", which
  #  then fails with the very confusing:
  #     "does not support platform specification, but platform x64 was specified"
  #     "CMAKE_CXX_COMPILER not set, after EnableLanguage"
  #  So we check up front and give an actionable message instead.
  $vsCpp  = $null
  $vsAny  = $null
  if (Test-Path $vsWhere) {
    $vsCpp = & $vsWhere -latest -products * -version "[17.0,18.0)" `
             -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationVersion
    if (-not $vsCpp) {
      $vsCpp = & $vsWhere -latest -products * -version "[16.0,17.0)" `
               -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationVersion
    }
    if (-not $vsCpp) {
      $vsAny = & $vsWhere -latest -products * -property installationPath
    }
  }

  $gen  = ""
  $archArgs = @("-A", "x64")

  if ($Generator) {
    $gen = $Generator
    if ($gen -eq "NMake Makefiles") { $archArgs = @() }
  } elseif ($vsCpp) {
    $ver = "$vsCpp"
    if ($ver -match '^17\.')      { $gen = "Visual Studio 17 2022" }
    elseif ($ver -match '^16\.')  { $gen = "Visual Studio 16 2019" }
  } elseif (Get-Command cl.exe -ErrorAction SilentlyContinue) {
    # No Visual Studio detected, but a compiler IS in PATH (e.g. VS Developer
    # Command Prompt, or a standalone MSVC/LLVM setup).
    $gen = "NMake Makefiles"
    $archArgs = @()
  }

  if (-not $gen) {
    Write-Host ""
    Write-Bad "============================================================"
    Write-Bad " BUILD TOOLCHAIN MISSING - cannot continue"
    Write-Bad "============================================================"
    Write-Host ""
    if ($vsAny) {
      Write-Host "Visual Studio is installed at:" -ForegroundColor Yellow
      Write-Host "  $vsAny"
      Write-Host ""
      Write-Host "but it does NOT include the C++ toolset." -ForegroundColor Yellow
      Write-Host "Fix: open 'Visual Studio Installer' -> Modify -> tick"
      Write-Host "     [x] Desktop development with C++  (Desktopentwicklung mit C++)"
      Write-Host "     and confirm these are included:"
      Write-Host "       - MSVC v143 - VS 2022 C++ x64/x86 build tools"
      Write-Host "       - Windows 10 SDK (10.0.19041.0 or newer)"
      Write-Host ""
    } else {
      Write-Host "No Visual Studio (or C++ compiler) was found on this machine." -ForegroundColor Yellow
      Write-Host ""
      Write-Host "Fastest fix (opens a ~2.5 GB download, no reboot needed):" -ForegroundColor White
      Write-Host "  winget install --id Microsoft.VisualStudio.2022.BuildTools -e --wait --override `"--quiet --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended`""
      Write-Host ""
      Write-Host "Manual fix:" -ForegroundColor White
      Write-Host "  1) https://visualstudio.microsoft.com/vs/community/  (or Build Tools)"
      Write-Host "  2) Workload: 'Desktop development with C++'"
      Write-Host "  3) Details: MSVC v143 x64/x86 build tools + Windows 10 SDK"
      Write-Host "  4) Re-run this script (a new terminal window helps CMake find it)"
      Write-Host ""
    }
    Write-Host "CMake needs cl.exe. The generator CMake picked otherwise was:" -ForegroundColor DarkGray
    Write-Host "  NMake Makefiles  ->  requires cl.exe in PATH" -ForegroundColor DarkGray
    Write-Host ""
    exit 1
  }

  Write-Host "gen    : $gen"
  Write-Host ""

  # ---- 4. CMake configure ------------------------------------------------
  $buildDir = Join-Path $root "build"

  # If the generator changed since the last attempt, the cache must be wiped,
  # otherwise CMake refuses to continue ("generator does not match").
  $cacheFile = Join-Path $buildDir "CMakeCache.txt"
  if (Test-Path $cacheFile) {
    $cachedGen = $null
    $line = Select-String -Path $cacheFile -Pattern "^CMAKE_GENERATOR:INTERNAL=" -ErrorAction SilentlyContinue |
            Select-Object -First 1
    if ($line) { $cachedGen = ($line.Line -split "=")[1] }
    if ($cachedGen -and $cachedGen -ne $gen) {
      Write-Host "Generator changed ('$cachedGen' -> '$gen'), wiping build directory ..." -ForegroundColor Yellow
      Remove-Item -Recurse -Force $buildDir -ErrorAction SilentlyContinue
    }
  }

  $cmakeArgs = @("-S", $root, "-B", $buildDir, "-G", $gen, "-DCEF_ROOT=$CefRoot") + $archArgs
  if ($NativeFrame) { $cmakeArgs += "-DLUMEN_NATIVE_FRAME=ON" }

  Write-Host "--- cmake configure ---" -ForegroundColor Cyan
  # Native tools that write to stderr would raise a terminating
  # NativeCommandError under $ErrorActionPreference = "Stop" (PowerShell 5.1),
  # so every native call is wrapped in "Continue" and merged with 2>&1.
  function Invoke-CMake([string[]]$cmakeArgv) {
    $old = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $lines = @()
    try {
      $lines = & $cmake @cmakeArgv 2>&1 | ForEach-Object {
      if ($_ -is [System.Management.Automation.ErrorRecord]) { $s = $_.Exception.Message } else { $s = "$_" }
      Write-Host $s
      $s
    }
    } catch {
      $lines = @("$($_.Exception.Message)")
    } finally {
      $ErrorActionPreference = $old
    }
    return ,$lines
  }

  $cfgOut = Invoke-CMake $cmakeArgs

  # Self-healing: a stale cache from a previous generator (e.g. an earlier
  # run without Visual Studio, which falls back to "NMake Makefiles") blocks
  # the configure with "does not match the generator used previously".
  if ($LASTEXITCODE -ne 0) {
    $text = ($cfgOut -join "`n")
    if ($text -match "does not match the generator used previously") {
      Write-Host ""
      Write-Host "Stale CMake cache found (generator changed). Wiping build directory and retrying once..." -ForegroundColor Yellow
      Remove-Item -Recurse -Force $buildDir -ErrorAction SilentlyContinue
      $cfgOut = Invoke-CMake $cmakeArgs
    }
  }

  $cfgLog = Join-Path $root "configure.log"
  try { ($cfgOut -join "`r`n") | Set-Content -Path $cfgLog -Encoding UTF8 } catch { }

  if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Bad "================ CMake configure FAILED ================"
    Write-Bad " First error lines (copied from the log):"
    Write-Bad "--------------------------------------------------------"
    $errs = $cfgOut | Where-Object { $_ -match "Error|error:|CMake Error|FATAL|not found|No such|cannot find" } |
            Select-Object -First 20
    if (-not $errs) { $errs = $cfgOut | Select-Object -First 20 }
    foreach ($e in $errs) { Write-Host "  $e" -ForegroundColor Red }
    Write-Bad "--------------------------------------------------------"
    Write-Host " Full log saved to: $cfgLog"
    Write-Host " Tip: paste the lines between the two dashed rules above." -ForegroundColor Yellow
    throw "CMake configure failed"
  }

  # ---- 5. build ----------------------------------------------------------
  Write-Host ""
  Write-Host "--- building (first run compiles the CEF wrapper, 5-15 min) ---" -ForegroundColor Yellow
  $buildArgs = @("--build", $buildDir, "--config", $Config, "--parallel")
  $buildOut = Invoke-CMake $buildArgs
  $buildLog = Join-Path $root "build.log"
  try { ($buildOut -join "`r`n") | Set-Content -Path $buildLog -Encoding UTF8 } catch { }

  if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Bad "================ BUILD FAILED ================"
    $berrs = $buildOut | Where-Object { $_ -match "error |error C|error MSB|error LNK|fatal error" } |
             Select-Object -First 25
    foreach ($e in $berrs) { Write-Host "  $e" -ForegroundColor Red }
    Write-Bad "----------------------------------------------"
    Write-Host " Full log saved to: $buildLog"
    Write-Host " Tip: the FIRST 'error C...' line is the one that matters." -ForegroundColor Yellow
    throw "Build failed"
  }

  # ---- 6. report ---------------------------------------------------------
  $outDir = Join-Path $buildDir $Config
  $exe = Join-Path $outDir "lumen.exe"
  Write-Host ""
  if (Test-Path $exe) {
    Write-Host "Build OK." -ForegroundColor Green
    Write-Host "  executable : $exe"
    Write-Host "  portable   : $outDir   (browser_data\ is created next to the exe)"
    Write-Host ""
    Write-Host "  Run it with:  & '$exe'"
    Write-Host ""
  } else {
    Write-Bad "lumen.exe was not produced - check the build output above."
    exit 1
  }
}
finally {
  Pop-Location
}
