﻿# ===========================================================================
#  Lumen Browser - scripts/check-tree.ps1
#  Verifies every source file against SRC-MANIFEST.txt (sha1 + line count).
#
#  Why: if a project folder has been overwritten by several ZIP versions, a
#  mixed set of files can cause build errors that look impossible, e.g.
#     error C2660: 'PaintToolbarButton': function does not take 5 arguments
#  while the .cpp clearly calls it with 5 arguments. This script finds such
#  stale files immediately.
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File .\scripts\check-tree.ps1
#    powershell -ExecutionPolicy Bypass -File .\scripts\check-tree.ps1 -Fix
#      -Fix prints the exact commands to refresh only the stale files.
#
#  This file is intentionally ASCII-only.
# ===========================================================================
param(
  [switch]$Fix
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$manifest = Join-Path $root "SRC-MANIFEST.txt"

if (-not (Test-Path $manifest)) {
  Write-Host "SRC-MANIFEST.txt not found next to scripts\\. Cannot verify." -ForegroundColor Red
  exit 1
}

$ok = 0
$bad = New-Object System.Collections.ArrayList
$missing = New-Object System.Collections.ArrayList

foreach ($line in Get-Content $manifest) {
  if ($line -match '^\s*$') { continue }
  if ($line -match '^\s*#') { continue }
  $parts = $line -split '\s+', 3
  if ($parts.Count -lt 3) { continue }
  $wantSha = $parts[0].ToLower()
  $rel     = $parts[2].Trim()
  $path    = Join-Path $root ($rel -replace '/', '\')

  if (-not (Test-Path $path)) {
    [void]$missing.Add($rel)
    continue
  }
  $got = (Get-FileHash -Algorithm SHA1 -Path $path).Hash.ToLower()
  if ($got -eq $wantSha) {
    $ok++
  } else {
    $lines = (Get-Content $path | Measure-Object -Line).Lines
    [void]$bad.Add(("{0}   (local {1} lines / expected {2})" -f $rel, $lines, $parts[1].Trim()))
  }
}

Write-Host ""
Write-Host "checked : $($ok + $bad.Count + $missing.Count) files"
Write-Host "match   : $ok" -ForegroundColor Green
if ($bad.Count -gt 0) {
  Write-Host "STALE   : $($bad.Count)" -ForegroundColor Red
  foreach ($b in $bad) { Write-Host "  $b" -ForegroundColor Red }
}
if ($missing.Count -gt 0) {
  Write-Host "MISSING : $($missing.Count)" -ForegroundColor Yellow
  foreach ($m in $missing) { Write-Host "  $m" -ForegroundColor Yellow }
}
Write-Host ""

if ($bad.Count -eq 0 -and $missing.Count -eq 0) {
  Write-Host "Source tree is consistent with the shipped version." -ForegroundColor Green
  Write-Host ""
  exit 0
}

Write-Host "The folder contains files from a different (older) ZIP version." -ForegroundColor Yellow
Write-Host "Re-extract the current ZIP over this folder and choose 'Replace all'."
Write-Host ""
if ($Fix) {
  Write-Host "Quickest deterministic repair (keeps third_party\\cef, so CEF is NOT re-downloaded):" -ForegroundColor White
  Write-Host ""
  Write-Host "  cd /d `"$root`""
  Write-Host "  rmdir /s /q src res build"
  Write-Host "  :: then unzip the current lumen-browser-src-*.zip into this folder (Replace all)"
  Write-Host "  BUILD-WIN10.cmd"
  Write-Host ""
}
exit 1
