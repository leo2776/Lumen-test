﻿# ===========================================================================
#  Lumen Browser - scripts/fetch-cef.ps1
#  Download + verify + extract the PINNED CEF binary distribution.
#
#  Pinned build : CEF 130.1.16+g5a7e5ed+chromium-130.0.6723.117 (windows64)
#  Why pinned   : the C++ sources in src\ were verified header-by-header
#                 against this exact version. See docs/CEF-VERSION-NOTES.md.
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File .\scripts\fetch-cef.ps1
#    powershell -ExecutionPolicy Bypass -File .\scripts\fetch-cef.ps1 -Force
#    powershell -ExecutionPolicy Bypass -File .\scripts\fetch-cef.ps1 -CefRoot D:\sdk\cef
#
#  EXTRACTION:
#    CEF only publishes .tar.bz2 for windows64. Windows' built-in tar.exe is
#    bsdtar WITHOUT a bzip2 filter, so it fails with
#      "Can't initialize filter; unable to run program bzip2 -d".
#    Order used here: existing 7-Zip  ->  tar.exe  ->  portable 7-Zip download.
#
#  NOTE on PowerShell 5.1: a native exe that writes to stderr raises a
#  terminating "NativeCommandError" when $ErrorActionPreference is 'Stop'.
#  All native invocations below therefore run through helpers that switch to
#  'Continue' and merge stderr, so probing can never abort the script.
#
#  This file is intentionally ASCII-only: Windows PowerShell 5.1 reads
#  non-BOM UTF-8 as CP950 on zh-TW systems and corrupts string literals.
# ===========================================================================
param(
  [string]$Version = "130.1.16+g5a7e5ed+chromium-130.0.6723.117",
  [string]$CefRoot = "",
  [switch]$Force
)

$ErrorActionPreference = "Stop"

function Write-Step($text) { Write-Host "==> $text" -ForegroundColor Cyan }
function Write-Warn($text) { Write-Host "    $text" -ForegroundColor Yellow }
function Write-Ok($text)   { Write-Host "    $text" -ForegroundColor Green }

# ---------------------------------------------------------------------------
#  Native command helpers (stderr safe on PowerShell 5.1)
# ---------------------------------------------------------------------------
function Invoke-NativeQuiet($exe, [string[]]$argv) {
  $old = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  $code = -1
  try {
    & $exe @argv 2>&1 | Out-Null
    $code = $LASTEXITCODE
  } catch {
    $code = -1
  } finally {
    $ErrorActionPreference = $old
  }
  return $code
}

function Invoke-NativeVisible($exe, [string[]]$argv) {
  $old = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  $code = -1
  try {
    & $exe @argv
    $code = $LASTEXITCODE
  } catch {
    $code = -1
  } finally {
    $ErrorActionPreference = $old
  }
  return $code
}

try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$root       = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$toolsDir   = Join-Path $root "scripts\tools"

if (-not $CefRoot) { $CefRoot = Join-Path $root (Join-Path "third_party" "cef") }
$CefRoot    = [IO.Path]::GetFullPath($CefRoot)
$thirdParty = Split-Path -Parent $CefRoot

$fileName = "cef_binary_" + $Version + "_windows64.tar.bz2"
$archive  = Join-Path $thirdParty $fileName

Write-Step "CEF version : $Version"
Write-Step "Destination : $CefRoot"

$marker = Join-Path $CefRoot "include\cef_app.h"
if ((Test-Path $marker) -and -not $Force) {
  Write-Host ""
  Write-Host "CEF already present - nothing to do (use -Force to re-download)." -ForegroundColor Green
  Write-Host ""
  exit 0
}

New-Item -ItemType Directory -Force -Path $thirdParty | Out-Null

# ---------------------------------------------------------------------------
#  Download helper
# ---------------------------------------------------------------------------
function Get-RemoteFile($url, $outFile, $label) {
  if (Test-Path $outFile) { Remove-Item -Force $outFile -ErrorAction SilentlyContinue }
  $curl = Join-Path $env:SystemRoot "System32\curl.exe"
  $code = 1
  if (Test-Path $curl) {
    $code = Invoke-NativeVisible $curl @("-L", "--fail", "--retry", "3", "--retry-delay", "5", "-o", $outFile, $url)
  } else {
    $ProgressPreference = "SilentlyContinue"
    try { Invoke-WebRequest -Uri $url -OutFile $outFile -UseBasicParsing; $code = 0 } catch { $code = 1 }
  }
  if ($code -ne 0 -or -not (Test-Path $outFile)) { throw "Download failed ($label): $url" }
  try { Unblock-File -Path $outFile } catch { }
}

# ---------------------------------------------------------------------------
#  7-Zip discovery / provisioning
# ---------------------------------------------------------------------------
function Find-7Zip {
  $candidates = @(
    (Join-Path $toolsDir "x64\7za.exe"),
    (Join-Path $toolsDir "7za.exe"),
    (Join-Path ${env:ProgramFiles} "7-Zip\7z.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "7-Zip\7z.exe")
  )
  foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { return $c } }
  $cmd = Get-Command "7z.exe" -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return $null
}

function Install-Portable7Zip {
  New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null
  $szr   = Join-Path $toolsDir "7zr.exe"
  $extra = Join-Path $toolsDir "7z-extra.7z"

  if (-not (Test-Path $szr)) {
    Write-Step "Downloading 7-Zip standalone extractor (0.6 MB)"
    Get-RemoteFile "https://www.7-zip.org/a/7zr.exe" $szr "7zr.exe"
  }
  if (-not (Test-Path $extra)) {
    Write-Step "Downloading 7-Zip console package (1.0 MB)"
    Get-RemoteFile "https://www.7-zip.org/a/7z2301-extra.7z" $extra "7z-extra"
  }

  Write-Step "Unpacking 7-Zip console tool (no install, no admin rights needed)"
  $code = Invoke-NativeQuiet $szr @("x", $extra, ("-o" + $toolsDir), "-y")
  if ($code -ne 0) { throw "7zr.exe failed to unpack the 7-Zip console package (exit code $code)" }

  $za = Join-Path $toolsDir "x64\7za.exe"
  if (-not (Test-Path $za)) { $za = Join-Path $toolsDir "7za.exe" }
  if (-not (Test-Path $za)) {
    throw "Could not obtain 7za.exe. Install 7-Zip manually from https://www.7-zip.org/ and re-run."
  }
  try { Unblock-File -Path $za } catch { }
  Write-Ok "7-Zip ready: $za"
  return $za
}

# ---------------------------------------------------------------------------
#  Step 1: obtain the archive (reuse an already verified one)
# ---------------------------------------------------------------------------
$expectedSha1 = "5bc51f2378ddcf0d05abbb7d07681e48ba78b83e"

if ((Test-Path $archive) -and -not $Force) {
  Write-Host ""
  Write-Host "Found existing archive, reusing it (no re-download):" -ForegroundColor Green
  Write-Host "    $archive"
} else {
  $url = "https://cef-builds.spotifycdn.com/" + ($fileName -replace '\+', '%2B')
  Write-Step "Downloading ~335 MB (335,346,714 bytes), please wait"
  Write-Warn $url
  Get-RemoteFile $url $archive "CEF archive"
  Write-Ok ("Downloaded {0:N1} MB" -f ((Get-Item $archive).Length / 1MB))
}

if ($Version -eq "130.1.16+g5a7e5ed+chromium-130.0.6723.117") {
  Write-Step "Verifying SHA1"
  $actualSha1 = (Get-FileHash -Algorithm SHA1 -Path $archive).Hash.ToLower()
  if ($actualSha1 -ne $expectedSha1) {
    Write-Warn "expected : $expectedSha1"
    Write-Warn "actual   : $actualSha1"
    Write-Warn "The archive is incomplete or corrupted. Deleting it - please re-run."
    Remove-Item -Force $archive -ErrorAction SilentlyContinue
    throw "SHA1 verification failed"
  }
  Write-Ok "SHA1 OK"
} else {
  Write-Warn "Custom -Version given, SHA1 check skipped."
}

# ---------------------------------------------------------------------------
#  Step 2: choose an extractor and unpack (bz2 layer -> tar layer)
# ---------------------------------------------------------------------------
$stage = Join-Path $thirdParty "_cef_stage"
if (Test-Path $stage) { Remove-Item -Recurse -Force $stage }
New-Item -ItemType Directory -Force -Path $stage | Out-Null

$tarExe   = Join-Path $env:SystemRoot "System32\tar.exe"
$sevenZip = Find-7Zip
$done     = $false

if ($sevenZip) {
  Write-Ok "Using 7-Zip: $sevenZip"
} else {
  # No 7-Zip installed. Provision the official portable console build
  # (7zr.exe + 7z2301-extra.7z -> x64\7za.exe, ~1.6 MB, no admin, no registry).
  try {
    $sevenZip = Install-Portable7Zip
  } catch {
    Write-Warn "Could not obtain 7-Zip: $($_.Exception.Message)"
    $sevenZip = $null
  }
}

if ($sevenZip) {
  if (Test-Path $stage) { Remove-Item -Recurse -Force $stage }
  New-Item -ItemType Directory -Force -Path $stage | Out-Null

  Write-Step "Extracting bzip2 layer"
  $code = Invoke-NativeQuiet $sevenZip @("x", $archive, ("-o" + $stage), "-y")
  if ($code -ne 0) { throw "7-Zip failed to decompress the bzip2 layer (exit code $code)" }

  $tarFile = Get-ChildItem -Path $stage -Filter "*.tar" -File | Select-Object -First 1
  if (-not $tarFile) { throw "No .tar produced by the bzip2 layer; the archive may be corrupt" }

  Write-Step "Extracting tar layer - about 1.2 GB, 1-3 minutes with no output is normal"
  $code = Invoke-NativeQuiet $sevenZip @("x", $tarFile.FullName, ("-o" + $stage), "-y")
  if ($code -ne 0) { throw "7-Zip failed to extract the tar layer (exit code $code)" }
  Write-Ok "Extraction finished"
  $done = $true
}

# Last resort: the built-in bsdtar, which only works when a bzip2.exe exists.
if (-not $done -and (Test-Path $tarExe)) {
  Write-Step "Falling back to Windows tar.exe (works only if bzip2 is installed)"
  $code = Invoke-NativeQuiet $tarExe @("-xjf", $archive, "-C", $stage)
  if ($code -eq 0) {
    $probe = Get-ChildItem -Path $stage -Directory -ErrorAction SilentlyContinue |
             Where-Object { Test-Path (Join-Path $_.FullName "include\cef_app.h") } |
             Select-Object -First 1
    if ($probe) { Write-Ok "tar.exe worked"; $done = $true }
  }
}

if (-not $done) {
  throw ("No working bzip2 extractor. Install 7-Zip from https://www.7-zip.org/ , then either re-run this script " +
         "or extract manually: .tar.bz2 -> .tar -> folder, and copy the contents of cef_binary_*_windows64 into " +
         "$CefRoot")
}

# ---------------------------------------------------------------------------
#  Step 3: locate cef_binary_*_windows64 and move it into place
# ---------------------------------------------------------------------------
$extractedDir = Get-ChildItem -Path $stage -Directory -ErrorAction SilentlyContinue |
                Where-Object { Test-Path (Join-Path $_.FullName "include\cef_app.h") } |
                Select-Object -First 1
if (-not $extractedDir) { throw "Extraction finished but include\cef_app.h was not found" }

if (Test-Path $CefRoot) { Remove-Item -Recurse -Force $CefRoot }
New-Item -ItemType Directory -Force -Path $CefRoot | Out-Null
Write-Step "Moving files into $CefRoot"
Get-ChildItem -Path $extractedDir.FullName -Force | Move-Item -Destination $CefRoot -Force

Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue

# ---------------------------------------------------------------------------
#  Step 4: verify layout
# ---------------------------------------------------------------------------
$required = @(
  "include\cef_app.h",
  "cmake\FindCEF.cmake",
  "cmake\cef_variables.cmake",
  "libcef_dll\CMakeLists.txt",
  "Release\libcef.dll",
  "Release\libcef.lib",
  "Resources\icudtl.dat",
  "Resources\locales"
)
$missing = @()
foreach ($item in $required) {
  if (-not (Test-Path (Join-Path $CefRoot $item))) { $missing += $item }
}

Write-Host ""
if ($missing.Count -eq 0) {
  Write-Host "CEF is ready." -ForegroundColor Green
  Write-Host "  location : $CefRoot"
  Write-Host "  next     : powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1"
  Write-Host ""
  Write-Host "  You may delete the archive: $archive" -ForegroundColor DarkGray
  Write-Host ""
  exit 0
} else {
  Write-Warn "These items are missing, CEF may be incomplete:"
  $missing | ForEach-Object { Write-Warn "  - $_" }
  exit 1
}
